"""Fetch the signed-in person's own account label for a connector (T44, decision #161).

The provider's response is DATA, never instructions: only one named field (or an
ordered fallback of a few) is ever read out of it, and any failure — a network
error, a non-200 status, a missing field, or a field that isn't a string — comes
back as ``None`` without ever raising. The result is a plain label (an email
address, sign-in name, or display name), stripped, capped at 254 characters, with
control characters dropped; it is only ever used as a label, never logged
alongside a token, and never parsed for instructions.

No new OAuth scope is needed anywhere here: every call below reuses a
``GET``-only read already covered by scopes each connector already requests
(Microsoft's ``User.Read``; Google's existing Gmail/Drive read scopes).
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import replace
from pathlib import Path
from typing import Final

import httpx

from gates.catalog import load_connector
from gates.errors import ConnectError
from gates.secrets_port import SecretsPort, default_secrets_port
from gates.tokens import TokenStoreError, load_tokens, store_tokens

#: Every account fetch is bounded the same way regardless of provider.
TIMEOUT_SECONDS: Final = 10.0
_MAX_RESPONSE_BYTES: Final = 64 * 1024
_MAX_ACCOUNT_LENGTH: Final = 254
_CONTROL_CHARS_RE: Final = re.compile(r"[\x00-\x1f\x7f]")

_MICROSOFT_CONNECTORS: Final = frozenset({"outlook", "teams", "onedrive", "outlook-calendar"})
_MICROSOFT_ME_URL: Final = (
    "https://graph.microsoft.com/v1.0/me?$select=mail,userPrincipalName,displayName"
)
_GMAIL_PROFILE_URL: Final = "https://gmail.googleapis.com/gmail/v1/users/me/profile"
_DRIVE_ABOUT_URL: Final = (
    "https://www.googleapis.com/drive/v3/about?fields=user(emailAddress,displayName)"
)

#: (connector, person) pairs `ensure_account` has already tried this process —
#: a GET /connectors poll never calls the provider more than once per run.
_TRIED: set[tuple[str, str]] = set()


def _clean(value: object) -> str | None:
    """A stripped, length-capped, control-character-free label, or ``None``."""
    if not isinstance(value, str):
        return None
    cleaned = _CONTROL_CHARS_RE.sub("", value.strip())[:_MAX_ACCOUNT_LENGTH]
    return cleaned or None


def _first_clean(payload: Mapping[str, object] | None, fields: tuple[str, ...]) -> str | None:
    if payload is None:
        return None
    for field_name in fields:
        cleaned = _clean(payload.get(field_name))
        if cleaned:
            return cleaned
    return None


def _drive_account(payload: Mapping[str, object] | None) -> str | None:
    if payload is None:
        return None
    user = payload.get("user")
    if not isinstance(user, dict):
        return None
    return _first_clean(user, ("emailAddress", "displayName"))


def _get_json(url: str, access_token: str, *, http: httpx.Client) -> dict[str, object] | None:
    """One bounded GET. Any failure at all — never raises — comes back as ``None``."""
    try:
        response = http.get(
            url,
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=TIMEOUT_SECONDS,
            follow_redirects=False,
        )
    except Exception:  # noqa: BLE001 - a fetch failure here is always just None
        return None
    if response.status_code != 200:
        return None
    if len(response.content) > _MAX_RESPONSE_BYTES:
        return None
    try:
        payload = response.json()
    except ValueError:
        return None
    return payload if isinstance(payload, dict) else None


def fetch_account(connector_name: str, access_token: str, *, http: httpx.Client) -> str | None:
    """The signed-in person's own account label for this connector, or ``None``.

    Microsoft connectors (``outlook``, ``teams``, ``onedrive``,
    ``outlook-calendar``) read ``mail``, else ``userPrincipalName``, else
    ``displayName`` from Graph's ``/me``. ``gmail`` reads ``emailAddress``.
    ``google-drive`` reads ``user.emailAddress``, else ``user.displayName``.
    ``google-calendar`` makes no call and always returns ``None``. Every other
    connector name also returns ``None``.
    """
    if connector_name in _MICROSOFT_CONNECTORS:
        payload = _get_json(_MICROSOFT_ME_URL, access_token, http=http)
        return _first_clean(payload, ("mail", "userPrincipalName", "displayName"))
    if connector_name == "gmail":
        payload = _get_json(_GMAIL_PROFILE_URL, access_token, http=http)
        return _first_clean(payload, ("emailAddress",))
    if connector_name == "google-drive":
        payload = _get_json(_DRIVE_ABOUT_URL, access_token, http=http)
        return _drive_account(payload)
    return None


def ensure_account(
    name: str,
    person: str,
    *,
    secrets: SecretsPort | None = None,
    http: httpx.Client | None = None,
    catalog_dir: Path | None = None,
) -> str | None:
    """Fetch and store this connector's account once per process, if not already known.

    A no-op, no-network call whenever the stored bundle already carries an
    account (the common case). Otherwise refreshes the access token first only
    through the existing silent refresh path (:func:`gates.connect.refresh_if_needed`),
    then fetches and stores the account. Once tried for a (connector, person) pair in
    this process — success or failure — later calls in the same run never call the
    provider again.
    """
    from gates.connect import refresh_if_needed  # deferred: gates.connect imports this module

    connector = load_connector(name, catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    try:
        bundle = load_tokens(secrets_port, connector.name, person)
    except TokenStoreError:
        return None
    if bundle is None:
        return None
    if bundle.account is not None:
        return bundle.account
    key = (connector.name, person)
    if key in _TRIED:
        return None
    _TRIED.add(key)
    client = http if http is not None else httpx.Client()
    owns_client = http is None
    try:
        try:
            refreshed = refresh_if_needed(
                name, person, catalog_dir=catalog_dir, transport=client, secrets=secrets_port
            )
        except ConnectError:
            return None
        account = fetch_account(connector.name, refreshed.access_token, http=client)
        if account is None:
            return None
        updated = replace(refreshed, account=account)
        try:
            store_tokens(secrets_port, connector.name, person, updated)
        except TokenStoreError:
            pass
        return account
    finally:
        if owns_client:
            client.close()
