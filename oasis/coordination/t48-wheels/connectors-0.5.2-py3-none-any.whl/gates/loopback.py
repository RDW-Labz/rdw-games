"""A one-shot OAuth callback receiver on ``127.0.0.1``.

Binds to an OS-assigned free port on the loopback interface only, accepts
exactly one callback request, and hands the raw ``code``/``state``/``error``
query values back to the caller. It never interprets or trusts those values
(they are provider-controlled data); the caller is responsible for checking
``state`` against the one it generated before treating ``code`` as real.

Bounded on purpose: the request path is capped in length, no request body is
ever read, and the server serves at most one meaningful request before it
shuts itself down.
"""

from __future__ import annotations

import contextlib
import threading
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import cast
from urllib.parse import parse_qs, urlsplit

_SUCCESS_BODY = b"<html><body>You can close this window and go back to OASIS.</body></html>"
_MAX_PATH_LENGTH = 4096
_POLL_INTERVAL_SECONDS = 0.2


@dataclass(frozen=True)
class CallbackResult:
    """The raw values a provider sent back to the loopback redirect."""

    code: str | None
    state: str | None
    error: str | None


def _first(query: dict[str, list[str]], key: str) -> str | None:
    values = query.get(key)
    if not values:
        return None
    return values[0]


class _CallbackHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002
        # Never log request details: the query string may carry a real
        # authorization code.
        return

    def do_GET(self) -> None:  # noqa: N802 - http.server API name
        server = cast("_Server", self.server)
        if server.event.is_set() or len(self.path) > _MAX_PATH_LENGTH:
            self.send_response(410)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        query = parse_qs(urlsplit(self.path).query, keep_blank_values=True)
        result = CallbackResult(
            code=_first(query, "code"),
            state=_first(query, "state"),
            error=_first(query, "error"),
        )
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(_SUCCESS_BODY)))
        self.end_headers()
        self.wfile.write(_SUCCESS_BODY)
        server.result = result
        server.event.set()


class _Server(HTTPServer):
    def __init__(self, host: str) -> None:
        super().__init__((host, 0), _CallbackHandler)
        self.result: CallbackResult | None = None
        self.event = threading.Event()


class LoopbackServer:
    """Runs :class:`_Server` on a background thread until one callback lands."""

    def __init__(self, *, host: str = "127.0.0.1") -> None:
        self._server = _Server(host)
        self._server.timeout = _POLL_INTERVAL_SECONDS
        self._thread: threading.Thread | None = None

    @property
    def port(self) -> int:
        """The OS-assigned free port this server is bound to."""
        return int(self._server.server_address[1])

    def start(self) -> None:
        """Start serving in a background thread."""
        thread = threading.Thread(target=self._serve, daemon=True)
        self._thread = thread
        thread.start()

    def _serve(self) -> None:
        while not self._server.event.is_set():
            self._server.handle_request()

    def wait(self, timeout_seconds: float) -> CallbackResult | None:
        """Block for the one callback, or ``None`` if it never arrives."""
        arrived = self._server.event.wait(timeout_seconds)
        if not arrived:
            # Stop the serving loop; nothing more will be accepted.
            self._server.event.set()
            return None
        return self._server.result

    def close(self) -> None:
        """Stop the serving thread, then tear down the socket.

        Order matters: signal and join the background thread first, so it is
        never mid-``handle_request`` (and about to touch the socket) at the
        moment ``server_close`` closes it out from under it.
        """
        self._server.event.set()
        thread = self._thread
        if thread is not None:
            thread.join(timeout=1.0)
        with contextlib.suppress(Exception):
            self._server.server_close()
