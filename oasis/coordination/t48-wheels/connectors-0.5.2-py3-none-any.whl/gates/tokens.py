"""Token storage: the only place a connector's access/refresh tokens live.

Tokens are never written anywhere except through :mod:`gates.secrets_port`
(which itself only talks to :mod:`anorak.secrets`, the OS keychain). A whole
:class:`TokenBundle` is serialised as one JSON string and stored under one
secret name per (connector, person) pair, so there is exactly one thing to
delete to disconnect and exactly one thing to redact if this module's own
errors ever needed to mention it (they never reveal the plaintext).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Final

from gates.secrets_port import SecretsPort

_NAME_RE: Final = re.compile(r"[a-z][a-z0-9_.-]{0,127}")
_MAX_PERSON_SLUG_LENGTH: Final = 64


class TokenStoreError(Exception):
    """A stored token bundle could not be built, read, or written."""


@dataclass(frozen=True)
class TokenBundle:
    """One connector's tokens for one person. Never logged, never printed."""

    access_token: str
    refresh_token: str | None
    token_type: str
    expires_at: datetime
    obtained_at: datetime
    scope: str
    refresh_expires_at: datetime | None = None
    #: T44 (decision #161) — the signed-in person's own account label (an email
    #: address, sign-in name, or display name), fetched once via `gates.account`.
    #: `None` until fetched; a stored bundle from before this field existed also
    #: loads with `account=None`.
    account: str | None = None

    def is_access_token_stale(self, *, buffer_seconds: float, now: datetime | None = None) -> bool:
        """True once the access token is expired or within ``buffer_seconds``."""
        current = now if now is not None else datetime.now(UTC)
        remaining = (self.expires_at - current).total_seconds()
        return remaining <= buffer_seconds

    def is_refresh_token_expired(self, *, now: datetime | None = None) -> bool:
        """True only when this provider's refresh token has a known TTL that passed."""
        if self.refresh_expires_at is None:
            return False
        current = now if now is not None else datetime.now(UTC)
        return current >= self.refresh_expires_at

    def to_json(self) -> str:
        payload: dict[str, str | None] = {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "token_type": self.token_type,
            "expires_at": self.expires_at.isoformat(),
            "obtained_at": self.obtained_at.isoformat(),
            "scope": self.scope,
            "refresh_expires_at": (
                self.refresh_expires_at.isoformat() if self.refresh_expires_at is not None else None
            ),
            "account": self.account,
        }
        return json.dumps(payload, separators=(",", ":"))

    @classmethod
    def from_json(cls, raw: str) -> TokenBundle:
        try:
            payload = json.loads(raw)
        except ValueError as error:
            raise TokenStoreError("stored connection data was not valid") from error
        if not isinstance(payload, dict):
            raise TokenStoreError("stored connection data was not valid")
        try:
            access_token = payload["access_token"]
            refresh_token = payload["refresh_token"]
            token_type = payload["token_type"]
            expires_at = payload["expires_at"]
            obtained_at = payload["obtained_at"]
            scope = payload["scope"]
            refresh_expires_at = payload.get("refresh_expires_at")
            account = payload.get("account")
            if not isinstance(access_token, str) or not access_token:
                raise TokenStoreError("stored connection data was not valid")
            if refresh_token is not None and not isinstance(refresh_token, str):
                raise TokenStoreError("stored connection data was not valid")
            if not isinstance(token_type, str) or not token_type:
                raise TokenStoreError("stored connection data was not valid")
            if not isinstance(expires_at, str) or not isinstance(obtained_at, str):
                raise TokenStoreError("stored connection data was not valid")
            if not isinstance(scope, str):
                raise TokenStoreError("stored connection data was not valid")
            if refresh_expires_at is not None and not isinstance(refresh_expires_at, str):
                raise TokenStoreError("stored connection data was not valid")
            if account is not None and not isinstance(account, str):
                raise TokenStoreError("stored connection data was not valid")
            return cls(
                access_token=access_token,
                refresh_token=refresh_token,
                token_type=token_type,
                expires_at=datetime.fromisoformat(expires_at),
                obtained_at=datetime.fromisoformat(obtained_at),
                scope=scope,
                refresh_expires_at=(
                    datetime.fromisoformat(refresh_expires_at)
                    if refresh_expires_at is not None
                    else None
                ),
                account=account,
            )
        except (KeyError, ValueError) as error:
            raise TokenStoreError("stored connection data was not valid") from error


def _slug(value: str) -> str:
    """A lowercase, secret-name-safe slug for a person identifier."""
    lowered = value.strip().lower()
    slugged = re.sub(r"[^a-z0-9_.-]", "-", lowered)
    slugged = re.sub(r"-{2,}", "-", slugged).strip("-.")
    if not slugged:
        slugged = "person"
    if not slugged[0].isalpha():
        slugged = f"p-{slugged}"
    return slugged[:_MAX_PERSON_SLUG_LENGTH]


def token_secret_name(connector: str, person: str) -> str:
    """The one secret name a connector+person's tokens live under."""
    name = f"gates.tokens.{connector}.{_slug(person)}"
    if _NAME_RE.fullmatch(name) is None:
        raise TokenStoreError("could not build a valid secret name for this connection")
    return name


def store_tokens(secrets: SecretsPort, connector: str, person: str, bundle: TokenBundle) -> None:
    """Store ``bundle`` as the one secret for this (connector, person)."""
    name = token_secret_name(connector, person)
    try:
        secrets.set(name, bundle.to_json())
    except Exception as error:  # noqa: BLE001 - never leak the backend's own message
        raise TokenStoreError("the connection could not be saved") from error


def load_tokens(secrets: SecretsPort, connector: str, person: str) -> TokenBundle | None:
    """Return the stored bundle, or ``None`` if this connector isn't connected."""
    name = token_secret_name(connector, person)
    try:
        raw = secrets.get(name).reveal()
    except KeyError:
        return None
    except Exception as error:  # noqa: BLE001 - never leak the backend's own message
        raise TokenStoreError("the saved connection could not be read") from error
    return TokenBundle.from_json(raw)


def delete_tokens(secrets: SecretsPort, connector: str, person: str) -> bool:
    """Remove the stored bundle, if any, and report whether one was actually there.

    Always safe to repeat: ``True`` the first time (something was removed),
    ``False`` every time after (nothing was there to remove).
    """
    name = token_secret_name(connector, person)
    try:
        secrets.delete(name)
    except KeyError:
        return False
    except Exception as error:  # noqa: BLE001 - never leak the backend's own message
        raise TokenStoreError("the connection could not be removed") from error
    return True
