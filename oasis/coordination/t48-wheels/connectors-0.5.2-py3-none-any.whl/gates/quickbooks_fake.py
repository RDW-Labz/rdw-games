"""``FakeQuickBooksTransport`` — canned GET responses for QuickBooks read tests.

The only implementation of :class:`~gates.quickbooks_read.QuickBooksTransport`
used by this repo's tests: it never touches the network. Every response is
keyed by URL path plus its sorted query string, so a test builds its
fixtures once and the fake serves back exactly what it's given; an
unrecorded URL raises instead of guessing. ``calls`` is the ordered list of
every key this fake actually saw, for assertions like "the pack requested
exactly these six report windows." Like the real transport it has no
non-``get`` method — there is nothing here a write could call.
"""

from __future__ import annotations

from collections.abc import Mapping
from urllib.parse import urlsplit

from gates.errors import ConnectError
from gates.quickbooks_read import TransportResponse


def _canonical_key(url: str) -> str:
    """``path?sorted&query`` for ``url`` — the key both the fake and its tests use."""
    parsed = urlsplit(url)
    if not parsed.query:
        return parsed.path
    query = "&".join(sorted(parsed.query.split("&")))
    return f"{parsed.path}?{query}"


class FakeQuickBooksTransport:
    """Records every GET; serves back a canned :class:`TransportResponse` or raises."""

    def __init__(self, responses: Mapping[str, TransportResponse]) -> None:
        self._responses = dict(responses)
        self.calls: list[str] = []

    async def get(
        self, url: str, *, headers: Mapping[str, str], timeout: float
    ) -> TransportResponse:
        key = _canonical_key(url)
        self.calls.append(key)
        response = self._responses.get(key)
        if response is None:
            raise ConnectError(
                "QuickBooks fake transport saw an unrecorded URL.", kind="generic"
            )
        return response
