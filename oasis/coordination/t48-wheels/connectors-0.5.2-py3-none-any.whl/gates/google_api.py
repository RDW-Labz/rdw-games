"""Gmail (REST v1), Google Calendar (v3) and Google Drive (v3) reads and writes (T27).

Six reads (`gmail_unread`, `gmail_search`, `gcal_today`, `drive_search`,
`drive_read_text`) and ten writes (`gmail_send`, `gmail_reply`, `gmail_move`,
`gcal_create`, `gcal_update`, `gcal_delete`, `drive_create`, `drive_move`,
`drive_share`, `drive_delete`), each against its own connector's already-
stored token. Shared read shapes (`MailHeader`, `UnreadMail`, `MailSearch`,
`CalendarEvent`, `CalendarDay`, `FileItem`, `FileList`, `FileText`) and
`WriteResult` live in :mod:`gates.graph_read` and :mod:`gates.results`
(both owned by the Microsoft-side job); this module only imports them.

Every provider response is DATA: only the named fields below are ever read
out of it. A subject, sender, snippet, event title, location or file name is
sanitised (control characters stripped, length-capped) before it leaves this
module but otherwise kept verbatim, as data. A mail body, file text or chat
text is never written to a :class:`~gates.errors.ConnectError` message or any
log line this module emits.

Hardening mirrors :mod:`gates.oauth_http` and :mod:`gates.graph_read`: HTTPS
Google API hosts only, no redirects followed, a 15 second timeout, a bounded
response size, and a single silent refresh-and-retry on a 401. Every failure
surfaces as the same :class:`~gates.errors.ConnectError` the rest of this
package uses — never a raw token, URL, header, or response body.
"""

from __future__ import annotations

import base64
import contextlib
import json
import re
import uuid
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from email.message import EmailMessage
from email.utils import getaddresses, parseaddr
from pathlib import Path
from typing import Literal
from urllib.parse import urlencode

import httpx

from gates import audit
from gates.catalog import ConnectorConfig, load_connector
from gates.connect import DEFAULT_PERSON, PROACTIVE_REFRESH_BUFFER_SECONDS
from gates.errors import ConnectError, error_text
from gates.graph_read import (
    CalendarDay,
    CalendarEvent,
    FileItem,
    FileList,
    FileText,
    MailHeader,
    MailSearch,
    MailSearchFilters,
    UnreadMail,
    filter_and_sort_search_results,
    filter_by_sender,
    is_valid_message_id,
    validate_mail_search_filters,
)
from gates.oauth_http import (
    DEFAULT_TIMEOUT_SECONDS,
    MAX_RESPONSE_BYTES,
    refresh_access_token_async,
)
from gates.results import WriteResult
from gates.secrets_port import SecretsPort, default_secrets_port
from gates.tokens import TokenBundle, TokenStoreError, load_tokens, store_tokens

_GMAIL_BASE = "https://gmail.googleapis.com/gmail/v1/users/me"
_CALENDAR_BASE = "https://www.googleapis.com/calendar/v3"
_DRIVE_BASE = "https://www.googleapis.com/drive/v3"
_DRIVE_UPLOAD_BASE = "https://www.googleapis.com/upload/drive/v3"
_ALLOWED_URL_PREFIXES = (
    f"{_GMAIL_BASE}/",
    f"{_CALENDAR_BASE}/",
    f"{_DRIVE_BASE}/",
    f"{_DRIVE_UPLOAD_BASE}/",
)

#: A larger bound for the two calls that read actual file content, before it
#: is truncated to :data:`FILE_TEXT_MAX_CHARS`. Every other call keeps the
#: same 64 KiB bound as the rest of the package.
_FILE_MAX_RESPONSE_BYTES = 2 * 1024 * 1024

MAIL_LIMIT_MIN = 1
MAIL_LIMIT_MAX = 10
DEFAULT_MAIL_LIMIT = 10
SEARCH_LIMIT_MIN = 1
SEARCH_LIMIT_MAX = 50
DEFAULT_SEARCH_LIMIT = 20
FILE_TEXT_MAX_CHARS = 20_000

_MAX_TEXT_LENGTH = 200
_PREVIEW_MAX_LENGTH = 255
_CONTROL_CHARS_RE = re.compile(r"[\x00-\x1f\x7f]")

_GOOGLE_DOC_MIME = "application/vnd.google-apps.document"
_PLAIN_TEXT_MIME = "text/plain"
_ROLE_MAP: Mapping[str, str] = {"read": "reader", "write": "writer"}

_GMAIL_WEB_URL_BASE = "https://mail.google.com/mail/#all"
#: T27b — one `users/me/profile` call per read fills `MailHeader.account_address`;
#: a failure here never fails the read (see `_fetch_account_address`).
_GMAIL_PROFILE_URL = f"{_GMAIL_BASE}/profile"


def _gmail_web_url(message_id: str) -> str:
    return f"{_GMAIL_WEB_URL_BASE}/{message_id}" if message_id else ""


def _payload_web_url(payload: Mapping[str, object]) -> str:
    """An event/file's own link, when the response carries one (`htmlLink`/`webViewLink`)."""
    for key in ("htmlLink", "webViewLink"):
        value = payload.get(key)
        if isinstance(value, str):
            return value
    return ""


def _sanitize(value: str, max_length: int) -> str:
    """Strip control characters and cap length; keep the rest verbatim, as data."""
    return _CONTROL_CHARS_RE.sub("", value)[:max_length]


def _is_redirect(status_code: int) -> bool:
    return 300 <= status_code < 400


def _require_google_url(connector: ConnectorConfig, url: str) -> None:
    if not any(url.startswith(prefix) for prefix in _ALLOWED_URL_PREFIXES):
        raise ConnectError(error_text(connector, "generic"), kind="generic")


async def _raw_request(
    connector: ConnectorConfig,
    method: str,
    url: str,
    bundle: TokenBundle,
    client: httpx.AsyncClient,
    *,
    json_body: Mapping[str, object] | None = None,
    data: bytes | None = None,
    content_type: str | None = None,
    max_bytes: int = MAX_RESPONSE_BYTES,
) -> tuple[httpx.Response | None, int]:
    """One bounded, redirect-refusing request. Returns ``(None, 401)`` to retry."""
    _require_google_url(connector, url)
    headers = {"Authorization": f"{bundle.token_type} {bundle.access_token}"}
    if content_type is not None:
        headers["Content-Type"] = content_type
    try:
        response = await client.request(
            method,
            url,
            headers=headers,
            json=dict(json_body) if json_body is not None else None,
            content=data,
            timeout=DEFAULT_TIMEOUT_SECONDS,
            follow_redirects=False,
        )
    except Exception as error:  # noqa: BLE001 - never leak transport internals
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if _is_redirect(response.status_code):
        raise ConnectError(error_text(connector, "generic"), kind="redirect_refused")
    if len(response.content) > max_bytes:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if response.status_code == 401:
        return None, 401
    return response, response.status_code


async def _refresh_and_store_async(
    connector: ConnectorConfig,
    secrets: SecretsPort,
    person: str,
    bundle: TokenBundle,
    client: httpx.AsyncClient,
) -> TokenBundle:
    if bundle.refresh_token is None or bundle.is_refresh_token_expired():
        raise ConnectError(error_text(connector, "needs_reconnect"), kind="needs_reconnect")
    refreshed = await refresh_access_token_async(
        connector,
        secrets,
        refresh_token=bundle.refresh_token,
        client=client,
        previous_account=bundle.account,
    )
    try:
        store_tokens(secrets, connector.name, person, refreshed)
    except TokenStoreError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    return refreshed


async def _load_and_refresh_bundle_async(
    connector: ConnectorConfig, person: str, secrets: SecretsPort, client: httpx.AsyncClient
) -> TokenBundle:
    try:
        bundle = load_tokens(secrets, connector.name, person)
    except TokenStoreError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if bundle is None:
        raise ConnectError(error_text(connector, "denied"), kind="not_connected")
    if bundle.is_access_token_stale(buffer_seconds=PROACTIVE_REFRESH_BUFFER_SECONDS):
        bundle = await _refresh_and_store_async(connector, secrets, person, bundle, client)
    return bundle


async def _request(
    connector: ConnectorConfig,
    person: str,
    method: str,
    url: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
    json_body: Mapping[str, object] | None = None,
    data: bytes | None = None,
    content_type: str | None = None,
    max_bytes: int = MAX_RESPONSE_BYTES,
) -> tuple[httpx.Response, TokenBundle]:
    """Send one request, refreshing and retrying exactly once on a 401."""
    response, status = await _raw_request(
        connector, method, url, bundle, client,
        json_body=json_body, data=data, content_type=content_type, max_bytes=max_bytes,
    )
    if status == 401:
        bundle = await _refresh_and_store_async(connector, secrets, person, bundle, client)
        response, status = await _raw_request(
            connector, method, url, bundle, client,
            json_body=json_body, data=data, content_type=content_type, max_bytes=max_bytes,
        )
        if status == 401:
            raise ConnectError(error_text(connector, "denied"), kind="denied")
    if status >= 400:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if response is None:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return response, bundle


def _json_or_empty(connector: ConnectorConfig, response: httpx.Response) -> dict[str, object]:
    if not response.content:
        return {}
    try:
        payload = response.json()
    except ValueError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if not isinstance(payload, dict):
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return payload


def _decode_text(response: httpx.Response) -> str:
    return response.content.decode("utf-8", errors="replace")


def _parse_int_field(
    connector: ConnectorConfig, payload: Mapping[str, object], name: str
) -> int:
    value = payload.get(name)
    if not isinstance(value, int) or isinstance(value, bool):
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if value < 0:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return value


# --- Gmail --------------------------------------------------------------------


def _header_value(headers: list[object], name: str) -> str | None:
    for header in headers:
        if isinstance(header, dict) and header.get("name") == name:
            value = header.get("value")
            if isinstance(value, str):
                return value
    return None


def _message_headers(payload: Mapping[str, object]) -> list[object]:
    payload_field = payload.get("payload")
    if not isinstance(payload_field, dict):
        return []
    raw_headers = payload_field.get("headers")
    return raw_headers if isinstance(raw_headers, list) else []


def _internal_date_to_iso(value: object) -> str:
    if not isinstance(value, str):
        return ""
    try:
        millis = int(value)
    except ValueError:
        return ""
    return datetime.fromtimestamp(millis / 1000, tz=UTC).isoformat()


def _message_id(item: object) -> str | None:
    if not isinstance(item, dict):
        return None
    value = item.get("id")
    return value if isinstance(value, str) else None


def _message_ids(payload: Mapping[str, object]) -> list[str]:
    raw = payload.get("messages")
    if not isinstance(raw, list):
        return []
    ids = (_message_id(item) for item in raw)
    return [message_id for message_id in ids if message_id is not None]


def _parse_gmail_message(message_id: str, payload: Mapping[str, object]) -> MailHeader:
    headers = _message_headers(payload)
    subject_raw = _header_value(headers, "Subject") or ""
    subject = _sanitize(subject_raw, _MAX_TEXT_LENGTH)
    from_raw = _header_value(headers, "From") or ""
    name, address = parseaddr(from_raw)
    sender = _sanitize(name, _MAX_TEXT_LENGTH) if name else _sanitize(address, _MAX_TEXT_LENGTH)
    sender_address = _sanitize(address, _MAX_TEXT_LENGTH)
    to_raw = _header_value(headers, "To") or ""
    cc_raw = _header_value(headers, "Cc") or ""
    to_addresses = _dedupe_lower(addr for _name, addr in getaddresses([to_raw]) if addr)
    cc_addresses = _dedupe_lower(addr for _name, addr in getaddresses([cc_raw]) if addr)
    snippet_raw = payload.get("snippet")
    preview = _sanitize(snippet_raw, _PREVIEW_MAX_LENGTH) if isinstance(snippet_raw, str) else ""
    received_iso = _internal_date_to_iso(payload.get("internalDate"))
    return MailHeader(
        subject=subject,
        sender=sender,
        received_iso=received_iso,
        id=message_id,
        preview=preview,
        sender_address=sender_address,
        to_addresses=to_addresses,
        cc_addresses=cc_addresses,
    )


def _unread_count_url() -> str:
    return f"{_GMAIL_BASE}/labels/UNREAD"


def _unread_list_url(limit: int) -> str:
    capped = max(MAIL_LIMIT_MIN, min(MAIL_LIMIT_MAX, limit))
    params = {"q": "is:unread", "labelIds": "INBOX", "maxResults": str(capped)}
    return f"{_GMAIL_BASE}/messages?{urlencode(params)}"


def _search_list_url(query: str, limit: int) -> str:
    capped = max(SEARCH_LIMIT_MIN, min(SEARCH_LIMIT_MAX, limit))
    params = {"q": query, "maxResults": str(capped)}
    return f"{_GMAIL_BASE}/messages?{urlencode(params)}"


def _quote_if_multiword(value: str) -> str:
    return f'"{value}"' if " " in value else value


def _build_gmail_query(filters: MailSearchFilters) -> str:
    """Gmail's ``q``: ``from:(sender) subject:(subject) after:Y/M/D before:Y/M/D query``."""
    parts: list[str] = []
    if filters.sender:
        parts.append(f"from:({_quote_if_multiword(filters.sender)})")
    if filters.subject:
        parts.append(f"subject:({_quote_if_multiword(filters.subject)})")
    if filters.after:
        parts.append(f"after:{filters.after.replace('-', '/')}")
    if filters.before:
        parts.append(f"before:{filters.before.replace('-', '/')}")
    if filters.query:
        parts.append(filters.query)
    return " ".join(parts)


def _message_detail_url(message_id: str) -> str:
    params = [
        ("format", "metadata"),
        ("metadataHeaders", "Subject"),
        ("metadataHeaders", "From"),
        ("metadataHeaders", "To"),
        ("metadataHeaders", "Cc"),
    ]
    return f"{_GMAIL_BASE}/messages/{message_id}?{urlencode(params)}"


def _dedupe_lower(addresses: Iterable[str]) -> tuple[str, ...]:
    """Every address, lower-cased and deduped, in the order first seen."""
    seen: set[str] = set()
    result: list[str] = []
    for address in addresses:
        lowered = address.strip().lower()
        if lowered and lowered not in seen:
            seen.add(lowered)
            result.append(lowered)
    return tuple(result)


async def _fetch_account_address(
    connector: ConnectorConfig,
    person: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
) -> str:
    """The signed-in person's own address (``emailAddress``), lower-cased.

    Never raises: a failure of this ``users/me/profile`` call must never fail
    the read that calls it.
    """
    try:
        response, _bundle = await _request(
            connector, person, "GET", _GMAIL_PROFILE_URL, bundle, client=client, secrets=secrets
        )
        payload = _json_or_empty(connector, response)
    except ConnectError:
        return ""
    email_raw = payload.get("emailAddress")
    return email_raw.strip().lower() if isinstance(email_raw, str) and email_raw else ""


async def _fetch_message_headers(
    connector: ConnectorConfig,
    person: str,
    ids: list[str],
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
) -> tuple[tuple[MailHeader, ...], TokenBundle]:
    messages: list[MailHeader] = []
    for message_id in ids:
        response, bundle = await _request(
            connector, person, "GET", _message_detail_url(message_id), bundle,
            client=client, secrets=secrets,
        )
        payload = _json_or_empty(connector, response)
        messages.append(_parse_gmail_message(message_id, payload))
    return tuple(messages), bundle


async def gmail_unread(
    person: str = DEFAULT_PERSON,
    *,
    limit: int = DEFAULT_MAIL_LIMIT,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> UnreadMail:
    """Read ``gmail``'s unread count and up to ``limit`` (capped 1-10) newest unread headers."""
    connector = load_connector("gmail", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
    count_response, bundle = await _request(
        connector, person, "GET", _unread_count_url(), bundle,
        client=client, secrets=secrets_port,
    )
    count_payload = _json_or_empty(connector, count_response)
    count = _parse_int_field(connector, count_payload, "messagesUnread")
    list_response, bundle = await _request(
        connector, person, "GET", _unread_list_url(limit), bundle,
        client=client, secrets=secrets_port,
    )
    ids = _message_ids(_json_or_empty(connector, list_response))
    messages, bundle = await _fetch_message_headers(
        connector, person, ids, bundle, client=client, secrets=secrets_port
    )
    account_address = await _fetch_account_address(
        connector, person, bundle, client=client, secrets=secrets_port
    )
    messages = tuple(replace(header, account_address=account_address) for header in messages)
    return UnreadMail(count=count, messages=messages)


async def gmail_get(
    person: str = DEFAULT_PERSON,
    *,
    message_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> MailHeader:
    """Read one ``gmail`` message by id — for reply-verification re-fetch (T27c).

    Reuses :func:`_fetch_message_headers`'s per-message metadata fetch (Subject/From/
    To/Cc headers, no body) for the one id, plus :func:`_fetch_account_address`.
    ``message_id`` is validated by ``graph_read.is_valid_message_id`` before any
    network call; an invalid id raises ``ConnectError(kind="invalid")``.
    """
    connector = load_connector("gmail", catalog_dir=catalog_dir)
    if not is_valid_message_id(message_id):
        raise ConnectError(error_text(connector, "invalid"), kind="invalid")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,512}", message_id):
        raise ConnectError(error_text(connector, "invalid"), kind="invalid")
    secrets_port = secrets if secrets is not None else default_secrets_port()
    bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
    messages, bundle = await _fetch_message_headers(
        connector, person, [message_id], bundle, client=client, secrets=secrets_port
    )
    if not messages:
        raise ConnectError(error_text(connector, "not_found"), kind="not_found", status=404)
    account_address = await _fetch_account_address(
        connector, person, bundle, client=client, secrets=secrets_port
    )
    return replace(messages[0], account_address=account_address)


async def gmail_search(
    person: str = DEFAULT_PERSON,
    *,
    query: str | None = None,
    sender: str | None = None,
    subject: str | None = None,
    after: str | None = None,
    before: str | None = None,
    limit: int = DEFAULT_SEARCH_LIMIT,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> MailSearch:
    """Search ``gmail`` by sender, subject, a date range, and/or free words, newest first.

    Same filter rules as :func:`gates.graph_read.search_mail`: at least one of
    ``query``/``sender``/``subject``/``after``/``before`` must be given (non-empty after
    strip) or this raises ``ValueError``; ``after``/``before`` are ``YYYY-MM-DD``.
    Messages are filtered to that range again after the fetch (belt and braces) and
    returned newest first by ``received_iso``.
    """
    filters = validate_mail_search_filters(
        query=query, sender=sender, subject=subject, after=after, before=before
    )
    connector = load_connector("gmail", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
    list_response, bundle = await _request(
        connector, person, "GET", _search_list_url(_build_gmail_query(filters), limit), bundle,
        client=client, secrets=secrets_port,
    )
    list_payload = _json_or_empty(connector, list_response)
    ids = _message_ids(list_payload)
    messages, bundle = await _fetch_message_headers(
        connector, person, ids, bundle, client=client, secrets=secrets_port
    )
    messages = filter_and_sort_search_results(
        filter_by_sender(messages, filters.sender), after=filters.after, before=filters.before
    )
    account_address = await _fetch_account_address(
        connector, person, bundle, client=client, secrets=secrets_port
    )
    messages = tuple(replace(header, account_address=account_address) for header in messages)
    truncated = isinstance(list_payload.get("nextPageToken"), str)
    return MailSearch(messages=messages, truncated=truncated)


def _build_rfc2822_message(
    *,
    to: tuple[str, ...],
    subject: str,
    body: str,
    body_html: str | None = None,
    cc: tuple[str, ...] = (),
    in_reply_to: str | None = None,
    references: str | None = None,
) -> str:
    """Build one RFC 2822 message; ``body_html`` (T43, decisions #139/#150), when given,
    makes this ``multipart/alternative`` (``text/plain`` = ``body``, ``text/html`` =
    ``body_html``, UTF-8) instead of the plain single ``text/plain`` part.
    """
    message = EmailMessage()
    message["To"] = ", ".join(to)
    if cc:
        message["Cc"] = ", ".join(cc)
    message["Subject"] = subject
    if in_reply_to:
        message["In-Reply-To"] = in_reply_to
    if references:
        message["References"] = references
    message.set_content(body)
    if body_html is not None:
        message.add_alternative(body_html, subtype="html")
    return message.as_string()


def _encode_raw_message(text: str) -> str:
    return base64.urlsafe_b64encode(text.encode("utf-8")).decode("ascii")


async def gmail_send(
    person: str = DEFAULT_PERSON,
    *,
    to: tuple[str, ...],
    subject: str,
    body: str,
    body_html: str | None = None,
    cc: tuple[str, ...] = (),
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Send a new message through ``gmail``.

    ``body_html`` (T43, decisions #139/#150), when given, makes the sent message
    ``multipart/alternative`` (``text/plain`` = ``body``, ``text/html`` =
    ``body_html``) — sent as given, never built, sanitized or re-escaped here.
    ``body_html=None`` keeps today's single ``text/plain`` message byte for byte.
    """
    connector = load_connector("gmail", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    mail_format: Literal["html", "text"] = "html" if body_html is not None else "text"
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "send_mail", "started", operation_id, mail_format=mail_format
        )
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        raw = _encode_raw_message(
            _build_rfc2822_message(to=to, subject=subject, body=body, body_html=body_html, cc=cc)
        )
        response, _bundle = await _request(
            connector, person, "POST", f"{_GMAIL_BASE}/messages/send", bundle,
            client=client, secrets=secrets_port, json_body={"raw": raw},
        )
        payload = _json_or_empty(connector, response)
        message_id_raw = payload.get("id")
        message_id = message_id_raw if isinstance(message_id_raw, str) else ""
        result = WriteResult(ok=True, id=message_id, web_url=_gmail_web_url(message_id))
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "send_mail", "failed", operation_id,
                mail_format=mail_format,
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "send_mail", "succeeded", operation_id,
            mail_format=mail_format,
        )
    return result


def _reply_context_url(message_id: str) -> str:
    params = [
        ("format", "metadata"),
        ("metadataHeaders", "Subject"),
        ("metadataHeaders", "From"),
        ("metadataHeaders", "To"),
        ("metadataHeaders", "Cc"),
        ("metadataHeaders", "Message-ID"),
        ("metadataHeaders", "References"),
    ]
    return f"{_GMAIL_BASE}/messages/{message_id}?{urlencode(params)}"


@dataclass(frozen=True)
class _ReplyContext:
    subject: str
    reply_to: str
    message_rfc_id: str
    references: str
    thread_id: str


def _reply_context(payload: Mapping[str, object]) -> _ReplyContext:
    headers = _message_headers(payload)
    subject_raw = _header_value(headers, "Subject") or ""
    subject = subject_raw if subject_raw.lower().startswith("re:") else f"Re: {subject_raw}"
    from_raw = _header_value(headers, "From") or ""
    _name, reply_to = parseaddr(from_raw)
    message_rfc_id = _header_value(headers, "Message-ID") or ""
    references_raw = _header_value(headers, "References") or ""
    references = references_raw
    if message_rfc_id:
        references = f"{references_raw} {message_rfc_id}".strip()
    thread_id_raw = payload.get("threadId")
    thread_id = thread_id_raw if isinstance(thread_id_raw, str) else ""
    return _ReplyContext(
        subject=subject,
        reply_to=reply_to,
        message_rfc_id=message_rfc_id,
        references=references,
        thread_id=thread_id,
    )


async def gmail_reply(
    person: str = DEFAULT_PERSON,
    *,
    message_id: str,
    body: str,
    body_html: str | None = None,
    reply_all: bool = False,
    to: Sequence[str] | None = None,
    cc: Sequence[str] | None = None,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Reply to ``message_id``, keeping its thread, ``In-Reply-To`` and ``References``.

    ``reply_all=True`` requires a non-empty ``to`` — checked before any network
    call — and the sent message's To/Cc are exactly ``to``/``cc`` (``cc`` None
    means empty), never recomputed from the original message's own To/Cc
    headers. ``reply_all=False`` is unchanged: it replies only to the original
    sender and ``to``/``cc`` are ignored. ``body_html`` (T43, decisions #139/
    #150), when given, makes the sent reply ``multipart/alternative``
    (``text/plain`` = ``body``, ``text/html`` = ``body_html``), threading
    headers unchanged; sent as given, never built, sanitized or re-escaped
    here. ``body_html=None`` keeps today's single ``text/plain`` reply byte for
    byte.
    """
    connector = load_connector("gmail", catalog_dir=catalog_dir)
    if reply_all and not to:
        raise ConnectError(error_text(connector, "invalid"), kind="invalid")
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    mail_format: Literal["html", "text"] = "html" if body_html is not None else "text"
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "reply_mail", "started", operation_id, mail_format=mail_format
        )
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        detail_response, bundle = await _request(
            connector, person, "GET", _reply_context_url(message_id), bundle,
            client=client, secrets=secrets_port,
        )
        context = _reply_context(_json_or_empty(connector, detail_response))
        if reply_all:
            to_addresses: tuple[str, ...] = tuple(to) if to else ()
            cc_addresses: tuple[str, ...] = tuple(cc) if cc else ()
        else:
            to_addresses = (context.reply_to,)
            cc_addresses = ()
        raw = _encode_raw_message(
            _build_rfc2822_message(
                to=to_addresses,
                subject=context.subject,
                body=body,
                body_html=body_html,
                cc=cc_addresses,
                in_reply_to=context.message_rfc_id or None,
                references=context.references or None,
            )
        )
        json_body: dict[str, object] = {"raw": raw}
        if context.thread_id:
            json_body["threadId"] = context.thread_id
        response, _bundle = await _request(
            connector, person, "POST", f"{_GMAIL_BASE}/messages/send", bundle,
            client=client, secrets=secrets_port, json_body=json_body,
        )
        payload = _json_or_empty(connector, response)
        sent_id_raw = payload.get("id")
        sent_id = sent_id_raw if isinstance(sent_id_raw, str) else ""
        result = WriteResult(ok=True, id=sent_id, web_url=_gmail_web_url(sent_id))
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "reply_mail", "failed", operation_id,
                mail_format=mail_format,
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "reply_mail", "succeeded", operation_id,
            mail_format=mail_format,
        )
    return result


async def _resolve_gmail_label(
    connector: ConnectorConfig,
    person: str,
    name: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
) -> tuple[str, TokenBundle]:
    response, bundle = await _request(
        connector, person, "GET", f"{_GMAIL_BASE}/labels", bundle, client=client, secrets=secrets
    )
    payload = _json_or_empty(connector, response)
    labels = payload.get("labels")
    if isinstance(labels, list):
        for label in labels:
            if not isinstance(label, dict) or label.get("name") != name:
                continue
            label_id = label.get("id")
            if isinstance(label_id, str):
                return label_id, bundle
    raise ConnectError(error_text(connector, "generic"), kind="generic")


async def gmail_move(
    person: str = DEFAULT_PERSON,
    *,
    message_id: str,
    folder: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Move ``message_id``: ``archive`` removes INBOX, ``trash``/``inbox``, or a label name.

    ``WriteResult.previous_folder`` is a comma-joined list of the labels this
    call removed (``archive``/``trash`` remove ``INBOX``; ``inbox`` and adding
    a label remove nothing).
    """
    connector = load_connector("gmail", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "move_mail", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        normalized = folder.strip().lower()
        removed_labels: tuple[str, ...] = ()
        if normalized == "trash":
            response, _bundle = await _request(
                connector, person, "POST", f"{_GMAIL_BASE}/messages/{message_id}/trash", bundle,
                client=client, secrets=secrets_port,
            )
            removed_labels = ("INBOX",)
        elif normalized == "archive":
            response, _bundle = await _request(
                connector, person, "POST", f"{_GMAIL_BASE}/messages/{message_id}/modify", bundle,
                client=client, secrets=secrets_port, json_body={"removeLabelIds": ["INBOX"]},
            )
            removed_labels = ("INBOX",)
        elif normalized == "inbox":
            # Undoing a `trash` move calls this with `folder="inbox"`; the message
            # is still in Trash, so adding the INBOX label alone would not move it
            # back out. Untrash first, then label.
            _untrash_response, bundle = await _request(
                connector, person, "POST", f"{_GMAIL_BASE}/messages/{message_id}/untrash", bundle,
                client=client, secrets=secrets_port,
            )
            response, _bundle = await _request(
                connector, person, "POST", f"{_GMAIL_BASE}/messages/{message_id}/modify", bundle,
                client=client, secrets=secrets_port, json_body={"addLabelIds": ["INBOX"]},
            )
        else:
            label_id, bundle = await _resolve_gmail_label(
                connector, person, folder, bundle, client=client, secrets=secrets_port
            )
            response, _bundle = await _request(
                connector, person, "POST", f"{_GMAIL_BASE}/messages/{message_id}/modify", bundle,
                client=client, secrets=secrets_port, json_body={"addLabelIds": [label_id]},
            )
        payload = _json_or_empty(connector, response)
        result_id = payload.get("id")
        result = WriteResult(
            ok=True,
            id=result_id if isinstance(result_id, str) else message_id,
            previous_folder=",".join(removed_labels),
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "move_mail", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "move_mail", "succeeded", operation_id)
    return result


# --- Google Calendar ------------------------------------------------------------


def _calendar_events_url(start: datetime, end: datetime) -> str:
    params = {
        "timeMin": start.isoformat(),
        "timeMax": end.isoformat(),
        "singleEvents": "true",
        "orderBy": "startTime",
    }
    return f"{_CALENDAR_BASE}/calendars/primary/events?{urlencode(params)}"


def _attendee_email(entry: object) -> str | None:
    if not isinstance(entry, dict):
        return None
    value = entry.get("email")
    return value if isinstance(value, str) else None


def _parse_gcal_event(item: object) -> CalendarEvent | None:
    if not isinstance(item, dict) or item.get("status") == "cancelled":
        return None
    start = item.get("start")
    end = item.get("end")
    if not isinstance(start, dict) or not isinstance(end, dict):
        return None
    all_day = "date" in start and "dateTime" not in start
    start_iso = start.get("dateTime") or start.get("date")
    end_iso = end.get("dateTime") or end.get("date")
    if not isinstance(start_iso, str) or not isinstance(end_iso, str):
        return None
    subject_raw = item.get("summary")
    subject = _sanitize(subject_raw, _MAX_TEXT_LENGTH) if isinstance(subject_raw, str) else ""
    location_raw = item.get("location")
    location = _sanitize(location_raw, _MAX_TEXT_LENGTH) if isinstance(location_raw, str) else ""
    attendees_raw = item.get("attendees")
    attendees: tuple[str, ...] = ()
    if isinstance(attendees_raw, list):
        emails = (_attendee_email(entry) for entry in attendees_raw)
        attendees = tuple(email for email in emails if email is not None)
    event_id_raw = item.get("id")
    event_id = event_id_raw if isinstance(event_id_raw, str) else ""
    return CalendarEvent(
        start_iso=start_iso,
        end_iso=end_iso,
        subject=subject,
        all_day=all_day,
        id=event_id,
        location=location,
        attendees=attendees,
    )


async def gcal_today(
    person: str = DEFAULT_PERSON,
    *,
    start: datetime,
    end: datetime,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> CalendarDay:
    """Read ``google-calendar``'s events for ``[start, end)``. Drops cancelled events."""
    connector = load_connector("google-calendar", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
    response, _bundle = await _request(
        connector, person, "GET", _calendar_events_url(start, end), bundle,
        client=client, secrets=secrets_port,
    )
    payload = _json_or_empty(connector, response)
    raw_items = payload.get("items")
    items = raw_items if isinstance(raw_items, list) else []
    parsed = (_parse_gcal_event(item) for item in items)
    events = tuple(event for event in parsed if event is not None)
    truncated = isinstance(payload.get("nextPageToken"), str)
    return CalendarDay(events=events, truncated=truncated)


def _event_body(
    *,
    subject: str | None = None,
    start_iso: str | None = None,
    end_iso: str | None = None,
    attendees: tuple[str, ...] | None = None,
    location: str | None = None,
    body: str | None = None,
) -> dict[str, object]:
    payload: dict[str, object] = {}
    if subject is not None:
        payload["summary"] = subject
    if start_iso is not None:
        payload["start"] = {"dateTime": start_iso}
    if end_iso is not None:
        payload["end"] = {"dateTime": end_iso}
    if location is not None:
        payload["location"] = location
    if body is not None:
        payload["description"] = body
    if attendees is not None:
        payload["attendees"] = [{"email": address} for address in attendees]
    return payload


async def gcal_create(
    person: str = DEFAULT_PERSON,
    *,
    subject: str,
    start_iso: str,
    end_iso: str,
    attendees: tuple[str, ...] = (),
    location: str = "",
    body: str = "",
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Create one event on ``google-calendar``'s primary calendar."""
    connector = load_connector("google-calendar", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "create_event", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        payload = _event_body(
            subject=subject, start_iso=start_iso, end_iso=end_iso,
            attendees=attendees, location=location, body=body,
        )
        response, _bundle = await _request(
            connector, person, "POST", f"{_CALENDAR_BASE}/calendars/primary/events", bundle,
            client=client, secrets=secrets_port, json_body=payload,
        )
        result_payload = _json_or_empty(connector, response)
        event_id = result_payload.get("id")
        result = WriteResult(
            ok=True,
            id=event_id if isinstance(event_id, str) else "",
            web_url=_payload_web_url(result_payload),
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "create_event", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "create_event", "succeeded", operation_id)
    return result


async def gcal_update(
    person: str = DEFAULT_PERSON,
    *,
    event_id: str,
    subject: str | None = None,
    start_iso: str | None = None,
    end_iso: str | None = None,
    attendees: tuple[str, ...] | None = None,
    location: str | None = None,
    body: str | None = None,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Patch only the given fields of ``event_id`` on the primary calendar."""
    connector = load_connector("google-calendar", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "update_event", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        payload = _event_body(
            subject=subject, start_iso=start_iso, end_iso=end_iso,
            attendees=attendees, location=location, body=body,
        )
        url = f"{_CALENDAR_BASE}/calendars/primary/events/{event_id}"
        response, _bundle = await _request(
            connector, person, "PATCH", url, bundle,
            client=client, secrets=secrets_port, json_body=payload,
        )
        result_payload = _json_or_empty(connector, response)
        result = WriteResult(ok=True, id=event_id, web_url=_payload_web_url(result_payload))
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "update_event", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "update_event", "succeeded", operation_id)
    return result


async def gcal_delete(
    person: str = DEFAULT_PERSON,
    *,
    event_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Delete ``event_id`` from the primary calendar."""
    connector = load_connector("google-calendar", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_event", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        url = f"{_CALENDAR_BASE}/calendars/primary/events/{event_id}"
        response, _bundle = await _request(
            connector, person, "DELETE", url, bundle, client=client, secrets=secrets_port,
        )
        _json_or_empty(connector, response)
        result = WriteResult(ok=True, id=event_id)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "delete_event", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_event", "succeeded", operation_id)
    return result


# --- Google Drive ---------------------------------------------------------------


def _drive_query_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace("'", "\\'")


def _drive_search_url(query: str, limit: int) -> str:
    capped = max(SEARCH_LIMIT_MIN, min(SEARCH_LIMIT_MAX, limit))
    params = {
        "q": query,
        "pageSize": str(capped),
        "fields": "files(id,name,webViewLink,modifiedTime,size),nextPageToken",
    }
    return f"{_DRIVE_BASE}/files?{urlencode(params)}"


def _parse_file_item(item: object) -> FileItem | None:
    if not isinstance(item, dict):
        return None
    item_id = item.get("id")
    name = item.get("name")
    if not isinstance(item_id, str) or not isinstance(name, str):
        return None
    web_url_raw = item.get("webViewLink")
    web_url = web_url_raw if isinstance(web_url_raw, str) else ""
    modified_raw = item.get("modifiedTime")
    modified_iso = modified_raw if isinstance(modified_raw, str) else ""
    size_raw = item.get("size")
    size = int(size_raw) if isinstance(size_raw, str) and size_raw.isdigit() else 0
    return FileItem(
        id=item_id,
        name=_sanitize(name, _MAX_TEXT_LENGTH),
        path="",
        web_url=web_url,
        modified_iso=modified_iso,
        size=size,
    )


async def drive_search(
    person: str = DEFAULT_PERSON,
    *,
    query: str,
    limit: int = DEFAULT_SEARCH_LIMIT,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> FileList:
    """Search ``google-drive`` files matching ``query``.

    Drive files have no single hierarchical path field (a file can have
    multiple parents); every returned :class:`FileItem` has ``path=""``.
    """
    connector = load_connector("google-drive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
    response, _bundle = await _request(
        connector, person, "GET", _drive_search_url(query, limit), bundle,
        client=client, secrets=secrets_port,
    )
    payload = _json_or_empty(connector, response)
    raw_items = payload.get("files")
    items_iterable = raw_items if isinstance(raw_items, list) else []
    parsed = (_parse_file_item(item) for item in items_iterable)
    items = tuple(item for item in parsed if item is not None)
    truncated = isinstance(payload.get("nextPageToken"), str)
    return FileList(items=items, truncated=truncated)


def _drive_metadata_url(item_id: str) -> str:
    params = {"fields": "id,name,mimeType"}
    return f"{_DRIVE_BASE}/files/{item_id}?{urlencode(params)}"


def _drive_export_url(item_id: str) -> str:
    params = {"mimeType": _PLAIN_TEXT_MIME}
    return f"{_DRIVE_BASE}/files/{item_id}/export?{urlencode(params)}"


def _drive_media_url(item_id: str) -> str:
    return f"{_DRIVE_BASE}/files/{item_id}?alt=media"


async def drive_read_text(
    person: str = DEFAULT_PERSON,
    *,
    item_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> FileText:
    """Read up to :data:`FILE_TEXT_MAX_CHARS` of ``item_id`` as plain text.

    A Google Doc is exported as ``text/plain``; a plain-text file is
    downloaded as is. Any other type (``.docx``, ``.pdf``, other Google
    Workspace types) has no text export the Drive API offers here, so this
    returns ``truncated=True, text=""``.
    """
    connector = load_connector("google-drive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
    meta_response, bundle = await _request(
        connector, person, "GET", _drive_metadata_url(item_id), bundle,
        client=client, secrets=secrets_port,
    )
    meta_payload = _json_or_empty(connector, meta_response)
    name_raw = meta_payload.get("name")
    name = _sanitize(name_raw, _MAX_TEXT_LENGTH) if isinstance(name_raw, str) else ""
    mime_type = meta_payload.get("mimeType")
    if mime_type == _GOOGLE_DOC_MIME:
        text_response, _bundle = await _request(
            connector, person, "GET", _drive_export_url(item_id), bundle,
            client=client, secrets=secrets_port, max_bytes=_FILE_MAX_RESPONSE_BYTES,
        )
        text = _decode_text(text_response)
    elif mime_type == _PLAIN_TEXT_MIME:
        text_response, _bundle = await _request(
            connector, person, "GET", _drive_media_url(item_id), bundle,
            client=client, secrets=secrets_port, max_bytes=_FILE_MAX_RESPONSE_BYTES,
        )
        text = _decode_text(text_response)
    else:
        return FileText(id=item_id, name=name, text="", truncated=True)
    if len(text) > FILE_TEXT_MAX_CHARS:
        return FileText(id=item_id, name=name, text=text[:FILE_TEXT_MAX_CHARS], truncated=True)
    return FileText(id=item_id, name=name, text=text, truncated=False)


def _multipart_body(
    metadata: Mapping[str, object], content: str, mime_type: str
) -> tuple[bytes, str]:
    boundary = "oasis-drive-upload-boundary"
    metadata_json = json.dumps(dict(metadata))
    parts = (
        f"--{boundary}\r\n"
        "Content-Type: application/json; charset=UTF-8\r\n\r\n"
        f"{metadata_json}\r\n"
        f"--{boundary}\r\n"
        f"Content-Type: {mime_type}\r\n\r\n"
        f"{content}\r\n"
        f"--{boundary}--"
    )
    return parts.encode("utf-8"), boundary


async def _get_or_create_drive_folder(
    connector: ConnectorConfig,
    person: str,
    name: str,
    parent: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
) -> tuple[str, TokenBundle]:
    escaped = _drive_query_escape(name)
    query = (
        f"name = '{escaped}' and '{parent}' in parents "
        "and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
    )
    url = f"{_DRIVE_BASE}/files?{urlencode({'q': query, 'fields': 'files(id)'})}"
    response, bundle = await _request(
        connector, person, "GET", url, bundle, client=client, secrets=secrets
    )
    payload = _json_or_empty(connector, response)
    files = payload.get("files")
    if isinstance(files, list) and files:
        first = files[0]
        if isinstance(first, dict) and isinstance(first.get("id"), str):
            return first["id"], bundle
    folder_metadata = {
        "name": name,
        "mimeType": "application/vnd.google-apps.folder",
        "parents": [parent],
    }
    create_response, bundle = await _request(
        connector, person, "POST", f"{_DRIVE_BASE}/files", bundle,
        client=client, secrets=secrets, json_body=folder_metadata,
    )
    create_payload = _json_or_empty(connector, create_response)
    new_id = create_payload.get("id")
    if not isinstance(new_id, str):
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return new_id, bundle


async def _resolve_drive_folder(
    connector: ConnectorConfig,
    person: str,
    folder_path: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
) -> tuple[str, TokenBundle]:
    segments = [segment for segment in folder_path.strip("/").split("/") if segment]
    parent = "root"
    for segment in segments:
        parent, bundle = await _get_or_create_drive_folder(
            connector, person, segment, parent, bundle, client=client, secrets=secrets
        )
    return parent, bundle


async def drive_create(
    person: str = DEFAULT_PERSON,
    *,
    name: str,
    folder_path: str,
    text: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Create a plain-text file named ``name`` under ``folder_path`` (created if missing)."""
    connector = load_connector("google-drive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "create_file", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        folder_id, bundle = await _resolve_drive_folder(
            connector, person, folder_path, bundle, client=client, secrets=secrets_port
        )
        metadata = {"name": name, "parents": [folder_id], "mimeType": _PLAIN_TEXT_MIME}
        body, boundary = _multipart_body(metadata, text, _PLAIN_TEXT_MIME)
        response, _bundle = await _request(
            connector, person, "POST", f"{_DRIVE_UPLOAD_BASE}/files?uploadType=multipart", bundle,
            client=client, secrets=secrets_port, data=body,
            content_type=f"multipart/related; boundary={boundary}",
        )
        payload = _json_or_empty(connector, response)
        file_id = payload.get("id")
        result = WriteResult(
            ok=True,
            id=file_id if isinstance(file_id, str) else "",
            web_url=_payload_web_url(payload),
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "create_file", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "create_file", "succeeded", operation_id)
    return result


async def drive_move(
    person: str = DEFAULT_PERSON,
    *,
    item_id: str,
    folder_path: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Move ``item_id`` to ``folder_path`` (created if missing), replacing its parents."""
    connector = load_connector("google-drive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "move_file", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        new_parent, bundle = await _resolve_drive_folder(
            connector, person, folder_path, bundle, client=client, secrets=secrets_port
        )
        parents_response, bundle = await _request(
            connector, person, "GET", f"{_DRIVE_BASE}/files/{item_id}?fields=parents", bundle,
            client=client, secrets=secrets_port,
        )
        parents_payload = _json_or_empty(connector, parents_response)
        old_parents_raw = parents_payload.get("parents")
        old_parents = (
            tuple(p for p in old_parents_raw if isinstance(p, str))
            if isinstance(old_parents_raw, list)
            else ()
        )
        params = {"addParents": new_parent, "fields": "id,webViewLink"}
        if old_parents:
            params["removeParents"] = ",".join(old_parents)
        url = f"{_DRIVE_BASE}/files/{item_id}?{urlencode(params)}"
        response, _bundle = await _request(
            connector, person, "PATCH", url, bundle,
            client=client, secrets=secrets_port, json_body={},
        )
        result_payload = _json_or_empty(connector, response)
        result = WriteResult(ok=True, id=item_id, web_url=_payload_web_url(result_payload))
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "move_file", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "move_file", "succeeded", operation_id)
    return result


async def drive_share(
    person: str = DEFAULT_PERSON,
    *,
    item_id: str,
    emails: tuple[str, ...],
    role: Literal["read", "write"],
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Share ``item_id`` with each address in ``emails`` at ``role`` (read or write)."""
    connector = load_connector("google-drive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "share_file", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        mapped_role = _ROLE_MAP.get(role, "reader")
        for address in emails:
            response, bundle = await _request(
                connector, person, "POST", f"{_DRIVE_BASE}/files/{item_id}/permissions", bundle,
                client=client, secrets=secrets_port,
                json_body={"type": "user", "role": mapped_role, "emailAddress": address},
            )
            _json_or_empty(connector, response)
        result = WriteResult(ok=True, id=item_id, detail=f"shared with {len(emails)} people")
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "share_file", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "share_file", "succeeded", operation_id)
    return result


async def drive_delete(
    person: str = DEFAULT_PERSON,
    *,
    item_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Move ``item_id`` to trash."""
    connector = load_connector("google-drive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_file", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        response, _bundle = await _request(
            connector, person, "PATCH", f"{_DRIVE_BASE}/files/{item_id}", bundle,
            client=client, secrets=secrets_port, json_body={"trashed": True},
        )
        _json_or_empty(connector, response)
        result = WriteResult(ok=True, id=item_id)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "delete_file", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_file", "succeeded", operation_id)
    return result
