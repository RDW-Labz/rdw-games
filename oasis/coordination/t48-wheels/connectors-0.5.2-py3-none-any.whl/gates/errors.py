"""Plain-words error copy and the one exception the flow raises for people.

``ConnectError`` is the only error type that crosses from the OAuth/network
internals back to the UI-facing layer. Its message is always plain words
pulled from the connector's own ``errors`` block (never a raw exception,
token, code, or URL); ``kind`` is a small fixed vocabulary a caller can key
UI treatment off without parsing text.
"""

from __future__ import annotations

from gates.catalog import ConnectorConfig

_FALLBACK = "{display_name} said no. Try again or ask Braden."


class ConnectError(Exception):
    """A connect/refresh/test step failed. ``args[0]`` is plain words.

    ``status`` and ``graph_code`` are optional, keyword-only, and default to
    ``None`` so every existing ``ConnectError(message, kind=...)`` call stays
    valid. When set, ``status`` is the HTTP status a provider returned and
    ``graph_code`` is its own vendor error code — never ``error.message`` or
    any other body text.
    """

    def __init__(
        self, message: str, *, kind: str, status: int | None = None, graph_code: str | None = None
    ) -> None:
        super().__init__(message)
        self.kind = kind
        self.status = status
        self.graph_code = graph_code


def error_text(connector: ConnectorConfig, kind: str) -> str:
    """The connector's plain-words copy for ``kind``, falling back to generic."""
    text = connector.errors.get(kind)
    if text is not None:
        return text
    generic = connector.errors.get("generic")
    if generic is not None:
        return generic
    return _FALLBACK.format(display_name=connector.display_name)
