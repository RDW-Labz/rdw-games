"""Generic OAuth 2.0 authorization-code + PKCE HTTP calls, provider-agnostic.

Google and Microsoft both speak standard OAuth 2.0 at the endpoints declared
in each connector's ``oauth`` block; the only provider-specific behaviour is
Google's ``access_type=offline`` + ``prompt=consent`` pair, needed to
guarantee a refresh token is issued.

Security rules enforced here, uniformly for every provider:

* Every provider response is DATA, never instructions — only a handful of
  known field names (``access_token``, ``refresh_token``, ``token_type``,
  ``expires_in``, ``scope``) are ever read out of a JSON body.
* Redirects from a token endpoint are refused outright.
* Responses are bounded in size.
* Every failure surfaces as a :class:`~gates.errors.ConnectError` carrying
  only the connector's own plain-words copy — never a raw body, header,
  exception message, token, or code.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from urllib.parse import urlencode

import httpx

from gates.catalog import ConnectorConfig
from gates.errors import ConnectError, error_text
from gates.pkce import PkcePair
from gates.secrets_port import SecretsPort
from gates.tokens import TokenBundle

MAX_RESPONSE_BYTES = 64 * 1024
DEFAULT_TIMEOUT_SECONDS = 15.0
_DEFAULT_EXPIRES_IN_SECONDS = 3600


class Unauthorized(Exception):
    """The connection test call came back 401: the access token is no good."""


def _client_id(connector: ConnectorConfig, secrets: SecretsPort) -> str:
    return secrets.get(connector.oauth.client_id_config_key).reveal()


def _client_secret(connector: ConnectorConfig, secrets: SecretsPort) -> str | None:
    key = connector.oauth.client_secret_config_key
    if key is None:
        return None
    return secrets.get(key).reveal()


def _tenant_id(connector: ConnectorConfig, secrets: SecretsPort) -> str:
    key = connector.oauth.tenant_id_config_key
    if key is None:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return secrets.get(key).reveal()


def _fill_tenant(connector: ConnectorConfig, secrets: SecretsPort, endpoint: str) -> str:
    if "{tenant_id}" not in endpoint:
        return endpoint
    return endpoint.format(tenant_id=_tenant_id(connector, secrets))


def _is_redirect(status_code: int) -> bool:
    return 300 <= status_code < 400


def build_authorize_url(
    connector: ConnectorConfig,
    secrets: SecretsPort,
    *,
    state: str,
    pkce: PkcePair,
    redirect_uri: str,
) -> str:
    """Build the consent-page URL to open in the system browser."""
    params = {
        "client_id": _client_id(connector, secrets),
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": " ".join(connector.scopes),
        "state": state,
        "code_challenge": pkce.challenge,
        "code_challenge_method": pkce.method,
    }
    if connector.provider == "google":
        # Guarantees a refresh_token even on a repeat consent (Testing mode
        # re-issues one every 7 days once the prior one expires).
        params["access_type"] = "offline"
        params["prompt"] = "consent"
    endpoint = _fill_tenant(connector, secrets, connector.oauth.authorization_endpoint)
    return f"{endpoint}?{urlencode(params)}"


def _bounded_json(connector: ConnectorConfig, response: httpx.Response) -> dict[str, object]:
    if _is_redirect(response.status_code):
        raise ConnectError(error_text(connector, "generic"), kind="redirect_refused")
    if len(response.content) > MAX_RESPONSE_BYTES:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    try:
        payload = response.json()
    except ValueError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if not isinstance(payload, dict):
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return payload


def _post_token_request(
    connector: ConnectorConfig,
    client: httpx.Client,
    token_endpoint: str,
    fields: dict[str, str],
    *,
    deny_kind: str,
) -> dict[str, object]:
    try:
        response = client.post(
            token_endpoint, data=fields, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
        )
    except Exception as error:  # noqa: BLE001 - never leak transport internals
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    payload = _bounded_json(connector, response)
    if response.status_code >= 400 or "access_token" not in payload:
        raise ConnectError(error_text(connector, deny_kind), kind=deny_kind)
    return payload


def _bundle_from_payload(
    connector: ConnectorConfig,
    payload: dict[str, object],
    *,
    previous_refresh_token: str | None,
    previous_account: str | None = None,
) -> TokenBundle:
    access_token = payload.get("access_token")
    if not isinstance(access_token, str) or not access_token:
        raise ConnectError(error_text(connector, "denied"), kind="denied")
    refresh_token_raw = payload.get("refresh_token")
    refresh_token = (
        refresh_token_raw
        if isinstance(refresh_token_raw, str) and refresh_token_raw
        else previous_refresh_token
    )
    token_type_raw = payload.get("token_type")
    token_type = token_type_raw if isinstance(token_type_raw, str) and token_type_raw else "Bearer"
    expires_in_raw = payload.get("expires_in")
    expires_in = (
        expires_in_raw
        if isinstance(expires_in_raw, int) and expires_in_raw > 0
        else _DEFAULT_EXPIRES_IN_SECONDS
    )
    scope_raw = payload.get("scope")
    scope = scope_raw if isinstance(scope_raw, str) and scope_raw else " ".join(connector.scopes)
    now = datetime.now(UTC)
    refresh_expires_at = (
        now + timedelta(days=connector.oauth.refresh_ttl_days)
        if connector.oauth.refresh_ttl_days is not None
        else None
    )
    return TokenBundle(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type=token_type,
        expires_at=now + timedelta(seconds=expires_in),
        obtained_at=now,
        scope=scope,
        refresh_expires_at=refresh_expires_at,
        account=previous_account,
    )


def exchange_code(
    connector: ConnectorConfig,
    secrets: SecretsPort,
    *,
    code: str,
    code_verifier: str,
    redirect_uri: str,
    client: httpx.Client,
) -> TokenBundle:
    """Exchange an authorization code for a fresh :class:`TokenBundle`."""
    token_endpoint = _fill_tenant(connector, secrets, connector.oauth.token_endpoint)
    fields = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri,
        "client_id": _client_id(connector, secrets),
        "code_verifier": code_verifier,
    }
    secret = _client_secret(connector, secrets)
    if secret is not None:
        fields["client_secret"] = secret
    payload = _post_token_request(connector, client, token_endpoint, fields, deny_kind="denied")
    return _bundle_from_payload(connector, payload, previous_refresh_token=None)


def refresh_access_token(
    connector: ConnectorConfig,
    secrets: SecretsPort,
    *,
    refresh_token: str,
    client: httpx.Client,
    previous_account: str | None = None,
) -> TokenBundle:
    """Silently exchange a refresh token for a fresh :class:`TokenBundle`.

    ``previous_account`` (T44, decision #161) carries the prior bundle's
    account label forward: a refresh never fetches or changes it.
    """
    token_endpoint = _fill_tenant(connector, secrets, connector.oauth.token_endpoint)
    fields = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": _client_id(connector, secrets),
    }
    secret = _client_secret(connector, secrets)
    if secret is not None:
        fields["client_secret"] = secret
    payload = _post_token_request(connector, client, token_endpoint, fields, deny_kind="expired")
    return _bundle_from_payload(
        connector, payload, previous_refresh_token=refresh_token, previous_account=previous_account
    )


async def _post_token_request_async(
    connector: ConnectorConfig,
    client: httpx.AsyncClient,
    token_endpoint: str,
    fields: dict[str, str],
    *,
    deny_kind: str,
) -> dict[str, object]:
    try:
        response = await client.post(
            token_endpoint, data=fields, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
        )
    except Exception as error:  # noqa: BLE001 - never leak transport internals
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    payload = _bounded_json(connector, response)
    if response.status_code >= 400 or "access_token" not in payload:
        raise ConnectError(error_text(connector, deny_kind), kind=deny_kind)
    return payload


async def refresh_access_token_async(
    connector: ConnectorConfig,
    secrets: SecretsPort,
    *,
    refresh_token: str,
    client: httpx.AsyncClient,
    previous_account: str | None = None,
) -> TokenBundle:
    """Async twin of :func:`refresh_access_token`, for callers already on an event loop.

    Kept silent the same way: no prompt, no browser, plain-words
    :class:`ConnectError` only. Callers that also need to talk to a
    keychain-backed :class:`SecretsPort` do so synchronously themselves —
    this function only moves the network call off the event loop's blocking
    path. ``previous_account`` (T44, decision #161) carries the prior
    bundle's account label forward: a refresh never fetches or changes it.
    """
    token_endpoint = _fill_tenant(connector, secrets, connector.oauth.token_endpoint)
    fields = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": _client_id(connector, secrets),
    }
    secret = _client_secret(connector, secrets)
    if secret is not None:
        fields["client_secret"] = secret
    payload = await _post_token_request_async(
        connector, client, token_endpoint, fields, deny_kind="expired"
    )
    return _bundle_from_payload(
        connector, payload, previous_refresh_token=refresh_token, previous_account=previous_account
    )


def run_connection_test(
    connector: ConnectorConfig, bundle: TokenBundle, client: httpx.Client
) -> None:
    """Run the connector's one declared read call. Raises on any failure."""
    method = connector.connection_test.method.upper()
    headers = {"Authorization": f"{bundle.token_type} {bundle.access_token}"}
    try:
        response = client.request(
            method,
            connector.connection_test.url,
            headers=headers,
            timeout=DEFAULT_TIMEOUT_SECONDS,
            follow_redirects=False,
        )
    except Exception as error:  # noqa: BLE001 - never leak transport internals
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if _is_redirect(response.status_code):
        raise ConnectError(error_text(connector, "generic"), kind="redirect_refused")
    if len(response.content) > MAX_RESPONSE_BYTES:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if response.status_code == 401:
        raise Unauthorized()
    if response.status_code >= 400:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
