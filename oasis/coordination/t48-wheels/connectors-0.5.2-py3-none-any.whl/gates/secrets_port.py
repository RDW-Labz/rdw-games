"""The narrow secrets surface Gates depends on, and its default adapter.

Every token store/read goes through this and nowhere else. The default
implementation wraps :mod:`anorak.secrets` (the OASIS OS-keychain interface);
tests inject a fake in-memory store instead so no test ever touches a real
keychain.
"""

from __future__ import annotations

from typing import Protocol

import anorak.secrets as _anorak_secrets


class Revealable(Protocol):
    """The ``SecretValue`` surface this module relies on."""

    def reveal(self) -> str: ...


class SecretsPort(Protocol):
    """Read/write/delete secrets by name. Matches ``anorak.secrets``."""

    def get(self, name: str) -> Revealable: ...

    def set(self, name: str, value: str) -> None: ...

    def delete(self, name: str) -> None: ...


class KeychainSecretsPort:
    """Default adapter: the real OASIS OS-keychain secrets interface."""

    def get(self, name: str) -> Revealable:
        return _anorak_secrets.get(name)

    def set(self, name: str, value: str) -> None:
        _anorak_secrets.set(name, value)

    def delete(self, name: str) -> None:
        _anorak_secrets.delete(name)


def default_secrets_port() -> SecretsPort:
    """Return the default, real-keychain-backed secrets port."""
    return KeychainSecretsPort()
