"""``python -m gates.status`` — print every catalog connector's status.

A thin wrapper over ``gates.connect status`` so both spellings from the T11
ticket work: ``python -m gates.status`` and ``python -m gates.connect
status``.
"""

from __future__ import annotations

import sys
from collections.abc import Sequence

from gates.connect import main as _connect_main


def main(argv: Sequence[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    return _connect_main(["status", *args])


if __name__ == "__main__":
    raise SystemExit(main())
