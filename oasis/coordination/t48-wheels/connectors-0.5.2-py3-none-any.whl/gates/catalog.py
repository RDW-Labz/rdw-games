"""Loads ``catalog/<name>/connector.yaml`` files into typed connector configs.

The base shape is the T10 ``connector.yaml`` format
(``skills/docs/formats.md``): ``name``, ``provider``, ``auth_type``,
``scopes``, ``can_do``, ``cannot_do_without_yes``, ``roles_allowed``,
``setup_steps``, ``errors``. T11 needs a few fields that format does not yet
define — ``display_name``, ``description``, ``sensitivity``, ``oauth``,
``connection_test``, optional ``notes`` — documented per-file in the catalog
and called out under ``needs_root`` in the T11 report rather than invented
silently.

This is trusted, repo-owned configuration, not external input: validation
errors are descriptive (they name the offending connector and field) because
there is nothing secret in a ``connector.yaml`` file.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Final

import yaml

_CATALOG_DIRNAME: Final = "catalog"
_FILENAME: Final = "connector.yaml"


class CatalogError(Exception):
    """A ``connector.yaml`` file is missing, unreadable, or malformed."""


class CatalogNotFoundError(CatalogError):
    """The catalog directory itself does not exist (no traceback, exit 2)."""

    def __init__(self, path: Path) -> None:
        super().__init__(f"connector catalog not found: {path}")
        self.path = path


@dataclass(frozen=True)
class OAuthConfig:
    """The OAuth 2.0 + PKCE endpoints and config-key names for one connector.

    ``authorization_endpoint`` and ``token_endpoint`` may contain a
    ``{tenant_id}`` placeholder, filled in at connect time from the secret
    named by ``tenant_id_config_key``.
    """

    authorization_endpoint: str
    token_endpoint: str
    client_id_config_key: str
    client_secret_config_key: str | None
    tenant_id_config_key: str | None
    redirect_host: str
    refresh_ttl_days: int | None = None


@dataclass(frozen=True)
class ConnectionTest:
    """The one read call used to prove a connection actually works."""

    method: str
    url: str
    description: str


@dataclass(frozen=True)
class ConnectorConfig:
    """One parsed ``catalog/<name>/connector.yaml``."""

    name: str
    provider: str
    auth_type: str
    display_name: str
    description: str
    sensitivity: str
    scopes: tuple[str, ...]
    can_do: tuple[str, ...]
    cannot_do_without_yes: tuple[str, ...]
    roles_allowed: tuple[str, ...]
    oauth: OAuthConfig
    connection_test: ConnectionTest
    setup_steps: tuple[str, ...]
    errors: Mapping[str, str]
    notes: tuple[str, ...] = field(default_factory=tuple)


def _source_catalog_dir() -> Path:
    """The repo's ``catalog/`` directory, resolved from this file's location."""
    return Path(__file__).resolve().parents[2] / _CATALOG_DIRNAME


def _packaged_catalog_dir() -> Path:
    """The catalog copy shipped inside the wheel (``gates/_catalog``)."""
    return Path(__file__).resolve().parent / "_catalog"


def default_catalog_dir() -> Path:
    """The source checkout's ``catalog/`` if present, else the packaged copy.

    A source checkout (this file living under ``src/gates/``, two levels
    below the repo root that also has a ``catalog/`` directory) wins so
    editing ``catalog/`` in the repo is picked up without reinstalling.
    Installed from a wheel, there is no such directory, so this falls back
    to the copy hatch ships at ``gates/_catalog``.
    """
    source = _source_catalog_dir()
    if source.is_dir():
        return source
    return _packaged_catalog_dir()


def _require_str(value: object, *, connector: str, field_name: str) -> str:
    if not isinstance(value, str) or not value:
        raise CatalogError(f"{connector}: '{field_name}' must be a non-empty string")
    return value


def _optional_str(value: object, *, connector: str, field_name: str) -> str | None:
    if value is None:
        return None
    return _require_str(value, connector=connector, field_name=field_name)


def _require_str_list(value: object, *, connector: str, field_name: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise CatalogError(f"{connector}: '{field_name}' must be a list of strings")
    return tuple(value)


def _require_mapping(value: object, *, connector: str, field_name: str) -> Mapping[str, object]:
    if not isinstance(value, dict):
        raise CatalogError(f"{connector}: '{field_name}' must be a mapping")
    return value


def _require_str_mapping(value: object, *, connector: str, field_name: str) -> Mapping[str, str]:
    mapping = _require_mapping(value, connector=connector, field_name=field_name)
    result: dict[str, str] = {}
    for key, item in mapping.items():
        if not isinstance(key, str) or not isinstance(item, str):
            raise CatalogError(f"{connector}: '{field_name}' must map strings to strings")
        result[key] = item
    return result


def _parse_oauth(raw: object, *, connector: str) -> OAuthConfig:
    mapping = _require_mapping(raw, connector=connector, field_name="oauth")
    refresh_ttl = mapping.get("refresh_ttl_days")
    if refresh_ttl is not None and not isinstance(refresh_ttl, int):
        raise CatalogError(f"{connector}: 'oauth.refresh_ttl_days' must be an integer")
    return OAuthConfig(
        authorization_endpoint=_require_str(
            mapping.get("authorization_endpoint"),
            connector=connector,
            field_name="oauth.authorization_endpoint",
        ),
        token_endpoint=_require_str(
            mapping.get("token_endpoint"), connector=connector, field_name="oauth.token_endpoint"
        ),
        client_id_config_key=_require_str(
            mapping.get("client_id_config_key"),
            connector=connector,
            field_name="oauth.client_id_config_key",
        ),
        client_secret_config_key=_optional_str(
            mapping.get("client_secret_config_key"),
            connector=connector,
            field_name="oauth.client_secret_config_key",
        ),
        tenant_id_config_key=_optional_str(
            mapping.get("tenant_id_config_key"),
            connector=connector,
            field_name="oauth.tenant_id_config_key",
        ),
        redirect_host=_require_str(
            mapping.get("redirect_host"), connector=connector, field_name="oauth.redirect_host"
        ),
        refresh_ttl_days=refresh_ttl,
    )


def _parse_connection_test(raw: object, *, connector: str) -> ConnectionTest:
    mapping = _require_mapping(raw, connector=connector, field_name="connection_test")
    return ConnectionTest(
        method=_require_str(
            mapping.get("method"), connector=connector, field_name="connection_test.method"
        ),
        url=_require_str(mapping.get("url"), connector=connector, field_name="connection_test.url"),
        description=_require_str(
            mapping.get("description"),
            connector=connector,
            field_name="connection_test.description",
        ),
    )


def parse_connector(raw: object, *, source: str) -> ConnectorConfig:
    """Build a :class:`ConnectorConfig` from a parsed YAML mapping."""
    if not isinstance(raw, dict):
        raise CatalogError(f"{source}: connector.yaml must contain a mapping")
    name = _require_str(raw.get("name"), connector=source, field_name="name")
    notes_raw = raw.get("notes", [])
    notes = _require_str_list(notes_raw, connector=name, field_name="notes") if notes_raw else ()
    return ConnectorConfig(
        name=name,
        provider=_require_str(raw.get("provider"), connector=name, field_name="provider"),
        auth_type=_require_str(raw.get("auth_type"), connector=name, field_name="auth_type"),
        display_name=_require_str(
            raw.get("display_name"), connector=name, field_name="display_name"
        ),
        description=_require_str(raw.get("description"), connector=name, field_name="description"),
        sensitivity=_require_str(raw.get("sensitivity"), connector=name, field_name="sensitivity"),
        scopes=_require_str_list(raw.get("scopes"), connector=name, field_name="scopes"),
        can_do=_require_str_list(raw.get("can_do", []), connector=name, field_name="can_do"),
        cannot_do_without_yes=_require_str_list(
            raw.get("cannot_do_without_yes", []),
            connector=name,
            field_name="cannot_do_without_yes",
        ),
        roles_allowed=_require_str_list(
            raw.get("roles_allowed", []), connector=name, field_name="roles_allowed"
        ),
        oauth=_parse_oauth(raw.get("oauth"), connector=name),
        connection_test=_parse_connection_test(raw.get("connection_test"), connector=name),
        setup_steps=_require_str_list(
            raw.get("setup_steps", []), connector=name, field_name="setup_steps"
        ),
        errors=_require_str_mapping(raw.get("errors", {}), connector=name, field_name="errors"),
        notes=notes,
    )


def _load_file(path: Path) -> ConnectorConfig:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as error:
        raise CatalogError(f"could not read {path}") from error
    try:
        raw = yaml.safe_load(text)
    except yaml.YAMLError as error:
        raise CatalogError(f"could not parse {path}") from error
    return parse_connector(raw, source=path.parent.name)


def load_connector(name: str, *, catalog_dir: Path | None = None) -> ConnectorConfig:
    """Load one connector by its catalog directory name."""
    base = catalog_dir if catalog_dir is not None else default_catalog_dir()
    if not base.is_dir():
        raise CatalogNotFoundError(base)
    path = base / name / _FILENAME
    if not path.is_file():
        raise CatalogError(f"no such connector: {name}")
    connector = _load_file(path)
    if connector.name != name:
        raise CatalogError(
            f"{path}: connector.yaml name '{connector.name}' does not match its folder '{name}'"
        )
    return connector


def load_catalog(*, catalog_dir: Path | None = None) -> tuple[ConnectorConfig, ...]:
    """Load every connector under the catalog directory, sorted by name."""
    base = catalog_dir if catalog_dir is not None else default_catalog_dir()
    if not base.is_dir():
        raise CatalogNotFoundError(base)
    connectors = []
    for entry in sorted(base.iterdir(), key=lambda item: item.name):
        candidate = entry / _FILENAME
        if entry.is_dir() and candidate.is_file():
            connectors.append(load_connector(entry.name, catalog_dir=base))
    return tuple(connectors)
