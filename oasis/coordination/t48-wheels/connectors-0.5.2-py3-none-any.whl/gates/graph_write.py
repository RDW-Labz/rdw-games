"""Write (mutating) Microsoft Graph calls: Outlook mail/calendar, OneDrive, Teams (T27).

Every function here follows the same shape as `gates.graph_read`'s reads:
`async`, a first positional `person: str = DEFAULT_PERSON`, keyword-only
arguments, keyword-only `client: httpx.AsyncClient`, `secrets: SecretsPort |
None = None`, `catalog_dir: Path | None = None`; tokens load/refresh the same
way; every HTTP or auth failure surfaces as the same plain-words
`gates.errors.ConnectError`. A write returns `gates.results.WriteResult(ok,
id, detail)` — `detail` is always one of a handful of fixed, plain-words
status strings, never a mail body, subject, address, file text, or chat text.

Hardening mirrors `gates.graph_read` and `gates.oauth_http`: HTTPS Graph host
only, no redirects followed, a 15 second timeout, a 64 KiB response cap, and a
single silent refresh-and-retry on a 401. Every call appends one `gates.audit`
event (connector, person, action, outcome only) — never a recipient, subject,
body, folder, file name/text, or chat text.
"""

from __future__ import annotations

import contextlib
import uuid
from collections.abc import Awaitable, Callable, Sequence
from pathlib import Path
from typing import Literal
from urllib.parse import quote, urlencode

import httpx

from gates import audit
from gates.catalog import ConnectorConfig, load_connector
from gates.connect import DEFAULT_PERSON
from gates.errors import ConnectError, error_text
from gates.graph_read import (
    _GRAPH_BASE,
    _is_redirect,
    _load_and_refresh_bundle_async,
    _refresh_and_store_async,
    _request_json,
    _require_graph_url,
)
from gates.oauth_http import DEFAULT_TIMEOUT_SECONDS, MAX_RESPONSE_BYTES
from gates.results import WriteResult
from gates.secrets_port import SecretsPort, default_secrets_port
from gates.tokens import TokenBundle

_WELL_KNOWN_MAIL_FOLDERS = frozenset(
    {
        "inbox",
        "drafts",
        "sentitems",
        "deleteditems",
        "archive",
        "junkemail",
        "outbox",
        "conversationhistory",
        "clutter",
    }
)
_SHARE_ROLES = frozenset({"read", "write"})

#: Graph changes a message's id when it moves between folders (a draft moving
#: to Sent Items on send, or an explicit move) unless the request opts into a
#: stable id, so every mail send/reply/move call carries this header.
_IMMUTABLE_ID_HEADERS = {"Prefer": 'IdType="ImmutableId"'}

_Send = Callable[[TokenBundle], Awaitable[httpx.Response]]


async def _send_once(
    connector: ConnectorConfig, send: _Send, bundle: TokenBundle
) -> httpx.Response:
    try:
        return await send(bundle)
    except Exception as error:  # noqa: BLE001 - never leak transport internals
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error


async def _write_call(
    connector: ConnectorConfig,
    person: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
    send: _Send,
    url: str,
) -> tuple[dict[str, object] | None, TokenBundle]:
    """One bounded Graph write call, refreshing and retrying exactly once on a 401.

    Returns ``(payload_or_None, bundle)``; ``payload`` is ``None`` for a 2xx
    response with no body (e.g. 202/204). Never returns or logs response
    content for a failing status.
    """
    _require_graph_url(connector, url)
    response = await _send_once(connector, send, bundle)
    if response.status_code == 401:
        bundle = await _refresh_and_store_async(connector, secrets, person, bundle, client)
        response = await _send_once(connector, send, bundle)
        if response.status_code == 401:
            raise ConnectError(error_text(connector, "denied"), kind="denied")
    if _is_redirect(response.status_code):
        raise ConnectError(error_text(connector, "generic"), kind="redirect_refused")
    if len(response.content) > MAX_RESPONSE_BYTES:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if response.status_code >= 400:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if not response.content:
        return None, bundle
    try:
        payload = response.json()
    except ValueError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if not isinstance(payload, dict):
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return payload, bundle


def _payload_id(payload: dict[str, object] | None) -> str:
    if not isinstance(payload, dict):
        return ""
    id_raw = payload.get("id")
    return id_raw if isinstance(id_raw, str) else ""


def _payload_web_url(payload: dict[str, object] | None) -> str:
    """A message/event/driveItem's own link, when Graph's response carries one."""
    if not isinstance(payload, dict):
        return ""
    for key in ("webLink", "webUrl"):
        value = payload.get(key)
        if isinstance(value, str):
            return value
    return ""


def _invite_web_url(payload: dict[str, object] | None) -> str:
    """The first permission's link, when Graph's `invite` response carries one."""
    if not isinstance(payload, dict):
        return ""
    value = payload.get("value")
    if not isinstance(value, list) or not value:
        return ""
    first = value[0]
    if not isinstance(first, dict):
        return ""
    link = first.get("link")
    if not isinstance(link, dict):
        return ""
    web_url = link.get("webUrl")
    return web_url if isinstance(web_url, str) else ""


# --- Outlook mail ----------------------------------------------------------


async def send_mail(
    person: str = DEFAULT_PERSON,
    *,
    to: tuple[str, ...],
    subject: str,
    body: str,
    body_html: str | None = None,
    cc: tuple[str, ...] = (),
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Send a new message from ``outlook``: create a draft, then send it.

    The draft's id and ``webLink`` (from the create response) become
    ``WriteResult.id``/``web_url``, so a plan report can link to what was sent.
    ``body_html`` (T43, decisions #139/#150), when given, becomes the message's
    single HTML body (``{"contentType": "HTML", "content": body_html}``) — sent
    as given, never built, sanitized or re-escaped here. ``body_html=None``
    keeps today's plain-text body byte for byte.
    """
    connector = load_connector("outlook", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    mail_format: Literal["html", "text"] = "html" if body_html is not None else "text"
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "send_mail", "started", operation_id, mail_format=mail_format
        )
    draft_url = f"{_GRAPH_BASE}/me/messages"
    message_body = (
        {"contentType": "HTML", "content": body_html}
        if body_html is not None
        else {"contentType": "Text", "content": body}
    )
    message: dict[str, object] = {
        "subject": subject,
        "body": message_body,
        "toRecipients": [{"emailAddress": {"address": address}} for address in to],
    }
    if cc:
        message["ccRecipients"] = [{"emailAddress": {"address": address}} for address in cc]
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def create_draft(current: TokenBundle) -> httpx.Response:
            headers = {
                "Authorization": f"{current.token_type} {current.access_token}",
                **_IMMUTABLE_ID_HEADERS,
            }
            return await client.post(
                draft_url,
                headers=headers,
                json=message,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        draft_payload, bundle = await _write_call(
            connector,
            person,
            bundle,
            client=client,
            secrets=secrets_port,
            send=create_draft,
            url=draft_url,
        )
        draft_id = _payload_id(draft_payload)
        web_url = _payload_web_url(draft_payload)
        send_url = f"{_GRAPH_BASE}/me/messages/{quote(draft_id, safe='')}/send"

        async def send_draft(current: TokenBundle) -> httpx.Response:
            headers = {
                "Authorization": f"{current.token_type} {current.access_token}",
                **_IMMUTABLE_ID_HEADERS,
            }
            return await client.post(
                send_url, headers=headers, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
            )

        await _write_call(
            connector,
            person,
            bundle,
            client=client,
            secrets=secrets_port,
            send=send_draft,
            url=send_url,
        )
        result = WriteResult(ok=True, id=draft_id, web_url=web_url, detail="sent")
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "send_mail", "failed", operation_id,
                mail_format=mail_format,
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "send_mail", "succeeded", operation_id,
            mail_format=mail_format,
        )
    return result


async def reply_mail(
    person: str = DEFAULT_PERSON,
    *,
    message_id: str,
    body: str,
    body_html: str | None = None,
    reply_all: bool = False,
    to: Sequence[str] | None = None,
    cc: Sequence[str] | None = None,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Reply (or reply-all) to one ``outlook`` message: create a draft, then send it.

    ``reply_all=True`` requires a non-empty ``to`` — checked before any network
    call — and always drafts through Graph's ``createReply`` (never
    ``createReplyAll``), then PATCHes the draft's ``toRecipients``/``ccRecipients``
    to exactly ``to``/``cc`` (``cc`` None means empty) before sending, so the sent
    message reaches exactly those addresses. ``reply_all=False`` is unchanged:
    no PATCH, and ``to``/``cc`` are ignored. Never logs the comment text or any
    address. The reply draft's id and ``webLink`` become ``WriteResult.id``/``web_url``.
    ``body_html`` (T43, decisions #139/#150), when given, replaces the plain
    ``comment`` with the reply draft's HTML message body (``createReply``'s
    ``message.body``) — same recipients/threading as today; sent as given,
    never built, sanitized or re-escaped here. ``body_html=None`` keeps today's
    ``comment``-only request byte for byte.
    """
    connector = load_connector("outlook", catalog_dir=catalog_dir)
    if reply_all and not to:
        raise ConnectError(error_text(connector, "invalid"), kind="invalid")
    to_list = list(to) if reply_all and to else []
    cc_list = list(cc) if reply_all and cc else []
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    mail_format: Literal["html", "text"] = "html" if body_html is not None else "text"
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "reply_mail", "started", operation_id, mail_format=mail_format
        )
    draft_url = f"{_GRAPH_BASE}/me/messages/{quote(message_id, safe='')}/createReply"
    payload_body: dict[str, object] = (
        {"message": {"body": {"contentType": "HTML", "content": body_html}}}
        if body_html is not None
        else {"comment": body}
    )
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def create_draft(current: TokenBundle) -> httpx.Response:
            headers = {
                "Authorization": f"{current.token_type} {current.access_token}",
                **_IMMUTABLE_ID_HEADERS,
            }
            return await client.post(
                draft_url,
                headers=headers,
                json=payload_body,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        draft_payload, bundle = await _write_call(
            connector,
            person,
            bundle,
            client=client,
            secrets=secrets_port,
            send=create_draft,
            url=draft_url,
        )
        draft_id = _payload_id(draft_payload)
        web_url = _payload_web_url(draft_payload)

        if reply_all:
            patch_url = f"{_GRAPH_BASE}/me/messages/{quote(draft_id, safe='')}"
            patch_body = {
                "toRecipients": [{"emailAddress": {"address": address}} for address in to_list],
                "ccRecipients": [{"emailAddress": {"address": address}} for address in cc_list],
            }

            async def patch_recipients(current: TokenBundle) -> httpx.Response:
                headers = {
                    "Authorization": f"{current.token_type} {current.access_token}",
                    **_IMMUTABLE_ID_HEADERS,
                }
                return await client.patch(
                    patch_url,
                    headers=headers,
                    json=patch_body,
                    timeout=DEFAULT_TIMEOUT_SECONDS,
                    follow_redirects=False,
                )

            _patch_payload, bundle = await _write_call(
                connector,
                person,
                bundle,
                client=client,
                secrets=secrets_port,
                send=patch_recipients,
                url=patch_url,
            )

        send_url = f"{_GRAPH_BASE}/me/messages/{quote(draft_id, safe='')}/send"

        async def send_draft(current: TokenBundle) -> httpx.Response:
            headers = {
                "Authorization": f"{current.token_type} {current.access_token}",
                **_IMMUTABLE_ID_HEADERS,
            }
            return await client.post(
                send_url, headers=headers, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
            )

        await _write_call(
            connector,
            person,
            bundle,
            client=client,
            secrets=secrets_port,
            send=send_draft,
            url=send_url,
        )
        result = WriteResult(ok=True, id=draft_id, web_url=web_url, detail="replied")
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "reply_mail", "failed", operation_id,
                mail_format=mail_format,
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "reply_mail", "succeeded", operation_id,
            mail_format=mail_format,
        )
    return result


async def _resolve_mail_folder_id(
    connector: ConnectorConfig,
    person: str,
    folder: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
) -> tuple[str, TokenBundle]:
    """A Graph well-known folder name, a display-name lookup, or a raw folder id.

    Tried in that order: a well-known name is used as-is; else a display-name
    lookup; else (needed to undo a move, since ``WriteResult.previous_folder``
    is a raw Graph folder id, not a display name) a direct
    ``GET /me/mailFolders/{id}`` confirms the id exists and is used as-is.
    """
    lowered = folder.strip().lower()
    if lowered in _WELL_KNOWN_MAIL_FOLDERS:
        return lowered, bundle
    escaped = folder.replace("'", "''")
    params = {"$filter": f"displayName eq '{escaped}'", "$select": "id"}
    url = f"{_GRAPH_BASE}/me/mailFolders?{urlencode(params)}"
    payload, bundle = await _request_json(
        connector, person, url, bundle, client=client, secrets=secrets
    )
    value = payload.get("value")
    if isinstance(value, list) and value:
        first = value[0]
        if isinstance(first, dict):
            id_raw = first.get("id")
            if isinstance(id_raw, str) and id_raw:
                return id_raw, bundle
    by_id_params = urlencode({"$select": "id"})
    by_id_url = f"{_GRAPH_BASE}/me/mailFolders/{quote(folder, safe='')}?{by_id_params}"
    try:
        by_id_payload, bundle = await _request_json(
            connector, person, by_id_url, bundle, client=client, secrets=secrets
        )
    except ConnectError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    id_raw = by_id_payload.get("id")
    if isinstance(id_raw, str) and id_raw:
        return id_raw, bundle
    raise ConnectError(error_text(connector, "generic"), kind="generic")


async def move_mail(
    person: str = DEFAULT_PERSON,
    *,
    message_id: str,
    folder: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Move one ``outlook`` message to ``folder`` (a well-known name, display name, or id).

    Reads the message's current ``parentFolderId`` before moving it, so the
    move can be undone: ``WriteResult.previous_folder`` is that id, and the
    Undo passes it straight back in as ``folder``.
    """
    connector = load_connector("outlook", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "move_mail", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        read_params = urlencode({"$select": "parentFolderId"})
        read_url = f"{_GRAPH_BASE}/me/messages/{quote(message_id, safe='')}?{read_params}"

        async def read_current(current: TokenBundle) -> httpx.Response:
            headers = {
                "Authorization": f"{current.token_type} {current.access_token}",
                **_IMMUTABLE_ID_HEADERS,
            }
            return await client.get(
                read_url, headers=headers, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
            )

        current_payload, bundle = await _write_call(
            connector,
            person,
            bundle,
            client=client,
            secrets=secrets_port,
            send=read_current,
            url=read_url,
        )
        previous_raw = (current_payload or {}).get("parentFolderId")
        previous_folder = previous_raw if isinstance(previous_raw, str) else ""
        folder_id, bundle = await _resolve_mail_folder_id(
            connector, person, folder, bundle, client=client, secrets=secrets_port
        )
        url = f"{_GRAPH_BASE}/me/messages/{quote(message_id, safe='')}/move"
        payload_body = {"destinationId": folder_id}

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {
                "Authorization": f"{current.token_type} {current.access_token}",
                **_IMMUTABLE_ID_HEADERS,
            }
            return await client.post(
                url,
                headers=headers,
                json=payload_body,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        payload, _bundle = await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(
            ok=True, id=_payload_id(payload), previous_folder=previous_folder, detail="moved"
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "move_mail", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "move_mail", "succeeded", operation_id)
    return result


# --- Outlook calendar --------------------------------------------------------


def _new_event_body(
    *,
    subject: str,
    start_iso: str,
    end_iso: str,
    attendees: tuple[str, ...],
    location: str,
    body: str,
) -> dict[str, object]:
    payload: dict[str, object] = {
        "subject": subject,
        "start": {"dateTime": start_iso, "timeZone": "UTC"},
        "end": {"dateTime": end_iso, "timeZone": "UTC"},
    }
    if location:
        payload["location"] = {"displayName": location}
    if body:
        payload["body"] = {"contentType": "Text", "content": body}
    if attendees:
        payload["attendees"] = [
            {"emailAddress": {"address": address}, "type": "required"} for address in attendees
        ]
    return payload


async def create_event(
    person: str = DEFAULT_PERSON,
    *,
    subject: str,
    start_iso: str,
    end_iso: str,
    attendees: tuple[str, ...] = (),
    location: str = "",
    body: str = "",
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Create one ``outlook-calendar`` event."""
    connector = load_connector("outlook-calendar", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "create_event", "started", operation_id)
    url = f"{_GRAPH_BASE}/me/events"
    payload_body = _new_event_body(
        subject=subject,
        start_iso=start_iso,
        end_iso=end_iso,
        attendees=attendees,
        location=location,
        body=body,
    )
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.post(
                url,
                headers=headers,
                json=payload_body,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        payload, _bundle = await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(
            ok=True, id=_payload_id(payload), web_url=_payload_web_url(payload), detail="created"
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "create_event", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "create_event", "succeeded", operation_id)
    return result


def _event_patch_body(
    *,
    subject: str | None,
    start_iso: str | None,
    end_iso: str | None,
    attendees: tuple[str, ...] | None,
    location: str | None,
    body: str | None,
) -> dict[str, object]:
    payload: dict[str, object] = {}
    if subject is not None:
        payload["subject"] = subject
    if start_iso is not None:
        payload["start"] = {"dateTime": start_iso, "timeZone": "UTC"}
    if end_iso is not None:
        payload["end"] = {"dateTime": end_iso, "timeZone": "UTC"}
    if location is not None:
        payload["location"] = {"displayName": location}
    if body is not None:
        payload["body"] = {"contentType": "Text", "content": body}
    if attendees is not None:
        payload["attendees"] = [
            {"emailAddress": {"address": address}, "type": "required"} for address in attendees
        ]
    return payload


async def update_event(
    person: str = DEFAULT_PERSON,
    *,
    event_id: str,
    subject: str | None = None,
    start_iso: str | None = None,
    end_iso: str | None = None,
    attendees: tuple[str, ...] | None = None,
    location: str | None = None,
    body: str | None = None,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Patch one ``outlook-calendar`` event with only the given fields."""
    connector = load_connector("outlook-calendar", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "update_event", "started", operation_id)
    url = f"{_GRAPH_BASE}/me/events/{quote(event_id, safe='')}"
    payload_body = _event_patch_body(
        subject=subject,
        start_iso=start_iso,
        end_iso=end_iso,
        attendees=attendees,
        location=location,
        body=body,
    )
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.patch(
                url,
                headers=headers,
                json=payload_body,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        payload, _bundle = await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(
            ok=True, id=event_id, web_url=_payload_web_url(payload), detail="updated"
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "update_event", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "update_event", "succeeded", operation_id)
    return result


async def delete_event(
    person: str = DEFAULT_PERSON,
    *,
    event_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Delete one ``outlook-calendar`` event."""
    connector = load_connector("outlook-calendar", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_event", "started", operation_id)
    url = f"{_GRAPH_BASE}/me/events/{quote(event_id, safe='')}"
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.delete(
                url, headers=headers, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
            )

        await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(ok=True, id=event_id, detail="deleted")
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "delete_event", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_event", "succeeded", operation_id)
    return result


# --- OneDrive ----------------------------------------------------------------


def _drive_item_path(folder_path: str, name: str) -> str:
    trimmed = folder_path.strip("/")
    return f"{trimmed}/{name}" if trimmed else name


async def file_create(
    person: str = DEFAULT_PERSON,
    *,
    name: str,
    folder_path: str,
    text: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Create one plain-text file at ``folder_path`` in ``onedrive``."""
    connector = load_connector("onedrive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "create_file", "started", operation_id)
    path = quote(_drive_item_path(folder_path, name), safe="/")
    url = f"{_GRAPH_BASE}/me/drive/root:/{path}:/content"
    content = text.encode("utf-8")
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {
                "Authorization": f"{current.token_type} {current.access_token}",
                "Content-Type": "text/plain; charset=utf-8",
            }
            return await client.put(
                url,
                headers=headers,
                content=content,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        payload, _bundle = await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(
            ok=True, id=_payload_id(payload), web_url=_payload_web_url(payload), detail="created"
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "create_file", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "create_file", "succeeded", operation_id)
    return result


async def file_move(
    person: str = DEFAULT_PERSON,
    *,
    item_id: str,
    folder_path: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Move one ``onedrive`` file to ``folder_path`` (root-relative)."""
    connector = load_connector("onedrive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "move_file", "started", operation_id)
    trimmed = folder_path.strip("/")
    url = f"{_GRAPH_BASE}/me/drive/items/{quote(item_id, safe='')}"
    payload_body = {"parentReference": {"path": f"/drive/root:/{trimmed}"}}
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.patch(
                url,
                headers=headers,
                json=payload_body,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        payload, _bundle = await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(
            ok=True, id=item_id, web_url=_payload_web_url(payload), detail="moved"
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "move_file", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "move_file", "succeeded", operation_id)
    return result


async def file_share(
    person: str = DEFAULT_PERSON,
    *,
    item_id: str,
    emails: tuple[str, ...],
    role: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Invite ``emails`` to one ``onedrive`` file with ``role`` (``read``/``write``)."""
    if role not in _SHARE_ROLES:
        raise ValueError("role must be 'read' or 'write'")
    connector = load_connector("onedrive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "share_file", "started", operation_id)
    url = f"{_GRAPH_BASE}/me/drive/items/{quote(item_id, safe='')}/invite"
    payload_body = {
        "recipients": [{"email": address} for address in emails],
        "requireSignIn": True,
        "sendInvitation": False,
        "roles": [role],
    }
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.post(
                url,
                headers=headers,
                json=payload_body,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        payload, _bundle = await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(
            ok=True, id=item_id, web_url=_invite_web_url(payload), detail="shared"
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "share_file", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "share_file", "succeeded", operation_id)
    return result


async def file_delete(
    person: str = DEFAULT_PERSON,
    *,
    item_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Delete (send to Recycle Bin) one ``onedrive`` file."""
    connector = load_connector("onedrive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_file", "started", operation_id)
    url = f"{_GRAPH_BASE}/me/drive/items/{quote(item_id, safe='')}"
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.delete(
                url, headers=headers, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
            )

        await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(ok=True, id=item_id, detail="deleted")
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "delete_file", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_file", "succeeded", operation_id)
    return result


# --- Teams -------------------------------------------------------------------


async def teams_send_chat(
    person: str = DEFAULT_PERSON,
    *,
    chat_id: str,
    text: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Post one plain-text message to a Teams chat."""
    connector = load_connector("teams", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "send_chat", "started", operation_id)
    url = f"{_GRAPH_BASE}/chats/{quote(chat_id, safe='')}/messages"
    payload_body = {"body": {"contentType": "text", "content": text}}
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.post(
                url,
                headers=headers,
                json=payload_body,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        payload, _bundle = await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(
            ok=True, id=_payload_id(payload), web_url=_payload_web_url(payload), detail="sent"
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "send_chat", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "send_chat", "succeeded", operation_id)
    return result


async def teams_post_channel(
    person: str = DEFAULT_PERSON,
    *,
    team_id: str,
    channel_id: str,
    text: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Post one plain-text message to a Teams channel."""
    connector = load_connector("teams", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "post_channel_message", "started", operation_id)
    url = (
        f"{_GRAPH_BASE}/teams/{quote(team_id, safe='')}"
        f"/channels/{quote(channel_id, safe='')}/messages"
    )
    payload_body = {"body": {"contentType": "text", "content": text}}
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.post(
                url,
                headers=headers,
                json=payload_body,
                timeout=DEFAULT_TIMEOUT_SECONDS,
                follow_redirects=False,
            )

        payload, _bundle = await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(
            ok=True, id=_payload_id(payload), web_url=_payload_web_url(payload), detail="sent"
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "post_channel_message", "failed", operation_id
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "post_channel_message", "succeeded", operation_id
        )
    return result


async def teams_delete_chat_message(
    person: str = DEFAULT_PERSON,
    *,
    chat_id: str,
    message_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Soft-delete one message from a Teams chat (Graph `softDelete`). The Undo for a chat post."""
    connector = load_connector("teams", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "delete_chat_message", "started", operation_id)
    url = (
        f"{_GRAPH_BASE}/chats/{quote(chat_id, safe='')}"
        f"/messages/{quote(message_id, safe='')}/softDelete"
    )
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.post(
                url, headers=headers, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
            )

        await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(ok=True, id=message_id, detail="deleted")
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "delete_chat_message", "failed", operation_id
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "delete_chat_message", "succeeded", operation_id
        )
    return result


async def teams_delete_channel_message(
    person: str = DEFAULT_PERSON,
    *,
    team_id: str,
    channel_id: str,
    message_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> WriteResult:
    """Soft-delete one message from a Teams channel (Graph `softDelete`).

    The Undo for a channel post.
    """
    connector = load_connector("teams", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "delete_channel_message", "started", operation_id
        )
    url = (
        f"{_GRAPH_BASE}/teams/{quote(team_id, safe='')}"
        f"/channels/{quote(channel_id, safe='')}"
        f"/messages/{quote(message_id, safe='')}/softDelete"
    )
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)

        async def send(current: TokenBundle) -> httpx.Response:
            headers = {"Authorization": f"{current.token_type} {current.access_token}"}
            return await client.post(
                url, headers=headers, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
            )

        await _write_call(
            connector, person, bundle, client=client, secrets=secrets_port, send=send, url=url
        )
        result = WriteResult(ok=True, id=message_id, detail="deleted")
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "delete_channel_message", "failed", operation_id
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "delete_channel_message", "succeeded", operation_id
        )
    return result
