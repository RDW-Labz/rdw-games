"""Read-only QuickBooks Online reports for the month-end-close skill (T33).

UNVERIFIED against Intuit docs (T33 Open): no Intuit developer app has been
registered yet (``docs/registrations.md``, "QuickBooks — pending"), so none of
the host, paths, report JSON shapes, OAuth scope, or account note field name
below have been checked against Intuit's real documentation or a real
sandbox. Every one of those specifics lives in the one clearly marked block
below and is modeled on the QuickBooks Online Accounting API's reports and
query endpoints as best known. Every test in this module runs against
:class:`~gates.quickbooks_fake.FakeQuickBooksTransport` and the fixtures under
``tests/fixtures/quickbooks/`` — no test needs a real Intuit URL.

Five async reads, all sharing one connector (``quickbooks``) and one realm:
:func:`qbo_profit_and_loss`, :func:`qbo_balance_sheet`, :func:`qbo_trial_balance`,
:func:`qbo_accounts`, and :func:`qbo_month_pack` (which calls the other four
for the current month, the prior month, and — for profit and loss only — the
same month a year ago).

Read-only is enforced in code, not just by convention: :class:`QuickBooksTransport`
is a ``Protocol`` with exactly one method, ``get``; :class:`HttpxQuickBooksTransport`
wraps ``httpx.AsyncClient.get`` only; every URL is checked against a fixed
allowlist *before* any I/O; there is no write function anywhere in this module
or in :mod:`gates.quickbooks_fake`, and neither module ever calls
``post``/``put``/``patch``/``delete``/``request`` or spells out the literal
string ``"POST"``/``"PUT"``/``"PATCH"``/``"DELETE"`` (``test_no_write_verbs_in_module``
walks both modules' AST to prove it).

Every provider response is DATA: money arrives as a decimal string and is
parsed with :class:`decimal.Decimal` (never ``float``) into integer cents; an
account's note/description text is sanitised the same way
:func:`gates.graph_read._sanitize_text` sanitises a subject line (control
characters stripped, capped at 200 characters) and is kept as a plain string
afterwards — never interpreted, never specially handled, even when it reads
like an instruction. Each of the five tools appends one
:mod:`gates.audit` event (connector, person, outcome only — never a report
line, an amount, or a note).
"""

from __future__ import annotations

import calendar
import contextlib
import re
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path
from typing import Final, Protocol
from urllib.parse import urlencode, urlsplit

import httpx

from gates import audit
from gates.catalog import ConnectorConfig, load_connector
from gates.connect import DEFAULT_PERSON, PROACTIVE_REFRESH_BUFFER_SECONDS
from gates.errors import ConnectError, error_text
from gates.oauth_http import (
    DEFAULT_TIMEOUT_SECONDS,
    MAX_RESPONSE_BYTES,
    refresh_access_token_async,
)
from gates.secrets_port import SecretsPort, default_secrets_port
from gates.tokens import TokenBundle, TokenStoreError, load_tokens, store_tokens

# --- Intuit-specific constants (UNVERIFIED against Intuit docs, T33 Open) --
# Every literal below that names an Intuit host, path, report, field, or
# scope is a best-effort guess at the QuickBooks Online Accounting API's real
# shape, not a confirmed reading of Intuit's docs. Nothing here has been
# exercised against a real Intuit sandbox.
_QB_BASE: Final = "https://quickbooks.api.intuit.com"
#: Referenced only for documentation here; the scope itself is requested by
#: ``catalog/quickbooks/connector.yaml``, not by this module.
_QB_SCOPE: Final = "com.intuit.quickbooks.accounting"
_REPORT_NAMES: Final[Mapping[str, str]] = {
    "profit_and_loss": "ProfitAndLoss",
    "balance_sheet": "BalanceSheet",
    "trial_balance": "TrialBalance",
}
#: QuickBooks Online's Account entity field carrying the account's free-text
#: description/memo (verify field name) — the injection vector this module
#: sanitises but never interprets.
_ACCOUNT_NOTE_FIELD: Final = "Description"
# -----------------------------------------------------------------------------

_MONTH_RE: Final = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
_REALM_ID_RE: Final = re.compile(r"^\d{1,20}$")
_CONTROL_CHARS_RE: Final = re.compile(r"[\x00-\x1f\x7f]")
_MAX_TEXT_LENGTH: Final = 200
_READ_HEADERS: Final[Mapping[str, str]] = {"Accept": "application/json"}

_PNL_GROUPS: Final[Mapping[str, str]] = {
    "Income": "income",
    "COGS": "cogs",
    "Expenses": "expense",
    "OtherIncome": "other_income",
    "OtherExpenses": "other_expense",
}
_BS_GROUPS: Final[Mapping[str, str]] = {
    "Assets": "asset",
    "Liabilities": "liability",
    "Equity": "equity",
}
_PNL_TOTAL_GROUP: Final = "NetIncome"
_BS_TOTAL_GROUP: Final = "Assets"

_REPORT_PATH_RE: Final = re.compile(
    r"^/v3/company/(?P<realm>\d{1,20})/reports/(?P<report>ProfitAndLoss|BalanceSheet|TrialBalance)$"
)
_ACCOUNT_QUERY_PATH_RE: Final = re.compile(r"^/v3/company/(?P<realm>\d{1,20})/query$")


@dataclass(frozen=True)
class ReportLine:
    """One line item on a profit-and-loss or balance-sheet report."""

    account_id: str
    name: str
    section: str
    amount_cents: int


@dataclass(frozen=True)
class Report:
    """A profit-and-loss or balance-sheet report for one window.

    ``lines`` empty means "no data" — used when the same month last year
    isn't present yet. ``reported_total_cents`` is net income for
    ``kind="profit_and_loss"`` and total assets for ``kind="balance_sheet"``.
    """

    kind: str
    start: date | None
    end: date
    currency: str
    lines: tuple[ReportLine, ...]
    reported_total_cents: int


@dataclass(frozen=True)
class TrialBalanceLine:
    """One account's debit/credit balance on a trial balance."""

    account_id: str
    name: str
    debit_cents: int
    credit_cents: int


@dataclass(frozen=True)
class TrialBalance:
    """A trial balance as of one date."""

    as_of: date
    lines: tuple[TrialBalanceLine, ...]
    debit_total_cents: int
    credit_total_cents: int


@dataclass(frozen=True)
class Account:
    """One QuickBooks account. ``note`` is its description/memo text (verify field name)."""

    account_id: str
    name: str
    account_type: str
    current_balance_cents: int
    note: str


@dataclass(frozen=True)
class Periods:
    """The month, prior month, and same-month-last-year windows for a close."""

    month: str
    start: date
    end: date
    prior_month: str
    prior_start: date
    prior_end: date
    prior_year_month: str
    prior_year_start: date
    prior_year_end: date


@dataclass(frozen=True)
class MonthPack:
    """Everything ``qbo_month_pack`` gathers for one month's close.

    ``bs_prior`` is the balance sheet at ``periods.prior_end`` (the
    roll-forward opening balance); ``pnl_prior_year`` is ``None`` when its
    lines are empty (the same month a year ago not present yet).
    """

    company_name: str
    periods: Periods
    pnl_current: Report
    pnl_prior: Report
    pnl_prior_year: Report | None
    bs_current: Report
    bs_prior: Report
    tb_current: TrialBalance
    accounts: tuple[Account, ...]


@dataclass(frozen=True)
class TransportResponse:
    """One GET's status code and already-bounds-checked, parsed JSON body."""

    status_code: int
    payload: Mapping[str, object]


class QuickBooksTransport(Protocol):
    """The one call every QuickBooks read is ever allowed to make: a bounded GET."""

    async def get(
        self, url: str, *, headers: Mapping[str, str], timeout: float
    ) -> TransportResponse: ...


def periods_for(month: str) -> Periods:
    """The current, prior, and same-month-last-year windows for ``month`` (``YYYY-MM``).

    Plain calendar code, no I/O. Raises ``ValueError`` for anything not
    matching ``^\\d{4}-(0[1-9]|1[0-2])$``.
    """
    if not _MONTH_RE.fullmatch(month):
        raise ValueError(f"invalid month: {month!r}")
    year, mon = int(month[:4]), int(month[5:7])
    start = date(year, mon, 1)
    end = date(year, mon, calendar.monthrange(year, mon)[1])
    if mon == 1:
        prior_year, prior_mon = year - 1, 12
    else:
        prior_year, prior_mon = year, mon - 1
    prior_start = date(prior_year, prior_mon, 1)
    prior_end = date(prior_year, prior_mon, calendar.monthrange(prior_year, prior_mon)[1])
    prior_year_year = year - 1
    prior_year_start = date(prior_year_year, mon, 1)
    prior_year_end = date(prior_year_year, mon, calendar.monthrange(prior_year_year, mon)[1])
    return Periods(
        month=month,
        start=start,
        end=end,
        prior_month=f"{prior_year:04d}-{prior_mon:02d}",
        prior_start=prior_start,
        prior_end=prior_end,
        prior_year_month=f"{prior_year_year:04d}-{mon:02d}",
        prior_year_start=prior_year_start,
        prior_year_end=prior_year_end,
    )


def _sanitize_text(value: str) -> str:
    """Strip control characters and cap length; keep the rest verbatim, as data."""
    return _CONTROL_CHARS_RE.sub("", value)[:_MAX_TEXT_LENGTH]


def _parse_cents(connector: ConnectorConfig, raw: object) -> int:
    """Integer cents from a decimal string, via ``Decimal`` — never ``float``.

    An empty string is 0 (verify). Anything that isn't a string, or a string
    that isn't a valid decimal number, raises ``ConnectError(kind="generic")``.
    """
    if not isinstance(raw, str):
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    text = raw.strip()
    if text == "":
        return 0
    try:
        value = Decimal(text)
    except InvalidOperation as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    cents = (value * 100).to_integral_value(rounding=ROUND_HALF_UP)
    return int(cents)


def _validate_realm_id(connector: ConnectorConfig, realm_id: str) -> None:
    if not _REALM_ID_RE.fullmatch(realm_id):
        raise ConnectError(error_text(connector, "generic"), kind="generic")


def _require_client_id(connector: ConnectorConfig, secrets: SecretsPort) -> None:
    """Fail closed, before any I/O, when the Intuit client id isn't stored yet."""
    try:
        secrets.get(connector.oauth.client_id_config_key)
    except Exception as error:  # noqa: BLE001 - fail closed on any secrets-port error
        raise ConnectError(error_text(connector, "not_connected"), kind="not_connected") from error


def _report_url(realm_id: str, kind: str, *, start: date | None, end: date) -> str:
    report_name = _REPORT_NAMES[kind]
    params: dict[str, str] = {}
    if start is not None:
        params["start_date"] = start.isoformat()
    params["end_date"] = end.isoformat()
    params["accounting_method"] = "Accrual"
    return f"{_QB_BASE}/v3/company/{realm_id}/reports/{report_name}?{urlencode(params)}"


def _account_query_url(realm_id: str) -> str:
    query = urlencode({"query": "select * from Account"})
    return f"{_QB_BASE}/v3/company/{realm_id}/query?{query}"


def _require_allowed_url(connector: ConnectorConfig, url: str, *, realm_id: str) -> None:
    """Refuse anything but our own host and one of the two read paths, before any I/O."""
    parsed = urlsplit(url)
    if f"{parsed.scheme}://{parsed.netloc}" != _QB_BASE:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    report_match = _REPORT_PATH_RE.fullmatch(parsed.path)
    if report_match is not None:
        if report_match.group("realm") != realm_id:
            raise ConnectError(error_text(connector, "generic"), kind="generic")
        return
    account_match = _ACCOUNT_QUERY_PATH_RE.fullmatch(parsed.path)
    if account_match is not None:
        if account_match.group("realm") != realm_id:
            raise ConnectError(error_text(connector, "generic"), kind="generic")
        return
    raise ConnectError(error_text(connector, "generic"), kind="generic")


def _require_ok(connector: ConnectorConfig, response: TransportResponse) -> None:
    if response.status_code >= 400:
        raise ConnectError(
            error_text(connector, "generic"), kind="generic", status=response.status_code
        )


def _col_data(row: Mapping[str, object]) -> list[Mapping[str, object]]:
    raw = row.get("ColData")
    if not isinstance(raw, list):
        return []
    return [item for item in raw if isinstance(item, dict)]


def _col_text(col: Mapping[str, object]) -> str:
    value = col.get("value")
    return _sanitize_text(value) if isinstance(value, str) else ""


def _col_id(col: Mapping[str, object]) -> str:
    value = col.get("id")
    return value if isinstance(value, str) else ""


def _report_rows(payload: Mapping[str, object]) -> list[Mapping[str, object]]:
    rows_obj = payload.get("Rows")
    if not isinstance(rows_obj, dict):
        return []
    raw = rows_obj.get("Row")
    if not isinstance(raw, list):
        return []
    return [row for row in raw if isinstance(row, dict)]


def _section_lines(
    connector: ConnectorConfig, section: Mapping[str, object], mapped_section: str
) -> list[ReportLine]:
    nested = section.get("Rows")
    if not isinstance(nested, dict):
        return []
    raw = nested.get("Row")
    if not isinstance(raw, list):
        return []
    lines: list[ReportLine] = []
    for row in raw:
        if not isinstance(row, dict) or row.get("type") != "Data":
            continue
        cols = _col_data(row)
        if len(cols) < 2:
            continue
        lines.append(
            ReportLine(
                account_id=_col_id(cols[0]),
                name=_col_text(cols[0]),
                section=mapped_section,
                amount_cents=_parse_cents(connector, cols[1].get("value")),
            )
        )
    return lines


def _section_summary_cents(connector: ConnectorConfig, section: Mapping[str, object]) -> int | None:
    summary = section.get("Summary")
    if not isinstance(summary, dict):
        return None
    cols = _col_data(summary)
    if not cols:
        return None
    return _parse_cents(connector, cols[-1].get("value"))


def _parse_report(
    connector: ConnectorConfig,
    payload: Mapping[str, object],
    *,
    kind: str,
    start: date | None,
    end: date,
) -> tuple[Report, str]:
    header = payload.get("Header")
    currency = ""
    company_name = ""
    if isinstance(header, dict):
        currency_raw = header.get("Currency")
        currency = currency_raw if isinstance(currency_raw, str) else ""
        company_raw = header.get("CompanyName")
        company_name = _sanitize_text(company_raw) if isinstance(company_raw, str) else ""
    groups = _PNL_GROUPS if kind == "profit_and_loss" else _BS_GROUPS
    total_group = _PNL_TOTAL_GROUP if kind == "profit_and_loss" else _BS_TOTAL_GROUP
    lines: list[ReportLine] = []
    reported_total_cents = 0
    for section in _report_rows(payload):
        if section.get("type") != "Section":
            continue
        group = section.get("group")
        if not isinstance(group, str):
            continue
        mapped = groups.get(group)
        if mapped is not None:
            lines.extend(_section_lines(connector, section, mapped))
        if group == total_group:
            summary_cents = _section_summary_cents(connector, section)
            if summary_cents is not None:
                reported_total_cents = summary_cents
    report = Report(
        kind=kind,
        start=start,
        end=end,
        currency=currency,
        lines=tuple(lines),
        reported_total_cents=reported_total_cents,
    )
    return report, company_name


def _parse_trial_balance(
    connector: ConnectorConfig, payload: Mapping[str, object], *, as_of: date
) -> TrialBalance:
    lines: list[TrialBalanceLine] = []
    debit_total = 0
    credit_total = 0
    for row in _report_rows(payload):
        cols = _col_data(row)
        if len(cols) < 3:
            continue
        debit_cents = _parse_cents(connector, cols[1].get("value"))
        credit_cents = _parse_cents(connector, cols[2].get("value"))
        if row.get("type") == "Total":
            debit_total = debit_cents
            credit_total = credit_cents
            continue
        lines.append(
            TrialBalanceLine(
                account_id=_col_id(cols[0]),
                name=_col_text(cols[0]),
                debit_cents=debit_cents,
                credit_cents=credit_cents,
            )
        )
    return TrialBalance(
        as_of=as_of,
        lines=tuple(lines),
        debit_total_cents=debit_total,
        credit_total_cents=credit_total,
    )


def _parse_accounts(
    connector: ConnectorConfig, payload: Mapping[str, object]
) -> tuple[Account, ...]:
    query_response = payload.get("QueryResponse")
    if not isinstance(query_response, dict):
        return ()
    raw = query_response.get("Account")
    if not isinstance(raw, list):
        return ()
    accounts: list[Account] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        id_raw = item.get("Id")
        if not isinstance(id_raw, str) or not id_raw:
            continue
        name_raw = item.get("Name")
        name = _sanitize_text(name_raw) if isinstance(name_raw, str) else ""
        type_raw = item.get("AccountType")
        account_type = _sanitize_text(type_raw) if isinstance(type_raw, str) else ""
        note_raw = item.get(_ACCOUNT_NOTE_FIELD)
        note = _sanitize_text(note_raw) if isinstance(note_raw, str) else ""
        accounts.append(
            Account(
                account_id=id_raw,
                name=name,
                account_type=account_type,
                current_balance_cents=_parse_cents(connector, item.get("CurrentBalance")),
                note=note,
            )
        )
    return tuple(accounts)


async def _fetch_report(
    connector: ConnectorConfig,
    realm_id: str,
    transport: QuickBooksTransport,
    *,
    kind: str,
    start: date | None,
    end: date,
) -> tuple[Report, str]:
    url = _report_url(realm_id, kind, start=start, end=end)
    _require_allowed_url(connector, url, realm_id=realm_id)
    response = await transport.get(url, headers=_READ_HEADERS, timeout=DEFAULT_TIMEOUT_SECONDS)
    _require_ok(connector, response)
    return _parse_report(connector, response.payload, kind=kind, start=start, end=end)


async def _fetch_trial_balance(
    connector: ConnectorConfig, realm_id: str, transport: QuickBooksTransport, *, as_of: date
) -> TrialBalance:
    url = _report_url(realm_id, "trial_balance", start=None, end=as_of)
    _require_allowed_url(connector, url, realm_id=realm_id)
    response = await transport.get(url, headers=_READ_HEADERS, timeout=DEFAULT_TIMEOUT_SECONDS)
    _require_ok(connector, response)
    return _parse_trial_balance(connector, response.payload, as_of=as_of)


async def _fetch_accounts(
    connector: ConnectorConfig, realm_id: str, transport: QuickBooksTransport
) -> tuple[Account, ...]:
    url = _account_query_url(realm_id)
    _require_allowed_url(connector, url, realm_id=realm_id)
    response = await transport.get(url, headers=_READ_HEADERS, timeout=DEFAULT_TIMEOUT_SECONDS)
    _require_ok(connector, response)
    return _parse_accounts(connector, response.payload)


async def qbo_profit_and_loss(
    person: str = DEFAULT_PERSON,
    *,
    start: date,
    end: date,
    realm_id: str,
    transport: QuickBooksTransport,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> Report:
    """Read one profit-and-loss report (accrual basis) for ``[start, end]``."""
    connector = load_connector("quickbooks", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    _require_client_id(connector, secrets_port)
    _validate_realm_id(connector, realm_id)
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_profit_and_loss", "started", operation_id)
    try:
        report, _company_name = await _fetch_report(
            connector, realm_id, transport, kind="profit_and_loss", start=start, end=end
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "qbo_profit_and_loss", "failed", operation_id
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_profit_and_loss", "succeeded", operation_id)
    return report


async def qbo_balance_sheet(
    person: str = DEFAULT_PERSON,
    *,
    as_of: date,
    realm_id: str,
    transport: QuickBooksTransport,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> Report:
    """Read one balance sheet report as of ``as_of``."""
    connector = load_connector("quickbooks", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    _require_client_id(connector, secrets_port)
    _validate_realm_id(connector, realm_id)
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_balance_sheet", "started", operation_id)
    try:
        report, _company_name = await _fetch_report(
            connector, realm_id, transport, kind="balance_sheet", start=None, end=as_of
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "qbo_balance_sheet", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_balance_sheet", "succeeded", operation_id)
    return report


async def qbo_trial_balance(
    person: str = DEFAULT_PERSON,
    *,
    as_of: date,
    realm_id: str,
    transport: QuickBooksTransport,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> TrialBalance:
    """Read the trial balance as of ``as_of``."""
    connector = load_connector("quickbooks", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    _require_client_id(connector, secrets_port)
    _validate_realm_id(connector, realm_id)
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_trial_balance", "started", operation_id)
    try:
        trial_balance = await _fetch_trial_balance(connector, realm_id, transport, as_of=as_of)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "qbo_trial_balance", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_trial_balance", "succeeded", operation_id)
    return trial_balance


async def qbo_accounts(
    person: str = DEFAULT_PERSON,
    *,
    realm_id: str,
    transport: QuickBooksTransport,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> tuple[Account, ...]:
    """Read every account: name, type, current balance, and note (the injection vector)."""
    connector = load_connector("quickbooks", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    _require_client_id(connector, secrets_port)
    _validate_realm_id(connector, realm_id)
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_accounts", "started", operation_id)
    try:
        accounts = await _fetch_accounts(connector, realm_id, transport)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "qbo_accounts", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_accounts", "succeeded", operation_id)
    return accounts


async def qbo_month_pack(
    person: str = DEFAULT_PERSON,
    *,
    month: str,
    realm_id: str,
    transport: QuickBooksTransport,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> MonthPack:
    """Gather everything one month's close needs.

    Current, prior, and prior-year profit and loss; current and opening
    (prior-end) balance sheet; the current trial balance; and every account.
    Calls the internal fetch helpers directly (not the four public tools
    above), so this makes exactly one audited call of its own, not five
    nested ones.
    """
    connector = load_connector("quickbooks", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    _require_client_id(connector, secrets_port)
    _validate_realm_id(connector, realm_id)
    periods = periods_for(month)
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_month_pack", "started", operation_id)
    try:
        pnl_current, company_name = await _fetch_report(
            connector,
            realm_id,
            transport,
            kind="profit_and_loss",
            start=periods.start,
            end=periods.end,
        )
        pnl_prior, _ = await _fetch_report(
            connector,
            realm_id,
            transport,
            kind="profit_and_loss",
            start=periods.prior_start,
            end=periods.prior_end,
        )
        pnl_prior_year_report, _ = await _fetch_report(
            connector,
            realm_id,
            transport,
            kind="profit_and_loss",
            start=periods.prior_year_start,
            end=periods.prior_year_end,
        )
        pnl_prior_year = pnl_prior_year_report if pnl_prior_year_report.lines else None
        bs_current, _ = await _fetch_report(
            connector, realm_id, transport, kind="balance_sheet", start=None, end=periods.end
        )
        bs_prior, _ = await _fetch_report(
            connector, realm_id, transport, kind="balance_sheet", start=None, end=periods.prior_end
        )
        tb_current = await _fetch_trial_balance(connector, realm_id, transport, as_of=periods.end)
        accounts = await _fetch_accounts(connector, realm_id, transport)
        pack = MonthPack(
            company_name=company_name,
            periods=periods,
            pnl_current=pnl_current,
            pnl_prior=pnl_prior,
            pnl_prior_year=pnl_prior_year,
            bs_current=bs_current,
            bs_prior=bs_prior,
            tb_current=tb_current,
            accounts=accounts,
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "qbo_month_pack", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "qbo_month_pack", "succeeded", operation_id)
    return pack


class HttpxQuickBooksTransport:
    """The only network implementation of :class:`QuickBooksTransport`.

    Wraps ``httpx.AsyncClient.get`` only: no redirects, a 15 second timeout, a
    64 KiB response cap, and one silent refresh-and-retry on a 401 — the same
    hardening :mod:`gates.graph_read` applies to Microsoft Graph. Holds its
    own token bundle (loaded through :mod:`gates.tokens`) so a caller never
    sees or passes an access token.
    """

    def __init__(
        self,
        *,
        person: str,
        client: httpx.AsyncClient,
        secrets: SecretsPort | None = None,
        catalog_dir: Path | None = None,
    ) -> None:
        self._person = person
        self._client = client
        self._secrets = secrets if secrets is not None else default_secrets_port()
        self._connector = load_connector("quickbooks", catalog_dir=catalog_dir)
        self._bundle: TokenBundle | None = None

    async def _load_bundle(self) -> TokenBundle:
        try:
            bundle = load_tokens(self._secrets, self._connector.name, self._person)
        except TokenStoreError as error:
            raise ConnectError(error_text(self._connector, "generic"), kind="generic") from error
        if bundle is None:
            raise ConnectError(error_text(self._connector, "not_connected"), kind="not_connected")
        return bundle

    async def _refresh(self, bundle: TokenBundle) -> TokenBundle:
        if bundle.refresh_token is None or bundle.is_refresh_token_expired():
            raise ConnectError(
                error_text(self._connector, "needs_reconnect"), kind="needs_reconnect"
            )
        refreshed = await refresh_access_token_async(
            self._connector,
            self._secrets,
            refresh_token=bundle.refresh_token,
            client=self._client,
            previous_account=bundle.account,
        )
        try:
            store_tokens(self._secrets, self._connector.name, self._person, refreshed)
        except TokenStoreError as error:
            raise ConnectError(error_text(self._connector, "generic"), kind="generic") from error
        self._bundle = refreshed
        return refreshed

    async def _bundle_or_raise(self) -> TokenBundle:
        bundle = self._bundle if self._bundle is not None else await self._load_bundle()
        if bundle.is_access_token_stale(buffer_seconds=PROACTIVE_REFRESH_BUFFER_SECONDS):
            bundle = await self._refresh(bundle)
        self._bundle = bundle
        return bundle

    async def _one_get(
        self, url: str, bundle: TokenBundle, *, headers: Mapping[str, str], timeout: float
    ) -> TransportResponse:
        merged = {**headers, "Authorization": f"{bundle.token_type} {bundle.access_token}"}
        try:
            response = await self._client.get(
                url, headers=merged, timeout=timeout, follow_redirects=False
            )
        except Exception as error:  # noqa: BLE001 - never leak transport internals
            raise ConnectError(error_text(self._connector, "generic"), kind="generic") from error
        if 300 <= response.status_code < 400:
            raise ConnectError(error_text(self._connector, "generic"), kind="redirect_refused")
        if len(response.content) > MAX_RESPONSE_BYTES:
            raise ConnectError(error_text(self._connector, "generic"), kind="generic")
        if response.status_code == 401:
            empty: dict[str, object] = {}
            return TransportResponse(status_code=401, payload=empty)
        try:
            payload = response.json()
        except ValueError as error:
            raise ConnectError(error_text(self._connector, "generic"), kind="generic") from error
        if not isinstance(payload, dict):
            raise ConnectError(error_text(self._connector, "generic"), kind="generic")
        return TransportResponse(status_code=response.status_code, payload=payload)

    async def get(
        self, url: str, *, headers: Mapping[str, str], timeout: float
    ) -> TransportResponse:
        bundle = await self._bundle_or_raise()
        response = await self._one_get(url, bundle, headers=headers, timeout=timeout)
        if response.status_code == 401:
            bundle = await self._refresh(bundle)
            response = await self._one_get(url, bundle, headers=headers, timeout=timeout)
            if response.status_code == 401:
                raise ConnectError(error_text(self._connector, "denied"), kind="denied")
        return response
