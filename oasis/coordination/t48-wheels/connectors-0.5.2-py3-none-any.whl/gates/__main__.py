"""``python -m gates`` / the ``gates`` console script.

``gates/__init__.py`` already imports ``gates.connect``, so running
``python -m gates.connect`` re-imports it under the ``__main__`` name and
Python warns (``RuntimeWarning: 'gates.connect' found in sys.modules``).
Running ``python -m gates`` instead executes this module as ``__main__``,
which is never the same name as ``gates.connect``, so no such collision
happens.
"""

from __future__ import annotations

import sys
from collections.abc import Sequence

from gates.connect import main as _connect_main


def main(argv: Sequence[str] | None = None) -> int:
    """``python -m gates connect <name> [--person NAME]`` or ``status``."""
    return _connect_main(list(sys.argv[1:] if argv is None else argv))


if __name__ == "__main__":
    raise SystemExit(main())
