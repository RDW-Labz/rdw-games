"""``WriteResult`` — the one outcome shape every connector write action returns.

Owned by CM (T27). Both Microsoft (``gates.graph_write``) and Google
(``gates.google_api``) write actions return this same frozen dataclass, so a
caller never has to special-case a provider to read back what happened.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class WriteResult:
    """Whether a write succeeded, the affected item's id, and a plain-words detail.

    ``id`` is the created or affected resource's id when the provider returns
    one (empty string otherwise, e.g. after a fire-and-forget send). ``detail``
    is a short, fixed, plain-words status such as ``"sent"`` or ``"created"`` —
    never a mail body, subject, address, file text, or chat text. ``web_url``
    is the item's own link (Graph's ``webLink``/``webUrl``, Google's
    ``htmlLink``/``webViewLink``, or a fixed Gmail link) when the provider
    gives one, so a plan report can link to what it did. ``previous_folder``
    is where a moved item used to be, so a move can be undone.
    """

    ok: bool
    id: str = ""
    detail: str = ""
    web_url: str = ""
    previous_folder: str = ""
