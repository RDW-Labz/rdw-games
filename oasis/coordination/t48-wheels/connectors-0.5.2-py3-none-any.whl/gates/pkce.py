"""PKCE (RFC 7636) verifier/challenge pairs and OAuth ``state`` values.

Every connect flow generates a fresh, unpredictable verifier/challenge pair
and a fresh, single-use ``state``. Nothing here is ever logged: these values
are not secrets stored long-term, but the verifier is sensitive for the
lifetime of one connect attempt and must never appear in an error message.
"""

from __future__ import annotations

import base64
import hashlib
import secrets as _stdlib_secrets
from dataclasses import dataclass

#: 64 random bytes -> 86 base64url characters, inside the RFC 7636 43-128 range.
_VERIFIER_BYTES = 64
_STATE_BYTES = 32


@dataclass(frozen=True)
class PkcePair:
    """One PKCE verifier/challenge pair for a single connect attempt."""

    verifier: str
    challenge: str
    method: str = "S256"


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def new_pkce_pair() -> PkcePair:
    """Generate a fresh, unpredictable PKCE verifier/challenge pair."""
    verifier = _b64url(_stdlib_secrets.token_bytes(_VERIFIER_BYTES))
    challenge = _b64url(hashlib.sha256(verifier.encode("ascii")).digest())
    return PkcePair(verifier=verifier, challenge=challenge)


def new_state() -> str:
    """Generate a fresh, unpredictable, single-use OAuth ``state`` value."""
    return _b64url(_stdlib_secrets.token_bytes(_STATE_BYTES))
