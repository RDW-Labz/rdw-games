"""Connect a person to a connector: click-only OAuth 2.0 + PKCE, and status.

The one flow an employee ever sees is: click Connect, click Allow in the
browser window we open, come back. Everything else — the loopback listener,
PKCE, the state check, the token exchange, the one read call that proves the
connection works, and storing the result — happens without a terminal, an
API key, or a settings screen ever appearing.

``connect()`` runs that whole flow once. ``test_connection()`` re-runs just
the one read call, refreshing the access token first (proactively, or after
a 401) with no prompt. ``get_status()`` answers the Connect page's tiles
without ever touching the network or revealing a token. A provider's
response is DATA at every step: only a few named fields are ever read out of
it, and nothing it contains can change what this module does next.
"""

from __future__ import annotations

import argparse
import contextlib
import sys
import uuid
from collections.abc import Callable, Sequence
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Final

import httpx

from gates import audit
from gates.account import fetch_account
from gates.browser import BrowserOpener, default_opener
from gates.catalog import CatalogNotFoundError, ConnectorConfig, load_catalog, load_connector
from gates.errors import ConnectError, error_text
from gates.loopback import LoopbackServer
from gates.oauth_http import (
    Unauthorized,
    build_authorize_url,
    exchange_code,
    refresh_access_token,
    run_connection_test,
)
from gates.pkce import new_pkce_pair, new_state
from gates.secrets_port import SecretsPort, default_secrets_port
from gates.tokens import TokenBundle, TokenStoreError, delete_tokens, load_tokens, store_tokens

#: How long connect() waits for the person to click Allow.
DEFAULT_WAIT_SECONDS: Final = 180.0
#: Refresh an access token this far ahead of its real expiry, proactively.
PROACTIVE_REFRESH_BUFFER_SECONDS: Final = 60.0
#: Phase 0 has exactly one person: Braden, user zero.
DEFAULT_PERSON: Final = "braden"

_STATUS_LABELS: Final = {
    "connected": "Connected",
    "not_connected": "Not connected",
    "needs_attention": "Needs attention",
}


@dataclass(frozen=True)
class ConnectOutcome:
    """What a connect/test attempt did, in a shape a UI can render directly."""

    connector: str
    person: str
    status: str
    message: str
    steps: tuple[str, ...]


@dataclass(frozen=True)
class ConnectorStatus:
    """One catalog connector's status line, for the Connect page's tiles."""

    connector: str
    display_name: str
    state: str
    reason: str
    #: T44 (decision #161) — the signed-in person's own account label, from the
    #: stored bundle only (never a network call); `None` when not connected or
    #: not yet fetched.
    account: str | None = None


class _Announcer:
    """Records plain-words step descriptions and forwards them to the UI."""

    def __init__(self, on_step: Callable[[str], None] | None) -> None:
        self._on_step = on_step
        self._steps: list[str] = []

    def __call__(self, message: str) -> None:
        self._steps.append(message)
        if self._on_step is not None:
            self._on_step(message)

    @property
    def steps(self) -> tuple[str, ...]:
        return tuple(self._steps)


def connect(
    name: str,
    person: str = DEFAULT_PERSON,
    *,
    catalog_dir: Path | None = None,
    opener: BrowserOpener | None = None,
    transport: httpx.Client | None = None,
    secrets: SecretsPort | None = None,
    on_step: Callable[[str], None] | None = None,
    wait_seconds: float = DEFAULT_WAIT_SECONDS,
) -> ConnectOutcome:
    """Run one full click-only connect flow for ``name`` and ``person``."""
    connector = load_connector(name, catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    announce = _Announcer(on_step)
    open_browser = opener if opener is not None else default_opener
    client = transport if transport is not None else httpx.Client()
    owns_client = transport is None
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "connect", "started", operation_id)
    try:
        outcome = _run_connect(
            connector, person, announce, open_browser, client, secrets_port, wait_seconds
        )
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "connect", "succeeded", operation_id)
        return outcome
    except ConnectError as error:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "connect", "failed", operation_id)
        return ConnectOutcome(connector.name, person, error.kind, error.args[0], announce.steps)
    finally:
        if owns_client:
            client.close()


def _run_connect(
    connector: ConnectorConfig,
    person: str,
    announce: _Announcer,
    open_browser: BrowserOpener,
    client: httpx.Client,
    secrets_port: SecretsPort,
    wait_seconds: float,
) -> ConnectOutcome:
    for step in connector.setup_steps:
        announce(step)
    pkce = new_pkce_pair()
    state = new_state()
    server = LoopbackServer()
    server.start()
    try:
        redirect_uri = f"http://{connector.oauth.redirect_host}:{server.port}/callback"
        url = build_authorize_url(
            connector, secrets_port, state=state, pkce=pkce, redirect_uri=redirect_uri
        )
        if not open_browser(url):
            raise ConnectError(error_text(connector, "denied"), kind="denied")
        result = server.wait(wait_seconds)
    finally:
        server.close()

    if result is None or result.error is not None:
        raise ConnectError(error_text(connector, "denied"), kind="denied")
    if result.code is None or result.state is None or result.state != state:
        # Single-use state mismatch: refuse before ever contacting the token
        # endpoint. This is not the provider's data to influence.
        raise ConnectError(error_text(connector, "denied"), kind="state_mismatch")

    announce(connector.connection_test.description)
    bundle = exchange_code(
        connector,
        secrets_port,
        code=result.code,
        code_verifier=pkce.verifier,
        redirect_uri=redirect_uri,
        client=client,
    )
    _test_or_denied(connector, bundle, client)
    account = fetch_account(connector.name, bundle.access_token, http=client)
    bundle = replace(bundle, account=account)
    try:
        store_tokens(secrets_port, connector.name, person, bundle)
    except TokenStoreError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    announce(f"{connector.display_name} connected.")
    return ConnectOutcome(
        connector.name,
        person,
        "connected",
        f"{connector.display_name} is connected.",
        announce.steps,
    )


def _test_or_denied(connector: ConnectorConfig, bundle: TokenBundle, client: httpx.Client) -> None:
    try:
        run_connection_test(connector, bundle, client)
    except Unauthorized as error:
        raise ConnectError(error_text(connector, "denied"), kind="denied") from error


def refresh_if_needed(
    name: str,
    person: str = DEFAULT_PERSON,
    *,
    catalog_dir: Path | None = None,
    transport: httpx.Client | None = None,
    secrets: SecretsPort | None = None,
    force: bool = False,
) -> TokenBundle:
    """Refresh this connector's stored token if it is stale (or ``force``).

    Silent: never opens a browser, never prompts. Raises :class:`ConnectError`
    with plain words if there is nothing to refresh or the provider refuses.
    """
    connector = load_connector(name, catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    client = transport if transport is not None else httpx.Client()
    owns_client = transport is None
    try:
        bundle = _load_bundle_or_raise(connector, person, secrets_port)
        if not force and not bundle.is_access_token_stale(
            buffer_seconds=PROACTIVE_REFRESH_BUFFER_SECONDS
        ):
            return bundle
        return _refresh(connector, secrets_port, person, bundle, client)
    finally:
        if owns_client:
            client.close()


def _load_bundle_or_raise(
    connector: ConnectorConfig, person: str, secrets_port: SecretsPort
) -> TokenBundle:
    try:
        bundle = load_tokens(secrets_port, connector.name, person)
    except TokenStoreError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if bundle is None:
        raise ConnectError(error_text(connector, "denied"), kind="not_connected")
    return bundle


def _refresh(
    connector: ConnectorConfig,
    secrets_port: SecretsPort,
    person: str,
    bundle: TokenBundle,
    client: httpx.Client,
) -> TokenBundle:
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "refresh", "started", operation_id)
    if bundle.is_refresh_token_expired() or bundle.refresh_token is None:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "refresh", "failed", operation_id)
        raise ConnectError(error_text(connector, "needs_reconnect"), kind="needs_reconnect")
    try:
        refreshed = refresh_access_token(
            connector,
            secrets_port,
            refresh_token=bundle.refresh_token,
            client=client,
            previous_account=bundle.account,
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "refresh", "failed", operation_id)
        raise
    try:
        store_tokens(secrets_port, connector.name, person, refreshed)
    except TokenStoreError as error:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "refresh", "failed", operation_id)
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "refresh", "succeeded", operation_id)
    return refreshed


def test_connection(
    name: str,
    person: str = DEFAULT_PERSON,
    *,
    catalog_dir: Path | None = None,
    transport: httpx.Client | None = None,
    secrets: SecretsPort | None = None,
    on_step: Callable[[str], None] | None = None,
) -> ConnectOutcome:
    """Run the connector's one read call, refreshing the token first if stale.

    Refreshes proactively (ahead of expiry) or once more after a 401, with no
    prompt either way — this is what makes a forced expiry silent.
    """
    connector = load_connector(name, catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    announce = _Announcer(on_step)
    client = transport if transport is not None else httpx.Client()
    owns_client = transport is None
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "test_connection", "started", operation_id)
    try:
        try:
            bundle = load_tokens(secrets_port, connector.name, person)
        except TokenStoreError as error:
            raise ConnectError(error_text(connector, "generic"), kind="generic") from error
        if bundle is None:
            return ConnectOutcome(
                connector.name,
                person,
                "not_connected",
                error_text(connector, "denied"),
                announce.steps,
            )
        if bundle.is_access_token_stale(buffer_seconds=PROACTIVE_REFRESH_BUFFER_SECONDS):
            announce(f"Refreshing your {connector.display_name} connection.")
            bundle = _refresh(connector, secrets_port, person, bundle, client)
        announce(connector.connection_test.description)
        try:
            run_connection_test(connector, bundle, client)
        except Unauthorized:
            announce(f"Refreshing your {connector.display_name} connection.")
            bundle = _refresh(connector, secrets_port, person, bundle, client)
            run_connection_test(connector, bundle, client)
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "test_connection", "succeeded", operation_id)
        return ConnectOutcome(
            connector.name,
            person,
            "connected",
            f"{connector.display_name} is connected.",
            announce.steps,
        )
    except ConnectError as error:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "test_connection", "failed", operation_id)
        return ConnectOutcome(connector.name, person, error.kind, error.args[0], announce.steps)
    finally:
        if owns_client:
            client.close()


def get_status(
    person: str = DEFAULT_PERSON,
    *,
    catalog_dir: Path | None = None,
    secrets: SecretsPort | None = None,
) -> tuple[ConnectorStatus, ...]:
    """Every catalog connector's Connected/Not connected/Needs attention state.

    Never touches the network and never reveals a token: it only checks
    whether a bundle is stored and, if so, whether its own recorded expiry
    metadata says it needs attention.
    """
    secrets_port = secrets if secrets is not None else default_secrets_port()
    connectors = load_catalog(catalog_dir=catalog_dir)
    return tuple(_status_for(connector, person, secrets_port) for connector in connectors)


def _status_for(
    connector: ConnectorConfig, person: str, secrets_port: SecretsPort
) -> ConnectorStatus:
    try:
        bundle = load_tokens(secrets_port, connector.name, person)
    except TokenStoreError:
        return ConnectorStatus(
            connector.name,
            connector.display_name,
            "needs_attention",
            "We could not read the saved connection. Click Connect again.",
        )
    if bundle is None:
        return ConnectorStatus(
            connector.name,
            connector.display_name,
            "not_connected",
            "Not connected yet. Click Connect to get started.",
        )
    if bundle.refresh_token is None:
        return ConnectorStatus(
            connector.name,
            connector.display_name,
            "needs_attention",
            error_text(connector, "expired"),
            bundle.account,
        )
    if bundle.is_refresh_token_expired(now=datetime.now(UTC)):
        return ConnectorStatus(
            connector.name,
            connector.display_name,
            "needs_attention",
            error_text(connector, "needs_reconnect"),
            bundle.account,
        )
    return ConnectorStatus(
        connector.name,
        connector.display_name,
        "connected",
        f"{connector.display_name} is connected.",
        bundle.account,
    )


def disconnect(
    name: str,
    person: str = DEFAULT_PERSON,
    *,
    catalog_dir: Path | None = None,
    secrets: SecretsPort | None = None,
) -> str:
    """Remove a connector's stored tokens for ``person``. Idempotent; no provider revoke call.

    Returns ``"removed"`` when a stored connection actually existed, else
    ``"already_gone"`` — so a caller (agent-core) can word the result. Every
    call is audited (connector, person, which of the two happened, timestamp)
    — never the token, the stored bundle, or the account label.
    """
    connector = load_connector(name, catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    removed = delete_tokens(secrets_port, connector.name, person)
    result = "removed" if removed else "already_gone"
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "disconnect", result, str(uuid.uuid4()))
    return result


def _print_status(person: str, catalog_dir: Path | None) -> int:
    for row in get_status(person, catalog_dir=catalog_dir):
        print(f"{row.display_name}: {_STATUS_LABELS[row.state]} — {row.reason}")
    return 0


def _print_connect(name: str, person: str, catalog_dir: Path | None) -> int:
    outcome = connect(name, person, catalog_dir=catalog_dir, on_step=print)
    print(outcome.message)
    return 0 if outcome.status == "connected" else 1


def main(argv: Sequence[str] | None = None) -> int:
    """CLI: ``python -m gates.connect connect <name> [--person NAME]`` or ``status``."""
    parser = argparse.ArgumentParser(prog="gates.connect")
    subparsers = parser.add_subparsers(dest="command", required=True)

    connect_parser = subparsers.add_parser("connect", help="connect one connector")
    connect_parser.add_argument("name")
    connect_parser.add_argument("--person", default=DEFAULT_PERSON)
    connect_parser.add_argument("--catalog-dir", type=Path, default=None)

    status_parser = subparsers.add_parser("status", help="show every connector's status")
    status_parser.add_argument("--person", default=DEFAULT_PERSON)
    status_parser.add_argument("--catalog-dir", type=Path, default=None)

    args = parser.parse_args(list(sys.argv[1:] if argv is None else argv))
    try:
        if args.command == "status":
            return _print_status(args.person, args.catalog_dir)
        return _print_connect(args.name, args.person, args.catalog_dir)
    except CatalogNotFoundError as error:
        print(str(error))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
