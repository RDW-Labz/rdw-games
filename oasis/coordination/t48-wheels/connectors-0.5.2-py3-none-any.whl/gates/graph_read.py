"""Read-only Microsoft Graph calls for the daily-summary skill (T16b).

Two async reads, each against its own connector's stored token:

* :func:`calendar_today` — ``outlook-calendar``'s ``me/calendarView`` for a
  caller-supplied window. Cancelled events and events the person declined
  are dropped before they ever become a :class:`CalendarEvent`.
* :func:`unread_mail` — ``outlook``'s inbox unread count, plus up to 10 of
  the newest unread messages' subject/sender/received time. Never a body or
  bodyPreview: those fields are never in the Graph ``$select`` and are never
  read out of a response even if a server ever sent one back.

Every provider response is DATA: only the named fields below are ever read
out of it. Subjects and calendar titles are sanitised (control characters
stripped, truncated to 200 characters) before they leave this module, but
otherwise kept verbatim — they are still data, never instructions, for
whatever reads a :class:`CalendarEvent` or :class:`MailHeader` next.

Hardening mirrors :mod:`gates.oauth_http`: HTTPS Graph host only, no
redirects followed, a 15 second timeout, a 64 KiB response cap, and a single
silent refresh-and-retry on a 401. Every failure surfaces as the same
:class:`~gates.errors.ConnectError` the rest of this package uses — never a
raw token, URL, header, or response body.

Each call appends one :mod:`gates.audit` event (connector, person, outcome
only) so a read is visible in the append-only trail without ever writing a
subject, sender, or title to it.
"""

from __future__ import annotations

import asyncio
import contextlib
import html
import re
import time
import uuid
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Final
from urllib.parse import quote, urlencode

import httpx

from gates import audit
from gates.catalog import ConnectorConfig, load_connector
from gates.connect import DEFAULT_PERSON, PROACTIVE_REFRESH_BUFFER_SECONDS
from gates.errors import ConnectError, error_text
from gates.oauth_http import (
    DEFAULT_TIMEOUT_SECONDS,
    MAX_RESPONSE_BYTES,
    refresh_access_token_async,
)
from gates.secrets_port import SecretsPort, default_secrets_port
from gates.tokens import TokenBundle, TokenStoreError, load_tokens, store_tokens

_GRAPH_BASE = "https://graph.microsoft.com/v1.0"
_CALENDAR_TOP = 50
_CALENDAR_SELECT = "subject,start,end,isAllDay,isCancelled,responseStatus"
_MAIL_INBOX_URL = f"{_GRAPH_BASE}/me/mailFolders/inbox?$select=unreadItemCount"
_MAIL_HEADERS_SELECT = "subject,from,receivedDateTime,toRecipients,ccRecipients"
#: T27b — one `/me` call per read fills `MailHeader.account_address`; a failure
#: here never fails the read (see `_fetch_account_address`).
_ACCOUNT_ADDRESS_URL = f"{_GRAPH_BASE}/me?$select=mail,userPrincipalName"
#: `unread_mail`'s `limit` is always capped to this range: at least one
#: newest-unread header, never more than ten.
MAIL_LIMIT_MIN = 1
MAIL_LIMIT_MAX = 10
DEFAULT_MAIL_LIMIT = 10
_MAX_TEXT_LENGTH = 200
_PREVIEW_MAX_LENGTH = 255
_FILE_TEXT_MAX_CHARS = 20_000
_CONTROL_CHARS_RE = re.compile(r"[\x00-\x1f\x7f]")
_HTML_TAG_RE = re.compile(r"<[^>]+>")

#: T27 (CM) — bounds for the new search/list reads. Same shape as the T16b
#: mail bounds above: a caller's `limit` is always capped into this range.
SEARCH_MAIL_LIMIT_MIN = 1
SEARCH_MAIL_LIMIT_MAX = 25
DEFAULT_SEARCH_MAIL_LIMIT = 10

FILE_LIMIT_MIN = 1
FILE_LIMIT_MAX = 25
DEFAULT_FILE_LIMIT = 10

TEAMS_CHATS_LIMIT_MIN = 1
TEAMS_CHATS_LIMIT_MAX = 25
DEFAULT_TEAMS_CHATS_LIMIT = 10

TEAMS_MESSAGES_LIMIT_MIN = 1
TEAMS_MESSAGES_LIMIT_MAX = 25
DEFAULT_TEAMS_MESSAGES_LIMIT = 20

_TEAMS_LIST_LIMIT = 20
_CHANNELS_LIST_LIMIT = 50

#: T48 (#215/#218) — total wall-clock budget for one read call (every HTTP call it
#: makes). At the deadline, the read returns what it has with ``complete=False``
#: instead of blocking further. A single monotonic deadline is computed once per
#: read call and passed down; each HTTP call's own timeout is
#: ``min(DEFAULT_TIMEOUT_SECONDS, time left before the deadline)``.
READ_BUDGET_SECONDS: Final = 10.0

#: T48 — `recent_mail`'s `top` is capped into this range, same shape as every
#: other bounded `limit`/`top` in this module.
RECENT_MAIL_TOP_MIN = 1
RECENT_MAIL_TOP_MAX = 100
DEFAULT_RECENT_MAIL_TOP = 25

#: T48 — `teams_recent_chats`'s `max_chats` is capped into this range.
TEAMS_MAX_CHATS_MIN = 1
TEAMS_MAX_CHATS_MAX = 200
DEFAULT_TEAMS_MAX_CHATS = 50

#: T48 — per-chat message fetches inside `teams_recent_chats` run at most this
#: many at once.
_TEAMS_MESSAGE_FETCH_CONCURRENCY = 5

#: Only these MIME types are read out as text (T27); everything else comes
#: back `truncated=True, text=""` since Graph's item content endpoint offers
#: no reliable plain-text export for other formats.
_TEXT_MIME_TYPES = frozenset({"text/plain"})

#: T27 retry (decision #115) — no-reply local parts `is_no_reply_address` matches
#: exactly, after normalization (lowercased, `+`-suffix dropped, `-`/`_`/`.` removed).
_NO_REPLY_LOCAL_PARTS = frozenset(
    {
        "noreply",
        "donotreply",
        "mailerdaemon",
        "postmaster",
        "bounce",
        "bounces",
        "notification",
        "notifications",
        "alert",
        "alerts",
    }
)
_NO_REPLY_PREFIXES = ("noreply", "donotreply")


def is_no_reply_address(address: str) -> bool:
    """True when ``address``'s local part is a no-reply alias (decision #115).

    The local part is the text before the last ``@``, lowercased, with anything
    from the first ``+`` dropped and every ``-``/``_``/``.`` removed. An empty
    ``address`` is never a no-reply address.
    """
    if not address:
        return False
    local_part = address.rsplit("@", 1)[0].lower().split("+", 1)[0]
    for char in ("-", "_", "."):
        local_part = local_part.replace(char, "")
    if local_part in _NO_REPLY_LOCAL_PARTS:
        return True
    return local_part.startswith(_NO_REPLY_PREFIXES)


@dataclass(frozen=True)
class CalendarEvent:
    """One kept calendar event: not cancelled, not declined."""

    start_iso: str
    end_iso: str
    subject: str
    all_day: bool
    id: str = ""
    location: str = ""
    attendees: tuple[str, ...] = ()


@dataclass(frozen=True)
class CalendarDay:
    """The events `calendarView` returned for one window, most-recent first."""

    events: tuple[CalendarEvent, ...]
    truncated: bool
    complete: bool = True


@dataclass(frozen=True)
class MailHeader:
    """One unread (or matched) message's subject, sender, and received time.

    ``id`` and ``preview`` are only ever populated by :func:`search_mail`
    (Gmail's `gmail_unread`/`gmail_search` reuse this same dataclass);
    :func:`unread_mail` never requests or reads a body/bodyPreview field, so
    those callers leave them at their empty defaults.

    ``to_addresses``/``cc_addresses`` (T27b) are every To/Cc address, lower-cased,
    in message order, deduped, with no display name; populated by both
    :func:`unread_mail` and :func:`search_mail`. ``account_address`` is the
    signed-in person's own address for that connector, lower-cased, from one
    ``GET /me`` call per read — empty when that call fails, which never fails
    the read itself.
    """

    subject: str
    sender: str
    received_iso: str
    id: str = ""
    preview: str = ""
    sender_address: str = ""
    to_addresses: tuple[str, ...] = ()
    cc_addresses: tuple[str, ...] = ()
    account_address: str = ""


@dataclass(frozen=True)
class UnreadMail:
    """The inbox's unread count, plus up to 10 of the newest unread headers."""

    count: int
    messages: tuple[MailHeader, ...] = field(default_factory=tuple)
    complete: bool = True


@dataclass(frozen=True)
class RecentMail:
    """T48 (#218) — messages received in the last `window_hours`, newest first.

    Unlike :class:`UnreadMail`, this never carries an unread count — a mail
    summary leads with what is new, not how much is unread (#215 item 4).
    """

    messages: tuple[MailHeader, ...]
    window_hours: int
    complete: bool = True


@dataclass(frozen=True)
class MailSearch:
    """The messages a mail search matched, most-relevant/newest first."""

    messages: tuple[MailHeader, ...]
    truncated: bool


@dataclass(frozen=True)
class FileItem:
    """One file's metadata only — never its content."""

    id: str
    name: str
    path: str
    web_url: str
    modified_iso: str
    size: int


@dataclass(frozen=True)
class FileList:
    """The files a search matched."""

    items: tuple[FileItem, ...]
    truncated: bool


@dataclass(frozen=True)
class FileText:
    """One file's extracted plain text, capped at 20,000 characters."""

    id: str
    name: str
    text: str
    truncated: bool


@dataclass(frozen=True)
class TeamsChat:
    """One Teams chat's id, topic, member display names, and newest message time.

    T48 (#215): `last_iso` is the newest *real* message time this read found by
    fetching the chat's own messages — never the listing's own (eventually
    consistent) sort key. `new_messages` are that chat's messages newer than the
    caller's `last_read` for this chat (reusing :class:`TeamsMessage`, the same
    type :func:`teams_chat_messages` returns).
    """

    id: str
    topic: str
    members: tuple[str, ...]
    last_iso: str
    new_messages: tuple[TeamsMessage, ...] = ()


@dataclass(frozen=True)
class TeamsChats:
    """The chats `teams_recent_chats` returned, sorted by newest message first.

    T48 (#215): `truncated` keeps its old meaning (a listing page/nextLink was
    not followed) for compatibility; `complete` is `False` for that reason too,
    plus a deadline hit or any per-chat message fetch failing. `read_marks` is,
    per chat id, the newest message time this read saw — the caller persists it
    and passes it back as `last_read` next time.
    """

    chats: tuple[TeamsChat, ...]
    truncated: bool
    complete: bool = True
    read_marks: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class TeamsMessage:
    """One Teams chat message: plain text only, HTML stripped."""

    id: str
    sender: str
    text: str
    at_iso: str


@dataclass(frozen=True)
class TeamsMessages:
    """The messages `teams_chat_messages` returned, newest first."""

    messages: tuple[TeamsMessage, ...]
    truncated: bool


@dataclass(frozen=True)
class TeamsChannel:
    """One channel in one joined team."""

    team_id: str
    team_name: str
    channel_id: str
    channel_name: str


@dataclass(frozen=True)
class TeamsChannels:
    """Every channel in every team `teams_list_channels` returned."""

    channels: tuple[TeamsChannel, ...]
    truncated: bool


def _sanitize_text(value: str, *, max_length: int = _MAX_TEXT_LENGTH) -> str:
    """Strip control characters and cap length; keep the rest verbatim, as data."""
    return _CONTROL_CHARS_RE.sub("", value)[:max_length]


def _strip_html(value: str) -> str:
    """Plain text from an HTML chat message body: tags dropped, entities unescaped."""
    without_tags = _HTML_TAG_RE.sub(" ", value)
    unescaped = html.unescape(without_tags)
    collapsed = re.sub(r"\s+", " ", unescaped).strip()
    return _sanitize_text(collapsed)


def _is_redirect(status_code: int) -> bool:
    return 300 <= status_code < 400


_GRAPH_CODE_RE = re.compile(r"[A-Za-z0-9_.]{1,64}")


def _graph_error_code(payload: Mapping[str, object] | None) -> str | None:
    """The response's ``error.code``, only when it is a plain vendor code.

    Never ``error.message`` or any other body text: a code outside
    ``[A-Za-z0-9_.]{1,64}`` is treated as absent.
    """
    if not isinstance(payload, dict):
        return None
    error = payload.get("error")
    if not isinstance(error, dict):
        return None
    code = error.get("code")
    if not isinstance(code, str) or not _GRAPH_CODE_RE.fullmatch(code):
        return None
    return code


def _require_graph_url(connector: ConnectorConfig, url: str) -> None:
    if not url.startswith(f"{_GRAPH_BASE}/"):
        raise ConnectError(error_text(connector, "generic"), kind="generic")


async def _get_json(
    connector: ConnectorConfig,
    url: str,
    bundle: TokenBundle,
    client: httpx.AsyncClient,
    *,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
) -> tuple[dict[str, object] | None, int]:
    """One bounded, redirect-refusing GET. Returns ``(None, 401)`` for the caller to retry."""
    _require_graph_url(connector, url)
    headers = {"Authorization": f"{bundle.token_type} {bundle.access_token}"}
    try:
        response = await client.get(
            url, headers=headers, timeout=timeout, follow_redirects=False
        )
    except Exception as error:  # noqa: BLE001 - never leak transport internals
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if _is_redirect(response.status_code):
        raise ConnectError(error_text(connector, "generic"), kind="redirect_refused")
    if len(response.content) > MAX_RESPONSE_BYTES:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if response.status_code == 401:
        return None, 401
    try:
        payload = response.json()
    except ValueError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if not isinstance(payload, dict):
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return payload, response.status_code


async def _refresh_and_store_async(
    connector: ConnectorConfig,
    secrets: SecretsPort,
    person: str,
    bundle: TokenBundle,
    client: httpx.AsyncClient,
) -> TokenBundle:
    if bundle.refresh_token is None or bundle.is_refresh_token_expired():
        raise ConnectError(error_text(connector, "needs_reconnect"), kind="needs_reconnect")
    refreshed = await refresh_access_token_async(
        connector,
        secrets,
        refresh_token=bundle.refresh_token,
        client=client,
        previous_account=bundle.account,
    )
    try:
        store_tokens(secrets, connector.name, person, refreshed)
    except TokenStoreError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    return refreshed


async def _load_and_refresh_bundle_async(
    connector: ConnectorConfig, person: str, secrets: SecretsPort, client: httpx.AsyncClient
) -> TokenBundle:
    try:
        bundle = load_tokens(secrets, connector.name, person)
    except TokenStoreError as error:
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if bundle is None:
        raise ConnectError(error_text(connector, "denied"), kind="not_connected")
    if bundle.is_access_token_stale(buffer_seconds=PROACTIVE_REFRESH_BUFFER_SECONDS):
        bundle = await _refresh_and_store_async(connector, secrets, person, bundle, client)
    return bundle


async def _request_json(
    connector: ConnectorConfig,
    person: str,
    url: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
) -> tuple[dict[str, object], TokenBundle]:
    """GET ``url``, refreshing and retrying exactly once on a 401."""
    payload, status = await _get_json(connector, url, bundle, client, timeout=timeout)
    if status == 401:
        bundle = await _refresh_and_store_async(connector, secrets, person, bundle, client)
        payload, status = await _get_json(connector, url, bundle, client, timeout=timeout)
        if status == 401:
            raise ConnectError(error_text(connector, "denied"), kind="denied")
    if status >= 400:
        raise ConnectError(
            error_text(connector, "generic"),
            kind="generic",
            status=status,
            graph_code=_graph_error_code(payload),
        )
    if payload is None:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return payload, bundle


async def _get_bytes(
    connector: ConnectorConfig, url: str, bundle: TokenBundle, client: httpx.AsyncClient
) -> tuple[bytes | None, int]:
    """One bounded, redirect-refusing GET for raw (non-JSON) content."""
    _require_graph_url(connector, url)
    headers = {"Authorization": f"{bundle.token_type} {bundle.access_token}"}
    try:
        response = await client.get(
            url, headers=headers, timeout=DEFAULT_TIMEOUT_SECONDS, follow_redirects=False
        )
    except Exception as error:  # noqa: BLE001 - never leak transport internals
        raise ConnectError(error_text(connector, "generic"), kind="generic") from error
    if _is_redirect(response.status_code):
        raise ConnectError(error_text(connector, "generic"), kind="redirect_refused")
    if len(response.content) > MAX_RESPONSE_BYTES:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if response.status_code == 401:
        return None, 401
    return response.content, response.status_code


async def _request_bytes(
    connector: ConnectorConfig,
    person: str,
    url: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
) -> tuple[bytes, TokenBundle]:
    """GET ``url`` for raw content, refreshing and retrying exactly once on a 401."""
    content, status = await _get_bytes(connector, url, bundle, client)
    if status == 401:
        bundle = await _refresh_and_store_async(connector, secrets, person, bundle, client)
        content, status = await _get_bytes(connector, url, bundle, client)
        if status == 401:
            raise ConnectError(error_text(connector, "denied"), kind="denied")
    if status >= 400:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if content is None:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return content, bundle


def _calendar_url(start: datetime, end: datetime) -> str:
    params = {
        "startDateTime": start.isoformat(),
        "endDateTime": end.isoformat(),
        "$select": _CALENDAR_SELECT,
        "$orderby": "start/dateTime",
        "$top": str(_CALENDAR_TOP),
    }
    return f"{_GRAPH_BASE}/me/calendarView?{urlencode(params)}"


def _is_declined(item: Mapping[str, object]) -> bool:
    response_status = item.get("responseStatus")
    if not isinstance(response_status, dict):
        return False
    return response_status.get("response") == "declined"


def _parse_event(item: object) -> CalendarEvent | None:
    if not isinstance(item, dict):
        return None
    if item.get("isCancelled") is True or _is_declined(item):
        return None
    start = item.get("start")
    end = item.get("end")
    start_iso = start.get("dateTime") if isinstance(start, dict) else None
    end_iso = end.get("dateTime") if isinstance(end, dict) else None
    if not isinstance(start_iso, str) or not isinstance(end_iso, str):
        return None
    subject_raw = item.get("subject")
    subject = _sanitize_text(subject_raw) if isinstance(subject_raw, str) else ""
    return CalendarEvent(
        start_iso=start_iso,
        end_iso=end_iso,
        subject=subject,
        all_day=item.get("isAllDay") is True,
    )


def _parse_calendar_day(payload: Mapping[str, object]) -> CalendarDay:
    raw_events = payload.get("value")
    items = raw_events if isinstance(raw_events, list) else []
    parsed = (_parse_event(item) for item in items)
    events = tuple(event for event in parsed if event is not None)
    truncated = isinstance(payload.get("@odata.nextLink"), str)
    return CalendarDay(events=events, truncated=truncated, complete=not truncated)


async def calendar_today(
    person: str = DEFAULT_PERSON,
    *,
    start: datetime,
    end: datetime,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> CalendarDay:
    """Read ``outlook-calendar``'s events for ``[start, end)``. Drops cancelled and declined."""
    connector = load_connector("outlook-calendar", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_calendar", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        url = _calendar_url(start, end)
        payload, _bundle = await _request_json(
            connector, person, url, bundle, client=client, secrets=secrets_port
        )
        day = _parse_calendar_day(payload)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "read_calendar", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_calendar", "succeeded", operation_id)
    return day


def _mail_headers_url(limit: int) -> str:
    capped = max(MAIL_LIMIT_MIN, min(MAIL_LIMIT_MAX, limit))
    params = {
        "$filter": "isRead eq false",
        "$orderby": "receivedDateTime desc",
        "$select": _MAIL_HEADERS_SELECT,
        "$top": str(capped),
    }
    return f"{_GRAPH_BASE}/me/mailFolders/inbox/messages?{urlencode(params)}"


def _parse_unread_count(connector: ConnectorConfig, payload: Mapping[str, object]) -> int:
    value = payload.get("unreadItemCount")
    if not isinstance(value, int) or isinstance(value, bool):
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    if value < 0:
        raise ConnectError(error_text(connector, "generic"), kind="generic")
    return value


def _sender_display(item: Mapping[str, object]) -> str:
    from_raw = item.get("from")
    if not isinstance(from_raw, dict):
        return ""
    email_address = from_raw.get("emailAddress")
    if not isinstance(email_address, dict):
        return ""
    name = email_address.get("name")
    if isinstance(name, str) and name:
        return _sanitize_text(name)
    address = email_address.get("address")
    return _sanitize_text(address) if isinstance(address, str) else ""


def _recipient_addresses(item: Mapping[str, object], key: str) -> tuple[str, ...]:
    """Every address in ``item[key]`` (a Graph recipients array), lower-cased and deduped.

    No display name, only ``emailAddress.address``, in message order.
    """
    raw = item.get(key)
    if not isinstance(raw, list):
        return ()
    seen: set[str] = set()
    addresses: list[str] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        email_address = entry.get("emailAddress")
        if not isinstance(email_address, dict):
            continue
        address_raw = email_address.get("address")
        if not isinstance(address_raw, str):
            continue
        address = address_raw.strip().lower()
        if address and address not in seen:
            seen.add(address)
            addresses.append(address)
    return tuple(addresses)


async def _fetch_account_address(
    connector: ConnectorConfig,
    person: str,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
) -> str:
    """The signed-in person's own address (``mail``, else ``userPrincipalName``), lower-cased.

    Never raises: a failure of this ``/me`` call must never fail the read that calls it.
    """
    try:
        payload, _bundle = await _request_json(
            connector, person, _ACCOUNT_ADDRESS_URL, bundle, client=client, secrets=secrets
        )
    except ConnectError:
        return ""
    mail_raw = payload.get("mail")
    if isinstance(mail_raw, str) and mail_raw:
        return mail_raw.strip().lower()
    upn_raw = payload.get("userPrincipalName")
    if isinstance(upn_raw, str) and upn_raw:
        return upn_raw.strip().lower()
    return ""


def _parse_mail_header(item: object) -> MailHeader | None:
    if not isinstance(item, dict):
        return None
    subject_raw = item.get("subject")
    subject = _sanitize_text(subject_raw) if isinstance(subject_raw, str) else ""
    received_raw = item.get("receivedDateTime")
    received_iso = received_raw if isinstance(received_raw, str) else ""
    return MailHeader(
        subject=subject,
        sender=_sender_display(item),
        received_iso=received_iso,
        to_addresses=_recipient_addresses(item, "toRecipients"),
        cc_addresses=_recipient_addresses(item, "ccRecipients"),
    )


def _parse_mail_headers_raw(payload: Mapping[str, object]) -> tuple[MailHeader, ...]:
    """Every header the payload's `value` parses to, uncapped (T48: `recent_mail`)."""
    raw = payload.get("value")
    items = raw if isinstance(raw, list) else []
    parsed = (_parse_mail_header(item) for item in items)
    return tuple(header for header in parsed if header is not None)


def _parse_mail_headers(payload: Mapping[str, object]) -> tuple[MailHeader, ...]:
    return _parse_mail_headers_raw(payload)[:MAIL_LIMIT_MAX]


async def unread_mail(
    person: str = DEFAULT_PERSON,
    *,
    limit: int = DEFAULT_MAIL_LIMIT,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> UnreadMail:
    """Read ``outlook``'s unread count and up to ``limit`` (capped 1-10) newest unread headers.

    Never requests or keeps a body or bodyPreview field.
    """
    connector = load_connector("outlook", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_mail", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        count_payload, bundle = await _request_json(
            connector, person, _MAIL_INBOX_URL, bundle, client=client, secrets=secrets_port
        )
        count = _parse_unread_count(connector, count_payload)
        headers_payload, bundle = await _request_json(
            connector,
            person,
            _mail_headers_url(limit),
            bundle,
            client=client,
            secrets=secrets_port,
        )
        account_address = await _fetch_account_address(
            connector, person, bundle, client=client, secrets=secrets_port
        )
        messages = tuple(
            replace(header, account_address=account_address)
            for header in _parse_mail_headers(headers_payload)
        )
        complete = not isinstance(headers_payload.get("@odata.nextLink"), str)
        result = UnreadMail(count=count, messages=messages, complete=complete)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "read_mail", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_mail", "succeeded", operation_id)
    return result


def _recent_mail_url(since_iso: str, top: int) -> str:
    params = {
        "$filter": f"receivedDateTime ge {since_iso}",
        "$orderby": "receivedDateTime desc",
        "$select": _MAIL_HEADERS_SELECT,
        "$top": str(top),
    }
    return f"{_GRAPH_BASE}/me/mailFolders/inbox/messages?{urlencode(params)}"


async def recent_mail(
    person: str = DEFAULT_PERSON,
    *,
    hours: int = 24,
    top: int = DEFAULT_RECENT_MAIL_TOP,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
    budget_seconds: float = READ_BUDGET_SECONDS,
) -> RecentMail:
    """Read ``outlook`` messages received in the last ``hours``, newest first.

    T48 (#215 item 4): a mail summary leads with what is new, not the unread
    count — this never fetches or returns one. Follows ``@odata.nextLink``
    until ``top`` (capped into
    [``RECENT_MAIL_TOP_MIN``, ``RECENT_MAIL_TOP_MAX``]) messages are collected,
    the deadline (``budget_seconds`` wall-clock, shared across every page) is
    hit, or there is no more nextLink; ``complete`` is ``False`` whenever a
    nextLink is left unfollowed for either reason.
    """
    connector = load_connector("outlook", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    capped_top = max(RECENT_MAIL_TOP_MIN, min(RECENT_MAIL_TOP_MAX, top))
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_mail", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        deadline = time.monotonic() + budget_seconds
        since_iso = (datetime.now(UTC) - timedelta(hours=hours)).isoformat()
        headers: list[MailHeader] = []
        complete = True
        url: str | None = _recent_mail_url(since_iso, capped_top)
        while url is not None:
            time_left = _time_left(deadline)
            if time_left <= 0:
                complete = False
                break
            payload, bundle = await _request_json(
                connector,
                person,
                url,
                bundle,
                client=client,
                secrets=secrets_port,
                timeout=min(DEFAULT_TIMEOUT_SECONDS, time_left),
            )
            headers.extend(_parse_mail_headers_raw(payload))
            next_link = payload.get("@odata.nextLink")
            if len(headers) >= capped_top:
                headers = headers[:capped_top]
                if isinstance(next_link, str):
                    complete = False
                url = None
            elif isinstance(next_link, str):
                url = next_link
            else:
                url = None
        account_address = await _fetch_account_address(
            connector, person, bundle, client=client, secrets=secrets_port
        )
        messages = tuple(
            replace(header, account_address=account_address) for header in headers
        )
        result = RecentMail(messages=messages, window_hours=hours, complete=complete)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "read_mail", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_mail", "succeeded", operation_id)
    return result


# --- T27 (CM): search_mail -----------------------------------------------

_MAIL_SEARCH_SELECT = "id,subject,from,receivedDateTime,bodyPreview,toRecipients,ccRecipients"

#: T27 follow-up (decision #114) — `search_mail`/`gmail_search` filter validation. A
#: search text field is capped at this many characters after strip; anything outside
#: this whitelist is refused (the whitelist is the injection guard, not sanitisation).
_SEARCH_TEXT_MAX_LENGTH = 200
_SEARCH_TEXT_ALLOWED_RE = re.compile(r"^[A-Za-z0-9 @._'+,-]*$")
_SEARCH_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


@dataclass(frozen=True)
class MailSearchFilters:
    """The five `search_mail`/`gmail_search` filters, stripped and validated."""

    query: str
    sender: str
    subject: str
    after: str
    before: str


def _clean_search_text(value: str | None) -> str:
    stripped = (value or "").strip()
    if not stripped:
        return ""
    if len(stripped) > _SEARCH_TEXT_MAX_LENGTH:
        raise ValueError("search text is too long")
    if not _SEARCH_TEXT_ALLOWED_RE.match(stripped):
        raise ValueError("search text has characters that are not allowed")
    return stripped


def _clean_search_date(value: str | None) -> str:
    stripped = (value or "").strip()
    if not stripped:
        return ""
    if not _SEARCH_DATE_RE.match(stripped):
        raise ValueError("after and before must be YYYY-MM-DD")
    try:
        datetime.strptime(stripped, "%Y-%m-%d")
    except ValueError as error:
        raise ValueError("after and before must be YYYY-MM-DD") from error
    return stripped


def validate_mail_search_filters(
    *,
    query: str | None,
    sender: str | None,
    subject: str | None,
    after: str | None,
    before: str | None,
) -> MailSearchFilters:
    """Strip and validate the five `search_mail`/`gmail_search` filters.

    Shared by both connectors' search calls so the rules (at least one filter given,
    a real ``YYYY-MM-DD`` date, ``after`` before ``before``, a 200-character cap and an
    injection-guard character whitelist on free text) are enforced exactly once.
    """
    query_clean = _clean_search_text(query)
    sender_clean = _clean_search_text(sender)
    subject_clean = _clean_search_text(subject)
    after_clean = _clean_search_date(after)
    before_clean = _clean_search_date(before)
    if not (query_clean or sender_clean or subject_clean or after_clean or before_clean):
        raise ValueError("search needs at least one of query, sender, subject, after, before")
    if after_clean and before_clean and after_clean >= before_clean:
        raise ValueError("after must be before before")
    return MailSearchFilters(
        query=query_clean,
        sender=sender_clean,
        subject=subject_clean,
        after=after_clean,
        before=before_clean,
    )


def _quote_if_multiword(value: str) -> str:
    return f'"{value}"' if " " in value else value


def _build_outlook_mail_search(filters: MailSearchFilters) -> str:
    """The KQL search text for `search_mail`'s `$search`, before the outer quoting/escaping."""
    parts: list[str] = []
    if filters.sender:
        parts.append(f"from:{_quote_if_multiword(filters.sender)}")
    if filters.subject:
        parts.append(f"subject:{_quote_if_multiword(filters.subject)}")
    if filters.after:
        parts.append(f"received>={filters.after}")
    if filters.before:
        parts.append(f"received<{filters.before}")
    if filters.query:
        parts.append(filters.query)
    return " ".join(parts)


def _within_search_date_range(received_iso: str, after: str, before: str) -> bool:
    date_part = received_iso[:10]
    if after and date_part < after:
        return False
    if before and date_part >= before:
        return False
    return True


def filter_by_sender(messages: tuple[MailHeader, ...], sender: str) -> tuple[MailHeader, ...]:
    """T27 retry (decision #115): apply the sender match, then drop no-reply senders.

    A no-op when ``sender`` is empty (no filter was asked for). Otherwise keeps only
    messages whose ``sender`` (display name) or ``sender_address`` contains ``sender``,
    case-insensitively — subject, preview and body never count — then drops any of
    those whose ``sender_address`` is a no-reply alias per :func:`is_no_reply_address`.
    """
    if not sender:
        return messages
    term = sender.lower()
    matched = tuple(
        header
        for header in messages
        if term in header.sender.lower() or term in header.sender_address.lower()
    )
    return tuple(header for header in matched if not is_no_reply_address(header.sender_address))


def filter_and_sort_search_results(
    messages: tuple[MailHeader, ...], *, after: str, before: str
) -> tuple[MailHeader, ...]:
    """Drop messages outside ``after``/``before`` (belt and braces); sort newest first."""
    if after or before:
        messages = tuple(
            header
            for header in messages
            if _within_search_date_range(header.received_iso, after, before)
        )
    return tuple(sorted(messages, key=lambda header: header.received_iso, reverse=True))


def _mail_search_url(query: str, limit: int) -> str:
    capped = max(SEARCH_MAIL_LIMIT_MIN, min(SEARCH_MAIL_LIMIT_MAX, limit))
    escaped_query = query.replace("\\", "\\\\").replace('"', '\\"')
    params = {
        "$search": f'"{escaped_query}"',
        "$select": _MAIL_SEARCH_SELECT,
        "$top": str(capped),
    }
    return f"{_GRAPH_BASE}/me/messages?{urlencode(params)}"


def _parse_mail_search_header(item: object) -> MailHeader | None:
    if not isinstance(item, dict):
        return None
    subject_raw = item.get("subject")
    subject = _sanitize_text(subject_raw) if isinstance(subject_raw, str) else ""
    received_raw = item.get("receivedDateTime")
    received_iso = received_raw if isinstance(received_raw, str) else ""
    id_raw = item.get("id")
    message_id = id_raw if isinstance(id_raw, str) else ""
    preview_raw = item.get("bodyPreview")
    preview = (
        _sanitize_text(preview_raw, max_length=_PREVIEW_MAX_LENGTH)
        if isinstance(preview_raw, str)
        else ""
    )
    address = ""
    from_raw = item.get("from")
    if isinstance(from_raw, dict):
        email_address = from_raw.get("emailAddress")
        if isinstance(email_address, dict):
            address_raw = email_address.get("address")
            address = _sanitize_text(address_raw) if isinstance(address_raw, str) else ""
    return MailHeader(
        subject=subject,
        sender=_sender_display(item),
        received_iso=received_iso,
        id=message_id,
        preview=preview,
        sender_address=address,
        to_addresses=_recipient_addresses(item, "toRecipients"),
        cc_addresses=_recipient_addresses(item, "ccRecipients"),
    )


def _parse_mail_search(payload: Mapping[str, object]) -> MailSearch:
    raw = payload.get("value")
    items = raw if isinstance(raw, list) else []
    parsed = (_parse_mail_search_header(item) for item in items)
    messages = tuple(header for header in parsed if header is not None)
    truncated = isinstance(payload.get("@odata.nextLink"), str)
    return MailSearch(messages=messages, truncated=truncated)


async def search_mail(
    person: str = DEFAULT_PERSON,
    *,
    query: str | None = None,
    sender: str | None = None,
    subject: str | None = None,
    after: str | None = None,
    before: str | None = None,
    limit: int = DEFAULT_SEARCH_MAIL_LIMIT,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> MailSearch:
    """Search ``outlook`` mail by sender, subject, a date range, and/or free words.

    At least one of ``query``/``sender``/``subject``/``after``/``before`` must be given
    (non-empty after strip) or this raises ``ValueError``; ``after``/``before`` are
    ``YYYY-MM-DD``, on/after and strictly-before that UTC day. Messages are filtered to
    that range again after the fetch (belt and braces) and returned newest first by
    ``received_iso``.

    Unlike :func:`unread_mail`, this reads ``bodyPreview`` (capped to 255
    characters) because a search result needs enough context to be useful;
    it is still never logged (see ``gates.audit`` — only connector, person,
    action, outcome are ever recorded).
    """
    filters = validate_mail_search_filters(
        query=query, sender=sender, subject=subject, after=after, before=before
    )
    connector = load_connector("outlook", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "search_mail", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        payload, bundle = await _request_json(
            connector,
            person,
            _mail_search_url(_build_outlook_mail_search(filters), limit),
            bundle,
            client=client,
            secrets=secrets_port,
        )
        result = _parse_mail_search(payload)
        account_address = await _fetch_account_address(
            connector, person, bundle, client=client, secrets=secrets_port
        )
        filtered = filter_and_sort_search_results(
            filter_by_sender(result.messages, filters.sender),
            after=filters.after,
            before=filters.before,
        )
        result = MailSearch(
            messages=tuple(
                replace(header, account_address=account_address) for header in filtered
            ),
            truncated=result.truncated,
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "search_mail", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "search_mail", "succeeded", operation_id)
    return result


# --- T27c: get_mail / gmail_get (read one message by id) -------------------

_GET_MAIL_SELECT = "id,subject,from,receivedDateTime,toRecipients,ccRecipients"
MESSAGE_ID_MAX_LENGTH = 512


def is_valid_message_id(message_id: str) -> bool:
    """False for an empty id, one over 512 characters, or one with a control character.

    Shared by :func:`get_mail` and `google_api.gmail_get` so both refuse an invalid
    ``message_id`` the same way, before either makes any network call.
    """
    if not message_id or len(message_id) > MESSAGE_ID_MAX_LENGTH:
        return False
    return not _CONTROL_CHARS_RE.search(message_id)


def _get_mail_url(message_id: str) -> str:
    params = {"$select": _GET_MAIL_SELECT}
    return f"{_GRAPH_BASE}/me/messages/{quote(message_id, safe='')}?{urlencode(params)}"


def _parse_get_mail_header(item: Mapping[str, object]) -> MailHeader:
    subject_raw = item.get("subject")
    subject = _sanitize_text(subject_raw) if isinstance(subject_raw, str) else ""
    received_raw = item.get("receivedDateTime")
    received_iso = received_raw if isinstance(received_raw, str) else ""
    id_raw = item.get("id")
    message_id = id_raw if isinstance(id_raw, str) else ""
    address = ""
    from_raw = item.get("from")
    if isinstance(from_raw, dict):
        email_address = from_raw.get("emailAddress")
        if isinstance(email_address, dict):
            address_raw = email_address.get("address")
            address = _sanitize_text(address_raw) if isinstance(address_raw, str) else ""
    return MailHeader(
        subject=subject,
        sender=_sender_display(item),
        received_iso=received_iso,
        id=message_id,
        sender_address=address,
        to_addresses=_recipient_addresses(item, "toRecipients"),
        cc_addresses=_recipient_addresses(item, "ccRecipients"),
    )


async def get_mail(
    person: str = DEFAULT_PERSON,
    *,
    message_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> MailHeader:
    """Read one ``outlook`` message by id — for reply-verification re-fetch (T27c).

    Never requests or reads a body or bodyPreview field. ``message_id`` is validated
    by :func:`is_valid_message_id` before any network call; an invalid id raises
    ``ConnectError(kind="invalid")``. A 404 (message not found) maps through the same
    error mapping as every other read here.
    """
    connector = load_connector("outlook", catalog_dir=catalog_dir)
    if not is_valid_message_id(message_id):
        raise ConnectError(error_text(connector, "invalid"), kind="invalid")
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_mail", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        payload, bundle = await _request_json(
            connector,
            person,
            _get_mail_url(message_id),
            bundle,
            client=client,
            secrets=secrets_port,
        )
        header = _parse_get_mail_header(payload)
        account_address = await _fetch_account_address(
            connector, person, bundle, client=client, secrets=secrets_port
        )
        result = replace(header, account_address=account_address)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "read_mail", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_mail", "succeeded", operation_id)
    return result


# --- T27 (CM): OneDrive files_search / file_read_text ---------------------

_FILE_SELECT = "id,name,parentReference,webUrl,lastModifiedDateTime,size"


def _files_search_url(query: str, limit: int) -> str:
    capped = max(FILE_LIMIT_MIN, min(FILE_LIMIT_MAX, limit))
    escaped_query = query.replace("'", "''")
    encoded_query = quote(escaped_query, safe="")
    params = {"$select": _FILE_SELECT, "$top": str(capped)}
    return f"{_GRAPH_BASE}/me/drive/root/search(q='{encoded_query}')?{urlencode(params)}"


def _file_path(item: Mapping[str, object]) -> str:
    parent = item.get("parentReference")
    parent_path = ""
    if isinstance(parent, dict):
        path_raw = parent.get("path")
        if isinstance(path_raw, str):
            parent_path = path_raw
    name_raw = item.get("name")
    name = name_raw if isinstance(name_raw, str) else ""
    if not name:
        return parent_path
    return f"{parent_path}/{name}" if parent_path else f"/{name}"


def _parse_file_item(item: object) -> FileItem | None:
    if not isinstance(item, dict):
        return None
    id_raw = item.get("id")
    if not isinstance(id_raw, str) or not id_raw:
        return None
    name_raw = item.get("name")
    name = _sanitize_text(name_raw) if isinstance(name_raw, str) else ""
    web_url_raw = item.get("webUrl")
    web_url = web_url_raw if isinstance(web_url_raw, str) else ""
    modified_raw = item.get("lastModifiedDateTime")
    modified_iso = modified_raw if isinstance(modified_raw, str) else ""
    size_raw = item.get("size")
    size = size_raw if isinstance(size_raw, int) and not isinstance(size_raw, bool) else 0
    return FileItem(
        id=id_raw,
        name=name,
        path=_sanitize_text(_file_path(item), max_length=400),
        web_url=web_url,
        modified_iso=modified_iso,
        size=size,
    )


def _parse_file_list(payload: Mapping[str, object]) -> FileList:
    raw = payload.get("value")
    items = raw if isinstance(raw, list) else []
    parsed = (_parse_file_item(item) for item in items)
    files = tuple(item for item in parsed if item is not None)
    truncated = isinstance(payload.get("@odata.nextLink"), str)
    return FileList(items=files, truncated=truncated)


async def files_search(
    person: str = DEFAULT_PERSON,
    *,
    query: str,
    limit: int = DEFAULT_FILE_LIMIT,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> FileList:
    """Search ``onedrive`` files by ``query``: name/metadata only, never content."""
    connector = load_connector("onedrive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "search_files", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        payload, _bundle = await _request_json(
            connector,
            person,
            _files_search_url(query, limit),
            bundle,
            client=client,
            secrets=secrets_port,
        )
        result = _parse_file_list(payload)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "search_files", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "search_files", "succeeded", operation_id)
    return result


def _file_metadata_url(item_id: str) -> str:
    return f"{_GRAPH_BASE}/me/drive/items/{quote(item_id, safe='')}?$select=id,name,file"


def _file_content_url(item_id: str) -> str:
    return f"{_GRAPH_BASE}/me/drive/items/{quote(item_id, safe='')}/content"


def _decode_file_text(raw: bytes) -> tuple[str, bool]:
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return "", True
    cleaned = _CONTROL_CHARS_RE.sub("", text)
    truncated = len(cleaned) > _FILE_TEXT_MAX_CHARS
    return cleaned[:_FILE_TEXT_MAX_CHARS], truncated


async def file_read_text(
    person: str = DEFAULT_PERSON,
    *,
    item_id: str,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> FileText:
    """Read one ``onedrive`` file as plain text, capped at 20,000 characters.

    Only ``text/plain`` files are read out; every other type (including
    ``.docx``/``.pdf``) comes back ``truncated=True, text=""`` — Graph's item
    content endpoint offers no reliable plain-text export for those formats.
    """
    connector = load_connector("onedrive", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_file_text", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        meta, bundle = await _request_json(
            connector,
            person,
            _file_metadata_url(item_id),
            bundle,
            client=client,
            secrets=secrets_port,
        )
        name_raw = meta.get("name")
        name = _sanitize_text(name_raw) if isinstance(name_raw, str) else ""
        file_info = meta.get("file")
        mime = ""
        if isinstance(file_info, dict):
            mime_raw = file_info.get("mimeType")
            if isinstance(mime_raw, str):
                mime = mime_raw
        if mime not in _TEXT_MIME_TYPES:
            result = FileText(id=item_id, name=name, text="", truncated=True)
        else:
            content, _bundle = await _request_bytes(
                connector,
                person,
                _file_content_url(item_id),
                bundle,
                client=client,
                secrets=secrets_port,
            )
            text, truncated = _decode_file_text(content)
            result = FileText(id=item_id, name=name, text=text, truncated=truncated)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "read_file_text", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_file_text", "succeeded", operation_id)
    return result


# --- T27 (CM): Teams reads -------------------------------------------------

_TEAMS_CHAT_SELECT = "id,topic,lastUpdatedDateTime"


def _teams_recent_chats_url(limit: int) -> str:
    capped = max(TEAMS_CHATS_LIMIT_MIN, min(TEAMS_CHATS_LIMIT_MAX, limit))
    params = {
        "$expand": "members,lastMessagePreview",
        "$orderby": "lastMessagePreview/createdDateTime desc",
        "$select": _TEAMS_CHAT_SELECT,
        "$top": str(capped),
    }
    return f"{_GRAPH_BASE}/me/chats?{urlencode(params)}"


def _chat_members(item: Mapping[str, object]) -> tuple[str, ...]:
    members_raw = item.get("members")
    if not isinstance(members_raw, list):
        return ()
    names: list[str] = []
    for member in members_raw:
        if not isinstance(member, dict):
            continue
        display_raw = member.get("displayName")
        if isinstance(display_raw, str) and display_raw:
            names.append(_sanitize_text(display_raw))
    return tuple(names)


def _parse_teams_chat(item: object) -> TeamsChat | None:
    if not isinstance(item, dict):
        return None
    id_raw = item.get("id")
    if not isinstance(id_raw, str) or not id_raw:
        return None
    topic_raw = item.get("topic")
    topic = _sanitize_text(topic_raw) if isinstance(topic_raw, str) else ""
    last_raw = item.get("lastUpdatedDateTime")
    last_iso = last_raw if isinstance(last_raw, str) else ""
    return TeamsChat(id=id_raw, topic=topic, members=_chat_members(item), last_iso=last_iso)


def _parse_teams_chats(payload: Mapping[str, object]) -> TeamsChats:
    raw = payload.get("value")
    items = raw if isinstance(raw, list) else []
    parsed = (_parse_teams_chat(item) for item in items)
    chats = tuple(chat for chat in parsed if chat is not None)
    truncated = isinstance(payload.get("@odata.nextLink"), str)
    return TeamsChats(chats=chats, truncated=truncated)


def _parse_iso(value: str) -> datetime | None:
    """``value`` parsed as an ISO-8601 timestamp, or ``None`` when it isn't one."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _is_newer_than(candidate_iso: str, threshold_iso: str | None) -> bool:
    """T48 (#215): is ``candidate_iso`` strictly newer than ``threshold_iso``?

    No ``threshold_iso`` (no last-read time for this chat) means every parseable
    candidate counts as new. A candidate that fails to parse is never newer.
    """
    candidate = _parse_iso(candidate_iso)
    if candidate is None:
        return False
    if threshold_iso is None:
        return True
    threshold = _parse_iso(threshold_iso)
    if threshold is None:
        return True
    return candidate > threshold


def _time_left(deadline: float) -> float:
    return deadline - time.monotonic()


async def _fetch_chat_new_messages(
    connector: ConnectorConfig,
    person: str,
    chat: TeamsChat,
    bundle: TokenBundle,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort,
    last_read: Mapping[str, str],
    deadline: float,
    semaphore: asyncio.Semaphore,
) -> tuple[TeamsChat, bool]:
    """One chat's newest messages, filtered to those newer than its `last_read`.

    Returns the chat with `last_iso`/`new_messages` filled from its real
    messages (never the listing's own sort key) and whether the fetch
    succeeded — a deadline already passed or a request failure both count as
    not succeeded, and leave `chat` otherwise unchanged.
    """
    async with semaphore:
        time_left = _time_left(deadline)
        if time_left <= 0:
            return chat, False
        try:
            payload, _bundle = await _request_json(
                connector,
                person,
                _teams_chat_messages_url(chat.id, DEFAULT_TEAMS_MESSAGES_LIMIT),
                bundle,
                client=client,
                secrets=secrets,
                timeout=min(DEFAULT_TIMEOUT_SECONDS, time_left),
            )
        except ConnectError:
            return chat, False
        messages = _parse_teams_messages(payload).messages
        newest_iso = messages[0].at_iso if messages else chat.last_iso
        threshold = last_read.get(chat.id)
        new_messages = tuple(
            message for message in messages if _is_newer_than(message.at_iso, threshold)
        )
        return replace(chat, last_iso=newest_iso, new_messages=new_messages), True


async def teams_recent_chats(
    person: str = DEFAULT_PERSON,
    *,
    limit: int = DEFAULT_TEAMS_CHATS_LIMIT,
    last_read: Mapping[str, str] | None = None,
    max_chats: int = DEFAULT_TEAMS_MAX_CHATS,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
    budget_seconds: float = READ_BUDGET_SECONDS,
) -> TeamsChats:
    """List ``teams``'s chats with each one's *real* newest message.

    T48 (#215): the listing's own sort (`lastMessagePreview/createdDateTime`) is
    eventually consistent and only ever used as a hint for which chats to check.
    For every listed chat (up to `max_chats`, capped
    [``TEAMS_MAX_CHATS_MIN``, ``TEAMS_MAX_CHATS_MAX``], concurrency
    ≤``_TEAMS_MESSAGE_FETCH_CONCURRENCY``) this fetches that chat's newest
    messages, keeps those newer than ``last_read.get(chat_id)`` as
    ``new_messages``, and sorts every chat locally by its real newest message
    time. The whole call (listing pages plus every per-chat fetch) shares one
    ``budget_seconds`` wall-clock budget; at the deadline it returns what it has
    with ``complete=False``.
    """
    connector = load_connector("teams", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    capped_max_chats = max(TEAMS_MAX_CHATS_MIN, min(TEAMS_MAX_CHATS_MAX, max_chats))
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_teams_chats", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        deadline = time.monotonic() + budget_seconds
        listed_chats: list[TeamsChat] = []
        complete = True
        truncated = False
        url: str | None = _teams_recent_chats_url(limit)
        while url is not None:
            time_left = _time_left(deadline)
            if time_left <= 0:
                complete = False
                truncated = True
                break
            payload, bundle = await _request_json(
                connector,
                person,
                url,
                bundle,
                client=client,
                secrets=secrets_port,
                timeout=min(DEFAULT_TIMEOUT_SECONDS, time_left),
            )
            listed_chats.extend(_parse_teams_chats(payload).chats)
            next_link = payload.get("@odata.nextLink")
            if len(listed_chats) >= capped_max_chats:
                listed_chats = listed_chats[:capped_max_chats]
                if isinstance(next_link, str):
                    complete = False
                    truncated = True
                url = None
            elif isinstance(next_link, str):
                url = next_link
            else:
                url = None

        last_read_map = last_read or {}
        semaphore = asyncio.Semaphore(_TEAMS_MESSAGE_FETCH_CONCURRENCY)
        fetched = await asyncio.gather(
            *(
                _fetch_chat_new_messages(
                    connector,
                    person,
                    chat,
                    bundle,
                    client=client,
                    secrets=secrets_port,
                    last_read=last_read_map,
                    deadline=deadline,
                    semaphore=semaphore,
                )
                for chat in listed_chats
            )
        )

        updated_chats: list[TeamsChat] = []
        read_marks: dict[str, str] = {}
        for chat, ok in fetched:
            updated_chats.append(chat)
            if not ok:
                complete = False
            elif chat.last_iso:
                read_marks[chat.id] = chat.last_iso
        updated_chats.sort(key=lambda chat: chat.last_iso, reverse=True)

        result = TeamsChats(
            chats=tuple(updated_chats),
            truncated=truncated,
            complete=complete,
            read_marks=read_marks,
        )
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(connector.name, person, "read_teams_chats", "failed", operation_id)
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_teams_chats", "succeeded", operation_id)
    return result


def _teams_chat_messages_url(chat_id: str, limit: int) -> str:
    capped = max(TEAMS_MESSAGES_LIMIT_MIN, min(TEAMS_MESSAGES_LIMIT_MAX, limit))
    params = {"$orderby": "createdDateTime desc", "$top": str(capped)}
    return f"{_GRAPH_BASE}/me/chats/{quote(chat_id, safe='')}/messages?{urlencode(params)}"


def _message_sender(item: Mapping[str, object]) -> str:
    from_raw = item.get("from")
    if not isinstance(from_raw, dict):
        return ""
    user = from_raw.get("user")
    if isinstance(user, dict):
        display_raw = user.get("displayName")
        if isinstance(display_raw, str) and display_raw:
            return _sanitize_text(display_raw)
    application = from_raw.get("application")
    if isinstance(application, dict):
        display_raw = application.get("displayName")
        if isinstance(display_raw, str) and display_raw:
            return _sanitize_text(display_raw)
    return ""


def _message_text(item: Mapping[str, object]) -> str:
    body = item.get("body")
    if not isinstance(body, dict):
        return ""
    content_raw = body.get("content")
    content = content_raw if isinstance(content_raw, str) else ""
    content_type = body.get("contentType")
    if content_type == "html":
        return _strip_html(content)
    return _sanitize_text(content)


def _parse_teams_message(item: object) -> TeamsMessage | None:
    if not isinstance(item, dict):
        return None
    id_raw = item.get("id")
    if not isinstance(id_raw, str) or not id_raw:
        return None
    created_raw = item.get("createdDateTime")
    at_iso = created_raw if isinstance(created_raw, str) else ""
    return TeamsMessage(
        id=id_raw, sender=_message_sender(item), text=_message_text(item), at_iso=at_iso
    )


def _parse_teams_messages(payload: Mapping[str, object]) -> TeamsMessages:
    raw = payload.get("value")
    items = raw if isinstance(raw, list) else []
    parsed = (_parse_teams_message(item) for item in items)
    messages = tuple(message for message in parsed if message is not None)
    truncated = isinstance(payload.get("@odata.nextLink"), str)
    return TeamsMessages(messages=messages, truncated=truncated)


async def teams_chat_messages(
    person: str = DEFAULT_PERSON,
    *,
    chat_id: str,
    limit: int = DEFAULT_TEAMS_MESSAGES_LIMIT,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> TeamsMessages:
    """Read one Teams chat's newest messages, HTML stripped to plain text."""
    connector = load_connector("teams", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_teams_messages", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        payload, _bundle = await _request_json(
            connector,
            person,
            _teams_chat_messages_url(chat_id, limit),
            bundle,
            client=client,
            secrets=secrets_port,
        )
        result = _parse_teams_messages(payload)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "read_teams_messages", "failed", operation_id
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "read_teams_messages", "succeeded", operation_id
        )
    return result


def _joined_teams_url() -> str:
    params = {"$select": "id,displayName", "$top": str(_TEAMS_LIST_LIMIT)}
    return f"{_GRAPH_BASE}/me/joinedTeams?{urlencode(params)}"


def _channels_url(team_id: str) -> str:
    params = {"$select": "id,displayName", "$top": str(_CHANNELS_LIST_LIMIT)}
    return f"{_GRAPH_BASE}/teams/{quote(team_id, safe='')}/channels?{urlencode(params)}"


def _parse_joined_teams(payload: Mapping[str, object]) -> tuple[tuple[str, str], ...]:
    raw = payload.get("value")
    items = raw if isinstance(raw, list) else []
    teams: list[tuple[str, str]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        id_raw = item.get("id")
        if isinstance(id_raw, str) and id_raw:
            name_raw = item.get("displayName")
            name = _sanitize_text(name_raw) if isinstance(name_raw, str) else ""
            teams.append((id_raw, name))
    return tuple(teams)


def _parse_channels(
    payload: Mapping[str, object], team_id: str, team_name: str
) -> tuple[TeamsChannel, ...]:
    raw = payload.get("value")
    items = raw if isinstance(raw, list) else []
    channels: list[TeamsChannel] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        id_raw = item.get("id")
        if isinstance(id_raw, str) and id_raw:
            name_raw = item.get("displayName")
            name = _sanitize_text(name_raw) if isinstance(name_raw, str) else ""
            channels.append(
                TeamsChannel(
                    team_id=team_id, team_name=team_name, channel_id=id_raw, channel_name=name
                )
            )
    return tuple(channels)


async def teams_list_channels(
    person: str = DEFAULT_PERSON,
    *,
    client: httpx.AsyncClient,
    secrets: SecretsPort | None = None,
    catalog_dir: Path | None = None,
) -> TeamsChannels:
    """List every channel in every team the person has joined."""
    connector = load_connector("teams", catalog_dir=catalog_dir)
    secrets_port = secrets if secrets is not None else default_secrets_port()
    operation_id = str(uuid.uuid4())
    with contextlib.suppress(audit.AuditError):
        audit.append_event(connector.name, person, "read_teams_channels", "started", operation_id)
    try:
        bundle = await _load_and_refresh_bundle_async(connector, person, secrets_port, client)
        teams_payload, bundle = await _request_json(
            connector, person, _joined_teams_url(), bundle, client=client, secrets=secrets_port
        )
        truncated = isinstance(teams_payload.get("@odata.nextLink"), str)
        channels: list[TeamsChannel] = []
        for team_id, team_name in _parse_joined_teams(teams_payload):
            channels_payload, bundle = await _request_json(
                connector,
                person,
                _channels_url(team_id),
                bundle,
                client=client,
                secrets=secrets_port,
            )
            if isinstance(channels_payload.get("@odata.nextLink"), str):
                truncated = True
            channels.extend(_parse_channels(channels_payload, team_id, team_name))
        result = TeamsChannels(channels=tuple(channels), truncated=truncated)
    except ConnectError:
        with contextlib.suppress(audit.AuditError):
            audit.append_event(
                connector.name, person, "read_teams_channels", "failed", operation_id
            )
        raise
    with contextlib.suppress(audit.AuditError):
        audit.append_event(
            connector.name, person, "read_teams_channels", "succeeded", operation_id
        )
    return result
