"""Append-only audit trail for connector connect/refresh/test actions.

Mirrors the pattern already used in this repo for OAuth-adjacent audit trails
(``scripts/registration_audit.py`` for T03, ``anorak.secrets_audit`` for T02):
one fsynced JSON line per event, in the platform user data directory, holding
only metadata. Never a token, authorization code, URL, or provider response.
"""

from __future__ import annotations

import getpass
import json
import os
import sys
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Final, Literal

#: Every action name any connector logs (Graph and Google alike). Google's writes
#: reuse the Graph write names below (``connector`` in the record tells them
#: apart), so this stays one flat set rather than per-provider lists.
_ACTIONS: Final = frozenset(
    {
        "connect",
        "refresh",
        "test_connection",
        "status",
        "disconnect",
        "read_calendar",
        "read_mail",
        "search_mail",
        "search_files",
        "read_file_text",
        "read_teams_chats",
        "read_teams_messages",
        "read_teams_channels",
        "send_mail",
        "reply_mail",
        "move_mail",
        "create_event",
        "update_event",
        "delete_event",
        "create_file",
        "move_file",
        "share_file",
        "delete_file",
        "send_chat",
        "post_channel_message",
        "delete_chat_message",
        "delete_channel_message",
        # QuickBooks reads (T33, decision #164) — reads only, records stay content-free.
        "qbo_profit_and_loss",
        "qbo_balance_sheet",
        "qbo_trial_balance",
        "qbo_accounts",
        "qbo_month_pack",
    }
)
#: `disconnect` (T44c, decision #161) has no started/failed phase of its own —
#: `delete_tokens` is a local, unfailable operation — so it logs one of these
#: two outcomes directly instead of started/succeeded/failed.
_STAGES: Final = frozenset({"started", "succeeded", "failed", "removed", "already_gone"})
_MAX_RECORD_BYTES: Final = 4096


class AuditError(Exception):
    """A connector-action audit record could not be durably appended."""

    def __init__(self) -> None:
        super().__init__("connector action audit record could not be saved")


def _default_path() -> Path:
    if sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    elif sys.platform == "win32":
        value = os.environ.get("LOCALAPPDATA")
        if not value:
            raise ValueError
        base = Path(value)
    elif sys.platform.startswith("linux"):
        value = os.environ.get("XDG_DATA_HOME")
        base = Path(value) if value else Path.home() / ".local" / "share"
    else:
        raise ValueError
    if not base.is_absolute():
        raise ValueError
    return base / "OASIS" / "connector-events.jsonl"


def _record(
    connector: str,
    person: str,
    action: str,
    stage: str,
    operation_id: str,
    *,
    mail_format: Literal["html", "text"] | None = None,
) -> bytes:
    if action not in _ACTIONS or stage not in _STAGES:
        raise ValueError
    if not isinstance(connector, str) or not connector:
        raise ValueError
    if not isinstance(person, str) or not person:
        raise ValueError
    if mail_format is not None and mail_format not in ("html", "text"):
        raise ValueError
    identifier = str(uuid.UUID(operation_id))
    actor = getpass.getuser()
    if not isinstance(actor, str) or not actor or len(actor) > 256:
        raise ValueError
    data: dict[str, str] = {"connector": connector, "person": person}
    if mail_format is not None:
        data["format"] = mail_format
    event = {
        "actor": actor,
        "what": action,
        "data": data,
        "model": None,
        "cost": 0,
        "timestamp": datetime.now(UTC).isoformat(),
        "stage": stage,
        "operation_id": identifier,
    }
    record = (json.dumps(event, ensure_ascii=True, separators=(",", ":")) + "\n").encode()
    if len(record) > _MAX_RECORD_BYTES:
        raise ValueError
    return record


def append_event(
    connector: str,
    person: str,
    action: str,
    stage: str,
    operation_id: str,
    *,
    mail_format: Literal["html", "text"] | None = None,
    path: Path | None = None,
) -> None:
    """Append and fsync one metadata record, or raise a redacted :class:`AuditError`.

    ``mail_format`` (T43, decisions #139/#150) adds a ``"format": "html"|"text"``
    field to the record's ``data`` — never the body itself — for the mail send/
    reply actions that now carry an optional HTML body.
    """
    failed = False
    try:
        record = _record(connector, person, action, stage, operation_id, mail_format=mail_format)
        destination = _default_path() if path is None else path
        destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, "O_BINARY", 0)
        descriptor = os.open(destination, flags, 0o600)
        try:
            if os.write(descriptor, record) != len(record):
                raise OSError
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    except Exception:
        failed = True
    # Outside the handler: no sensitive filesystem/backend exception context.
    if failed:
        raise AuditError()
