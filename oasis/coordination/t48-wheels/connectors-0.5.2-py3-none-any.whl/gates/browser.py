"""Opens the provider's consent page in the system browser.

Injectable on purpose: tests never open a real browser, they hand in a fake
opener that records the URL (or feeds it straight to a fake provider server).
"""

from __future__ import annotations

import webbrowser
from typing import Protocol


class BrowserOpener(Protocol):
    """Callable shape of ``webbrowser.open``: URL in, success flag out."""

    def __call__(self, url: str) -> bool: ...


def default_opener(url: str) -> bool:
    """Open ``url`` in the person's default system browser."""
    return webbrowser.open(url)
